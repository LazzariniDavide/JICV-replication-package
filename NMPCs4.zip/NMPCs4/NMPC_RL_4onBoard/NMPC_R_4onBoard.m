%% RIGID VEHICLE UPDATED - REAR
clc;
clear all;
close all;
addpath('..\..\')

data = A2_Full_car_model_parameters_4onBoard();

Ts      = 1e-3*[0 10 20 30 50 60 100];              % NMPCs4
EXPORT = 1;
COMPILE= 1;
T_discr = 0.0025;

%Define your states
DifferentialState z_b_dot z_b z_u_dot z_u x_b_dot x_b x_u_dot x_u ...
    theta_w_dot theta_w theta_s_dot theta_s torque;

%Define your control inputs
Control Delta_Tm sigma_eps; 

%Extra inputs needed
OnlineData w beta_y Tm_req_R1 Tm_req_R2 Tm_req_F_L Tm_req_F_R mu_act sigma_ref;

%% relative displacement and speed
epsilon_dot_x   = is(x_b_dot - x_u_dot);        % Longitudinal relative speed
epsilon_dot_z   = is(z_b_dot - z_u_dot);        % Vertical relative speed

epsilon_x       = is(x_b - x_u);                % Longitudinal relative displacement
epsilon_z       = is(z_b - z_u);                % Vertical relative displacement

%% antijerk term
delta_theta_dot_x   = is(theta_s_dot - theta_w_dot);      % Theta_s_dot - theta_w_dot

%% Vertical damper force
Fc_x = is(data.c_x_R * epsilon_dot_x);
Fc_z = is(0.71*(700*(-1.5 + atan(7*0.71*epsilon_dot_z + 1.1)/(pi/2))...
     + 1700*(1 + atan(18*0.71*epsilon_dot_z - 1.4)/(pi/2))));

Fk_x = is(data.k_x_R * epsilon_x);
Fk_z = is(data.k_z_R * epsilon_z);

%% Inverse tyre model equations
Fr_x = is((w - z_u)*cos(beta_y) * data.k_r_R * sin(beta_y));
Fr_z = is((w - z_u)*cos(beta_y) * data.k_r_R * cos(beta_y));

Ft_x = is((w - z_u)*sin(beta_y) * data.k_t_R * 5 * cos(beta_y));
Ft_z = is((w - z_u)*sin(beta_y) * data.k_t_R * 5 * sin(beta_y));

%% Longitudinal dynamics - Drag forces
F_drag = is(data.Aero_Coeff * x_b_dot^2);

%% Rolling resistance - Front
f_roll_F = is(data.f_0_F + data.f_2_F*x_b_dot^2);
F_roll_F = is(f_roll_F * data.m_total * data.b/data.L * data.g);

%% Rolling resistance - Rear
f_roll_R = is(data.f_0_R + data.f_2_R*x_b_dot^2);
F_roll_R = is(f_roll_R * data.m_total * data.a/data.L * data.g);

%% Deflection of the tyre
delta_rho = is((w - z_u)*cos(beta_y));
rho = is(0.3833 - 0.5*data.m_total*9.81*data.a/data.L/data.k_r_R - delta_rho); % - m_total*9.81*b/L/k_r

%% Pacejka
sigma_th        = is(1-(x_u_dot/(theta_w_dot*data.R_R)));             % Longitudinal slip
F_z             = is((Fr_z + 0.5*data.m_total*9.81*data.a/data.L));       % N      

% --------------------------------------------------------------------------
% Longitudinal Equation at pure slip - FxTyreFL
% --------------------------------------------------------------------------
gamma_x = data.gammaFL * data.LGAX;
dfz     = is((F_z - data.LFZO*data.FZ0)/(data.LFZO*data.FZ0));
mu      = is((mu_act+1e-10) * (data.PDX1 + data.PDX2* dfz)*( 1 - data.PDX3 * gamma_x^2 ).*data.LMUX);
SHx     = is((data.PHX1 + data.PHX2 * dfz)*data.LHX);
sigma_x = is(sigma_th + SHx);
C       = data.PCX1 * data.LCX;
D       = is(mu * F_z);
E       = is((data.PEX1 + data.PEX2*dfz + data.PEX3 * dfz^2).*data.LEX);

Kx      = is(F_z * (data.PKX1 + data.PKX2 * dfz) * 2.71828^(data.PKX3 * dfz) * data.LKX);
Svx     = is(F_z * ( data.PVX1 + data.PVX2 * dfz ) * data.LVX * data.LMUX * data.mu_max);
B       = is(Kx/(C*D));
F_x     = is(D * sin(C*atan(B*sigma_x - E*(B*sigma_x - atan( B* sigma_x )))) + Svx);
Fx_x    = is(F_x*cos(beta_y));
Fx_z    = is(F_x*sin(beta_y));

%% HALF SHAFT EQUATIONS

fa = is(data.k_hs_R4*(theta_s - theta_w + data.backlash_R4)); 
fb = is(data.k_hs_R4*(theta_s - theta_w - data.backlash_R4)); %
fc = is(data.b_hs_R4*(theta_s_dot - theta_w_dot));
f2_exp = is(exp(2*data.a_diff*( data.backlash_R4 - (theta_s - theta_w)))); %
f1_exp = is(exp(2*data.a_diff*( data.backlash_R4 + (theta_s - theta_w)))); %
f1 = is(0.5*((1-f1_exp) / (1+f1_exp)) + 0.5);
f2 = is(0.5*((1-f2_exp) / (1+f2_exp)) + 0.5);

T_hs_K = is(fa*f1 + fb*f2);
T_hs_B = is(fc*f1 + fc*f2);

T_hs = is(T_hs_K + T_hs_B);

T_t = is(data.i_t_R4*data.n_t_R4*torque);
%T_hs=T_t;
%% Quarter-car model equations
z_b_ddot    = is((- Fk_z - Fc_z)/(data.m_b*data.a/(data.L*2))); 

z_u_ddot    = is((  Fk_z + Fc_z + Fr_z - Ft_z + Fx_z)/data.m_u_R);        

x_b_ddot    = is((- Fk_x - Fc_x...
            + Tm_req_R2/data.R_R + Tm_req_F_R/data.R_F +Tm_req_F_L/data.R_F...
            - F_drag - F_roll_F - 0.5*F_roll_R)/data.m_app_RL);

x_u_ddot    = is((Fk_x + Fc_x - Fr_x - Ft_x + Fx_x)/data.m_u_R);

MyFL0       = is(rho * (F_z).* (data.QSY1 + data.QSY2 * (F_z)./data.FNOMIN));

theta_w_ddot   = is((T_hs - F_x*rho - MyFL0)/data.I_y_R);

torque_dot  = is((Tm_req_R1 + Delta_Tm) - torque)/data.tau_R4;

theta_s_ddot = is(T_t - T_hs) / data.J_eq_R4;

f=[dot(z_b_dot);...
    dot(z_b);
    dot(z_u_dot);...
    dot(z_u);
    dot(x_b_dot);...
    dot(x_b);
    dot(x_u_dot);...
    dot(x_u);...
    dot(theta_w_dot);...
    dot(theta_w);...
    dot(theta_s_dot);...
    dot(theta_s);...
    dot(torque)]==...
    [z_b_ddot;...
    z_b_dot;...
    z_u_ddot;...
    z_u_dot;...
    x_b_ddot;...
    x_b_dot;...
    x_u_ddot;...
    x_u_dot;...
    theta_w_ddot;...
    theta_w_dot;...
    theta_s_ddot;...
    theta_s_dot;...
    torque_dot];

%% COMPUTING TERMS TO DEFINE COST FUNCTION
control_action = is(Delta_Tm);

% Cost Function
h = {x_b_ddot; delta_theta_dot_x; sigma_eps; control_action}; 
hN = {x_b_ddot; delta_theta_dot_x};

%% MPCexport
fprintf('----------------------------\n         NMPC-export         \n----------------------------\n');
acadoSet('problemname', 'NMPC');

N = 100; %Steps
%N_int = fix(N*Ts/T_discr);
N_int = fix(Ts(end)/T_discr);

%ocp = acado.OCP( 0.0, N*Ts, N );
ocp = acado.OCP(Ts);

%These two variables are just for the compilation. The ones implemented in
%the Simulink Model are used in the simulation
W = acado.BMatrix(eye(length(h)));
WN = acado.BMatrix(eye(length(hN)));


ocp.minimizeLSQ(W, h);
ocp.minimizeLSQEndTerm(WN, hN);


%% Constraints

% Control force constraints
ocp.subjectTo(is(data.Lb_Tm - (Delta_Tm + Tm_req_R1)) <= 0);
ocp.subjectTo(is(data.Ub_Tm - (Delta_Tm + Tm_req_R1)) >= 0);
ocp.subjectTo(is(sigma_th - sigma_ref - sigma_eps) <= 0);
ocp.subjectTo(is(sigma_eps) >= 0);

%% Set the model
ocp.setModel( f );

%% ACADO Settings
mpc = acado.OCPexport( ocp );
mpc.set( 'HESSIAN_APPROXIMATION',       'GAUSS_NEWTON'      );
mpc.set( 'DISCRETIZATION_TYPE',         'MULTIPLE_SHOOTING' );
mpc.set( 'SPARSE_QP_SOLUTION',          'FULL_CONDENSING_N2');
mpc.set( 'INTEGRATOR_TYPE',             'INT_IRK_GL4'       );
mpc.set( 'NUM_INTEGRATOR_STEPS',           N_int            );
mpc.set( 'QP_SOLVER',                   'QP_QPOASES3'    	);
mpc.set( 'GENERATE_SIMULINK_INTERFACE', 'YES'               );
mpc.set( 'LEVENBERG_MARQUARDT',             0.99            );

if EXPORT
    mpc.exportCode( 'export_MPC' );
end
if COMPILE
    global ACADO_;
    copyfile([ACADO_.pwd '/../../external_packages/qpoases3'], 'export_MPC/qpoases3')
    
    make_custom_solver_sfunction_4onBoard
    
end