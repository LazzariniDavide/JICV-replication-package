/*
*    This file is part of ACADO Toolkit.
*
*    ACADO Toolkit -- A Toolkit for Automatic Control and Dynamic Optimization.
*    Copyright (C) 2008-2009 by Boris Houska and Hans Joachim Ferreau, K.U.Leuven.
*    Developed within the Optimization in Engineering Center (OPTEC) under
*    supervision of Moritz Diehl. All rights reserved.
*
*    ACADO Toolkit is free software; you can redistribute it and/or
*    modify it under the terms of the GNU Lesser General Public
*    License as published by the Free Software Foundation; either
*    version 3 of the License, or (at your option) any later version.
*
*    ACADO Toolkit is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*    Lesser General Public License for more details.
*
*    You should have received a copy of the GNU Lesser General Public
*    License along with ACADO Toolkit; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
*/


/**
*    Author David Ariens, Rien Quirynen
*    Date 2009-2013
*    http://www.acadotoolkit.org/matlab 
*/

#include <acado_optimal_control.hpp>
#include <acado_toolkit.hpp>
#include <acado/utils/matlab_acado_utils.hpp>

USING_NAMESPACE_ACADO

#include <mex.h>


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ) 
 { 
 
    MatlabConsoleStreamBuf mybuf;
    RedirectStream redirect(std::cout, mybuf);
    clearAllStaticCounters( ); 
 
    mexPrintf("\nACADO Toolkit for Matlab - Developed by David Ariens and Rien Quirynen, 2009-2013 \n"); 
    mexPrintf("Support available at http://www.acadotoolkit.org/matlab \n \n"); 

    if (nrhs != 0){ 
      mexErrMsgTxt("This problem expects 0 right hand side argument(s) since you have defined 0 MexInput(s)");
    } 
 
    TIME autotime;
    DifferentialState z_b_dot;
    DifferentialState z_b;
    DifferentialState z_u_dot;
    DifferentialState z_u;
    DifferentialState x_b_dot;
    DifferentialState x_b;
    DifferentialState x_u_dot;
    DifferentialState x_u;
    DifferentialState theta_w_dot;
    DifferentialState theta_w;
    DifferentialState theta_s_dot;
    DifferentialState theta_s;
    DifferentialState torque;
    Control Delta_Tm;
    Control sigma_eps;
    OnlineData w; 
    OnlineData beta_y; 
    OnlineData Tm_req_R1; 
    OnlineData Tm_req_R2; 
    OnlineData Tm_req_F_L; 
    OnlineData Tm_req_F_R; 
    OnlineData mu_act; 
    OnlineData sigma_ref; 
    IntermediateState intS1 = (x_b_dot-x_u_dot);
    IntermediateState intS2 = (z_b_dot-z_u_dot);
    IntermediateState intS3 = (x_b-x_u);
    IntermediateState intS4 = (z_b-z_u);
    IntermediateState intS5 = (theta_s_dot-theta_w_dot);
    IntermediateState intS6 = 1.80000000000000000000e+03*intS1;
    IntermediateState intS7 = (((-1.50000000000000000000e+00)+1/1.57079632679489655800e+00*atan((1.10000000000000008882e+00+4.96999999999999975131e+00*intS2)))*7.00000000000000000000e+02+(1.00000000000000000000e+00+1/1.57079632679489655800e+00*atan((1.27799999999999993605e+01*intS2-1.39999999999999991118e+00)))*1.70000000000000000000e+03)*7.09999999999999964473e-01;
    IntermediateState intS8 = 6.00000000000000000000e+05*intS3;
    IntermediateState intS9 = 3.30000000000000000000e+04*intS4;
    IntermediateState intS10 = (w-z_u)*3.17634000000000000000e+05*cos(beta_y)*sin(beta_y);
    IntermediateState intS11 = (w-z_u)*3.17634000000000000000e+05*cos(beta_y)*cos(beta_y);
    IntermediateState intS12 = (w-z_u)*3.17634000000000000000e+05*5.00000000000000000000e+00*cos(beta_y)*sin(beta_y);
    IntermediateState intS13 = (w-z_u)*3.17634000000000000000e+05*5.00000000000000000000e+00*sin(beta_y)*sin(beta_y);
    IntermediateState intS14 = 4.46862079999999994850e-01*pow(x_b_dot,2.00000000000000000000e+00);
    IntermediateState intS15 = 1.07499999999999991396e-02;
    IntermediateState intS16 = 1.45530000000000003801e+00*2.90900000000000000000e+03/2.92799999999999993605e+00*9.81000000000000049738e+00*intS15;
    IntermediateState intS17 = 1.07499999999999991396e-02;
    IntermediateState intS18 = 1.47269999999999989804e+00*2.90900000000000000000e+03/2.92799999999999993605e+00*9.81000000000000049738e+00*intS17;
    IntermediateState intS19 = (w-z_u)*cos(beta_y);
    IntermediateState intS20 = (3.60705696214425830526e-01-intS19);
    IntermediateState intS21 = (1.00000000000000000000e+00-1/3.72499999999999997780e-01/theta_w_dot*x_u_dot);
    IntermediateState intS22 = (7.17671908862704913190e+03+intS11);
    IntermediateState intS23 = (-7.00000000000000000000e+03+intS22)/7.00000000000000000000e+03;
    IntermediateState intS24 = (1.00000000000000003643e-10+mu_act)*(1.12999999999999992811e-02*intS23+1.22669999999999990159e+00);
    IntermediateState intS25 = 0;
    IntermediateState intS26 = intS21;
    IntermediateState intS27 = intS22*intS24;
    IntermediateState intS28 = ((-2.55900000000000016342e-01)+1.30099999999999993427e-01*intS23);
    IntermediateState intS29 = (1.15014000000000002899e+01*intS23+3.44585000000000007958e+01)*intS22;
    IntermediateState intS30 = 0;
    IntermediateState intS31 = 1/1.41060000000000007603e+00/intS27*intS29;
    IntermediateState intS32 = intS27*sin(1.41060000000000007603e+00*atan((-(-atan(intS26*intS31)+intS26*intS31)*intS28+intS26*intS31)));
    IntermediateState intS33 = cos(beta_y)*intS32;
    IntermediateState intS34 = intS32*sin(beta_y);
    IntermediateState intS35 = (1.05000000000000006523e-02+theta_s-theta_w)*7.70000000000000000000e+03;
    IntermediateState intS36 = (-1.05000000000000006523e-02+theta_s-theta_w)*7.70000000000000000000e+03;
    IntermediateState intS37 = (theta_s_dot-theta_w_dot)*4.70000000000000000000e+01;
    IntermediateState intS38 = exp((1.05000000000000006523e-02-theta_s+theta_w)*2.00000000000000000000e+02);
    IntermediateState intS39 = exp((1.05000000000000006523e-02+theta_s-theta_w)*2.00000000000000000000e+02);
    IntermediateState intS40 = (1/(1.00000000000000000000e+00+intS39)*(1.00000000000000000000e+00-intS39)*5.00000000000000000000e-01+5.00000000000000000000e-01);
    IntermediateState intS41 = (1/(1.00000000000000000000e+00+intS38)*(1.00000000000000000000e+00-intS38)*5.00000000000000000000e-01+5.00000000000000000000e-01);
    IntermediateState intS42 = (intS35*intS40+intS36*intS41);
    IntermediateState intS43 = (intS37*intS40+intS37*intS41);
    IntermediateState intS44 = (intS42+intS43);
    IntermediateState intS45 = 4.34905999360000006249e+00*torque;
    IntermediateState intS46 = (-intS7-intS9)/7.01393493852458959736e+02;
    IntermediateState intS47 = (intS11-intS13+intS34+intS7+intS9)/3.00000000000000000000e+01;
    IntermediateState intS48 = (1/3.72499999999999997780e-01*Tm_req_F_L+1/3.72499999999999997780e-01*Tm_req_F_R+1/3.72499999999999997780e-01*Tm_req_R2-5.00000000000000000000e-01*intS18-intS14-intS16-intS6-intS8)/2.90903107968109543435e+03;
    IntermediateState intS49 = (-intS10-intS12+intS33+intS6+intS8)/3.00000000000000000000e+01;
    IntermediateState intS50 = 1.00000000000000002082e-02*intS20*intS22;
    IntermediateState intS51 = (-intS20*intS32+intS44-intS50)/1.38900000000000001243e+00;
    IntermediateState intS52 = (Delta_Tm+Tm_req_R1-torque);
    IntermediateState intS53 = (-intS44+intS45);
    IntermediateState intS54 = Delta_Tm;
    DVector acadodata_v1(7);
    acadodata_v1(0) = 0;
    acadodata_v1(1) = 5.000000E-03;
    acadodata_v1(2) = 1.000000E-02;
    acadodata_v1(3) = 2.000000E-02;
    acadodata_v1(4) = 3.000000E-02;
    acadodata_v1(5) = 4.000000E-02;
    acadodata_v1(6) = 8.000000E-02;
    BMatrix acadodata_M1;
    acadodata_M1.read( "NMPC_data_acadodata_M1.txt" );
    BMatrix acadodata_M2;
    acadodata_M2.read( "NMPC_data_acadodata_M2.txt" );
    Function acadodata_f1;
    acadodata_f1 << intS48;
    acadodata_f1 << intS5;
    acadodata_f1 << sigma_eps;
    acadodata_f1 << intS54;
    Function acadodata_f2;
    acadodata_f2 << intS48;
    acadodata_f2 << intS5;
    IntermediateState intS55 = ((-3.50000000000000000000e+02)-Delta_Tm-Tm_req_R1);
    IntermediateState intS56 = (3.50000000000000000000e+02-Delta_Tm-Tm_req_R1);
    IntermediateState intS57 = (intS21-sigma_eps-sigma_ref);
    IntermediateState intS58 = sigma_eps;
    Grid grid_acadodata_v1(acadodata_v1);
    OCP ocp1(grid_acadodata_v1);
    ocp1.minimizeLSQ(acadodata_M1, acadodata_f1);
    ocp1.minimizeLSQEndTerm(acadodata_M2, acadodata_f2);
    ocp1.subjectTo(intS55 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(intS56 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(intS57 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(intS58 >= 0.00000000000000000000e+00);
    DifferentialEquation acadodata_f3;
    acadodata_f3 << dot(z_b_dot) == intS46;
    acadodata_f3 << dot(z_b) == z_b_dot;
    acadodata_f3 << dot(z_u_dot) == intS47;
    acadodata_f3 << dot(z_u) == z_u_dot;
    acadodata_f3 << dot(x_b_dot) == intS48;
    acadodata_f3 << dot(x_b) == x_b_dot;
    acadodata_f3 << dot(x_u_dot) == intS49;
    acadodata_f3 << dot(x_u) == x_u_dot;
    acadodata_f3 << dot(theta_w_dot) == intS51;
    acadodata_f3 << dot(theta_w) == theta_w_dot;
    acadodata_f3 << dot(theta_s_dot) == 1/1.39205141922101982566e+00*intS53;
    acadodata_f3 << dot(theta_s) == theta_s_dot;
    acadodata_f3 << dot(torque) == 1/5.69949999999999970535e-03*intS52;

    ocp1.setModel( acadodata_f3 );


    ocp1.setNU( 2 );
    ocp1.setNP( 0 );
    ocp1.setNOD( 8 );
    OCPexport ExportModule1( ocp1 );
    ExportModule1.set( GENERATE_MATLAB_INTERFACE, 1 );
    uint options_flag;
    options_flag = ExportModule1.set( HESSIAN_APPROXIMATION, GAUSS_NEWTON );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: HESSIAN_APPROXIMATION");
    options_flag = ExportModule1.set( DISCRETIZATION_TYPE, MULTIPLE_SHOOTING );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: DISCRETIZATION_TYPE");
    options_flag = ExportModule1.set( SPARSE_QP_SOLUTION, FULL_CONDENSING_N2 );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: SPARSE_QP_SOLUTION");
    options_flag = ExportModule1.set( INTEGRATOR_TYPE, INT_IRK_GL4 );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: INTEGRATOR_TYPE");
    options_flag = ExportModule1.set( NUM_INTEGRATOR_STEPS, 32 );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: NUM_INTEGRATOR_STEPS");
    options_flag = ExportModule1.set( QP_SOLVER, QP_QPOASES3 );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: QP_SOLVER");
    options_flag = ExportModule1.set( GENERATE_SIMULINK_INTERFACE, YES );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: GENERATE_SIMULINK_INTERFACE");
    options_flag = ExportModule1.set( LEVENBERG_MARQUARDT, 9.900000E-01 );
    if(options_flag != 0) mexErrMsgTxt("ACADO export failed when setting the following option: LEVENBERG_MARQUARDT");
    uint export_flag;
    export_flag = ExportModule1.exportCode( "export_MPC" );
    if(export_flag != 0) mexErrMsgTxt("ACADO export failed because of the above error(s)!");


    clearAllStaticCounters( ); 
 
} 

