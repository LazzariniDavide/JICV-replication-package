/*
 *    This file was auto-generated using the ACADO Toolkit.
 *    
 *    While ACADO Toolkit is free software released under the terms of
 *    the GNU Lesser General Public License (LGPL), the generated code
 *    as such remains the property of the user who used ACADO Toolkit
 *    to generate this code. In particular, user dependent data of the code
 *    do not inherit the GNU LGPL license. On the other hand, parts of the
 *    generated code that are a direct copy of source code from the
 *    ACADO Toolkit or the software tools it is based on, remain, as derived
 *    work, automatically covered by the LGPL license.
 *    
 *    ACADO Toolkit is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *    
 */


#include "acado_common.h"




/******************************************************************************/
/*                                                                            */
/* ACADO code generation                                                      */
/*                                                                            */
/******************************************************************************/


int acado_modelSimulation(  )
{
int ret;

int lRun1;
int lRun2;
ret = 0;
for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
acadoWorkspace.state[0] = acadoVariables.x[lRun1 * 13];
acadoWorkspace.state[1] = acadoVariables.x[lRun1 * 13 + 1];
acadoWorkspace.state[2] = acadoVariables.x[lRun1 * 13 + 2];
acadoWorkspace.state[3] = acadoVariables.x[lRun1 * 13 + 3];
acadoWorkspace.state[4] = acadoVariables.x[lRun1 * 13 + 4];
acadoWorkspace.state[5] = acadoVariables.x[lRun1 * 13 + 5];
acadoWorkspace.state[6] = acadoVariables.x[lRun1 * 13 + 6];
acadoWorkspace.state[7] = acadoVariables.x[lRun1 * 13 + 7];
acadoWorkspace.state[8] = acadoVariables.x[lRun1 * 13 + 8];
acadoWorkspace.state[9] = acadoVariables.x[lRun1 * 13 + 9];
acadoWorkspace.state[10] = acadoVariables.x[lRun1 * 13 + 10];
acadoWorkspace.state[11] = acadoVariables.x[lRun1 * 13 + 11];
acadoWorkspace.state[12] = acadoVariables.x[lRun1 * 13 + 12];

acadoWorkspace.state[208] = acadoVariables.u[lRun1 * 2];
acadoWorkspace.state[209] = acadoVariables.u[lRun1 * 2 + 1];
acadoWorkspace.state[210] = acadoVariables.od[lRun1 * 8];
acadoWorkspace.state[211] = acadoVariables.od[lRun1 * 8 + 1];
acadoWorkspace.state[212] = acadoVariables.od[lRun1 * 8 + 2];
acadoWorkspace.state[213] = acadoVariables.od[lRun1 * 8 + 3];
acadoWorkspace.state[214] = acadoVariables.od[lRun1 * 8 + 4];
acadoWorkspace.state[215] = acadoVariables.od[lRun1 * 8 + 5];
acadoWorkspace.state[216] = acadoVariables.od[lRun1 * 8 + 6];
acadoWorkspace.state[217] = acadoVariables.od[lRun1 * 8 + 7];

ret = acado_integrate(acadoWorkspace.state, 1, lRun1);

acadoWorkspace.d[lRun1 * 13] = acadoWorkspace.state[0] - acadoVariables.x[lRun1 * 13 + 13];
acadoWorkspace.d[lRun1 * 13 + 1] = acadoWorkspace.state[1] - acadoVariables.x[lRun1 * 13 + 14];
acadoWorkspace.d[lRun1 * 13 + 2] = acadoWorkspace.state[2] - acadoVariables.x[lRun1 * 13 + 15];
acadoWorkspace.d[lRun1 * 13 + 3] = acadoWorkspace.state[3] - acadoVariables.x[lRun1 * 13 + 16];
acadoWorkspace.d[lRun1 * 13 + 4] = acadoWorkspace.state[4] - acadoVariables.x[lRun1 * 13 + 17];
acadoWorkspace.d[lRun1 * 13 + 5] = acadoWorkspace.state[5] - acadoVariables.x[lRun1 * 13 + 18];
acadoWorkspace.d[lRun1 * 13 + 6] = acadoWorkspace.state[6] - acadoVariables.x[lRun1 * 13 + 19];
acadoWorkspace.d[lRun1 * 13 + 7] = acadoWorkspace.state[7] - acadoVariables.x[lRun1 * 13 + 20];
acadoWorkspace.d[lRun1 * 13 + 8] = acadoWorkspace.state[8] - acadoVariables.x[lRun1 * 13 + 21];
acadoWorkspace.d[lRun1 * 13 + 9] = acadoWorkspace.state[9] - acadoVariables.x[lRun1 * 13 + 22];
acadoWorkspace.d[lRun1 * 13 + 10] = acadoWorkspace.state[10] - acadoVariables.x[lRun1 * 13 + 23];
acadoWorkspace.d[lRun1 * 13 + 11] = acadoWorkspace.state[11] - acadoVariables.x[lRun1 * 13 + 24];
acadoWorkspace.d[lRun1 * 13 + 12] = acadoWorkspace.state[12] - acadoVariables.x[lRun1 * 13 + 25];

for (lRun2 = 0; lRun2 < 169; ++lRun2)
acadoWorkspace.evGx[(0) + ((lRun2) + (lRun1 * 169))] = acadoWorkspace.state[lRun2 + 13];


acadoWorkspace.evGu[lRun1 * 26] = acadoWorkspace.state[182];
acadoWorkspace.evGu[lRun1 * 26 + 1] = acadoWorkspace.state[183];
acadoWorkspace.evGu[lRun1 * 26 + 2] = acadoWorkspace.state[184];
acadoWorkspace.evGu[lRun1 * 26 + 3] = acadoWorkspace.state[185];
acadoWorkspace.evGu[lRun1 * 26 + 4] = acadoWorkspace.state[186];
acadoWorkspace.evGu[lRun1 * 26 + 5] = acadoWorkspace.state[187];
acadoWorkspace.evGu[lRun1 * 26 + 6] = acadoWorkspace.state[188];
acadoWorkspace.evGu[lRun1 * 26 + 7] = acadoWorkspace.state[189];
acadoWorkspace.evGu[lRun1 * 26 + 8] = acadoWorkspace.state[190];
acadoWorkspace.evGu[lRun1 * 26 + 9] = acadoWorkspace.state[191];
acadoWorkspace.evGu[lRun1 * 26 + 10] = acadoWorkspace.state[192];
acadoWorkspace.evGu[lRun1 * 26 + 11] = acadoWorkspace.state[193];
acadoWorkspace.evGu[lRun1 * 26 + 12] = acadoWorkspace.state[194];
acadoWorkspace.evGu[lRun1 * 26 + 13] = acadoWorkspace.state[195];
acadoWorkspace.evGu[lRun1 * 26 + 14] = acadoWorkspace.state[196];
acadoWorkspace.evGu[lRun1 * 26 + 15] = acadoWorkspace.state[197];
acadoWorkspace.evGu[lRun1 * 26 + 16] = acadoWorkspace.state[198];
acadoWorkspace.evGu[lRun1 * 26 + 17] = acadoWorkspace.state[199];
acadoWorkspace.evGu[lRun1 * 26 + 18] = acadoWorkspace.state[200];
acadoWorkspace.evGu[lRun1 * 26 + 19] = acadoWorkspace.state[201];
acadoWorkspace.evGu[lRun1 * 26 + 20] = acadoWorkspace.state[202];
acadoWorkspace.evGu[lRun1 * 26 + 21] = acadoWorkspace.state[203];
acadoWorkspace.evGu[lRun1 * 26 + 22] = acadoWorkspace.state[204];
acadoWorkspace.evGu[lRun1 * 26 + 23] = acadoWorkspace.state[205];
acadoWorkspace.evGu[lRun1 * 26 + 24] = acadoWorkspace.state[206];
acadoWorkspace.evGu[lRun1 * 26 + 25] = acadoWorkspace.state[207];
}
return ret;
}

void acado_evaluateLSQ(const real_t* in, real_t* out)
{
const real_t* xd = in;
const real_t* u = in + 13;
const real_t* od = in + 15;
/* Vector of auxiliary variables; number of elements: 51. */
real_t* a = acadoWorkspace.objAuxVar;

/* Compute intermediate quantities: */
a[0] = (real_t)(1.0749999999999999e-02);
a[1] = ((real_t)(1.4353438177254096e+04)*a[0]);
a[2] = ((xd[4])*(xd[4]));
a[3] = ((real_t)(4.4686207999999999e-01)*a[2]);
a[4] = (real_t)(1.0749999999999999e-02);
a[5] = ((real_t)(1.4183851822745903e+04)*a[4]);
a[6] = (xd[4]-xd[6]);
a[7] = ((real_t)(1.8000000000000000e+03)*a[6]);
a[8] = (xd[5]-xd[7]);
a[9] = ((real_t)(6.0000000000000000e+05)*a[8]);
a[10] = ((((((((((real_t)(2.6845637583892619e+00)*od[4])+((real_t)(2.6845637583892619e+00)*od[5]))+((real_t)(2.6845637583892619e+00)*od[3]))-((real_t)(5.0000000000000000e-01)*a[1]))-a[3])-a[5])-a[7])-a[9])/(real_t)(2.9090310796810954e+03));
a[11] = (xd[10]-xd[8]);
a[12] = (real_t)(0.0000000000000000e+00);
a[13] = (real_t)(0.0000000000000000e+00);
a[14] = (real_t)(0.0000000000000000e+00);
a[15] = (real_t)(0.0000000000000000e+00);
a[16] = ((real_t)(2.0000000000000000e+00)*xd[4]);
a[17] = ((real_t)(4.4686207999999999e-01)*a[16]);
a[18] = (real_t)(1.8000000000000000e+03);
a[19] = ((real_t)(1.0000000000000000e+00)/(real_t)(2.9090310796810954e+03));
a[20] = ((((real_t)(0.0000000000000000e+00)-a[17])-a[18])*a[19]);
a[21] = (real_t)(6.0000000000000000e+05);
a[22] = (((real_t)(0.0000000000000000e+00)-a[21])*a[19]);
a[23] = ((real_t)(0.0000000000000000e+00)-(real_t)(1.0000000000000000e+00));
a[24] = ((real_t)(1.8000000000000000e+03)*a[23]);
a[25] = (((real_t)(0.0000000000000000e+00)-a[24])*a[19]);
a[26] = ((real_t)(0.0000000000000000e+00)-(real_t)(1.0000000000000000e+00));
a[27] = ((real_t)(6.0000000000000000e+05)*a[26]);
a[28] = (((real_t)(0.0000000000000000e+00)-a[27])*a[19]);
a[29] = (real_t)(0.0000000000000000e+00);
a[30] = (real_t)(0.0000000000000000e+00);
a[31] = (real_t)(0.0000000000000000e+00);
a[32] = (real_t)(0.0000000000000000e+00);
a[33] = (real_t)(0.0000000000000000e+00);
a[34] = (real_t)(0.0000000000000000e+00);
a[35] = (real_t)(0.0000000000000000e+00);
a[36] = (real_t)(0.0000000000000000e+00);
a[37] = (real_t)(0.0000000000000000e+00);
a[38] = (real_t)(0.0000000000000000e+00);
a[39] = (real_t)(0.0000000000000000e+00);
a[40] = (real_t)(0.0000000000000000e+00);
a[41] = (real_t)(0.0000000000000000e+00);
a[42] = ((real_t)(0.0000000000000000e+00)-(real_t)(1.0000000000000000e+00));
a[43] = (real_t)(0.0000000000000000e+00);
a[44] = (real_t)(1.0000000000000000e+00);
a[45] = (real_t)(0.0000000000000000e+00);
a[46] = (real_t)(0.0000000000000000e+00);
a[47] = (real_t)(0.0000000000000000e+00);
a[48] = (real_t)(0.0000000000000000e+00);
a[49] = (real_t)(0.0000000000000000e+00);
a[50] = (real_t)(0.0000000000000000e+00);

/* Compute outputs: */
out[0] = a[10];
out[1] = a[11];
out[2] = u[1];
out[3] = u[0];
out[4] = a[12];
out[5] = a[13];
out[6] = a[14];
out[7] = a[15];
out[8] = a[20];
out[9] = a[22];
out[10] = a[25];
out[11] = a[28];
out[12] = a[29];
out[13] = a[30];
out[14] = a[31];
out[15] = a[32];
out[16] = a[33];
out[17] = a[34];
out[18] = a[35];
out[19] = a[36];
out[20] = a[37];
out[21] = a[38];
out[22] = a[39];
out[23] = a[40];
out[24] = a[41];
out[25] = a[42];
out[26] = a[43];
out[27] = a[44];
out[28] = a[45];
out[29] = a[46];
out[30] = (real_t)(0.0000000000000000e+00);
out[31] = (real_t)(0.0000000000000000e+00);
out[32] = (real_t)(0.0000000000000000e+00);
out[33] = (real_t)(0.0000000000000000e+00);
out[34] = (real_t)(0.0000000000000000e+00);
out[35] = (real_t)(0.0000000000000000e+00);
out[36] = (real_t)(0.0000000000000000e+00);
out[37] = (real_t)(0.0000000000000000e+00);
out[38] = (real_t)(0.0000000000000000e+00);
out[39] = (real_t)(0.0000000000000000e+00);
out[40] = (real_t)(0.0000000000000000e+00);
out[41] = (real_t)(0.0000000000000000e+00);
out[42] = (real_t)(0.0000000000000000e+00);
out[43] = (real_t)(0.0000000000000000e+00);
out[44] = (real_t)(0.0000000000000000e+00);
out[45] = (real_t)(0.0000000000000000e+00);
out[46] = (real_t)(0.0000000000000000e+00);
out[47] = (real_t)(0.0000000000000000e+00);
out[48] = (real_t)(0.0000000000000000e+00);
out[49] = (real_t)(0.0000000000000000e+00);
out[50] = (real_t)(0.0000000000000000e+00);
out[51] = (real_t)(0.0000000000000000e+00);
out[52] = (real_t)(0.0000000000000000e+00);
out[53] = (real_t)(0.0000000000000000e+00);
out[54] = (real_t)(0.0000000000000000e+00);
out[55] = (real_t)(0.0000000000000000e+00);
out[56] = a[47];
out[57] = a[48];
out[58] = a[49];
out[59] = a[50];
out[60] = (real_t)(0.0000000000000000e+00);
out[61] = (real_t)(1.0000000000000000e+00);
out[62] = (real_t)(1.0000000000000000e+00);
out[63] = (real_t)(0.0000000000000000e+00);
}

void acado_evaluateLSQEndTerm(const real_t* in, real_t* out)
{
const real_t* xd = in;
const real_t* od = in + 13;
/* Vector of auxiliary variables; number of elements: 47. */
real_t* a = acadoWorkspace.objAuxVar;

/* Compute intermediate quantities: */
a[0] = (real_t)(1.0749999999999999e-02);
a[1] = ((real_t)(1.4353438177254096e+04)*a[0]);
a[2] = ((xd[4])*(xd[4]));
a[3] = ((real_t)(4.4686207999999999e-01)*a[2]);
a[4] = (real_t)(1.0749999999999999e-02);
a[5] = ((real_t)(1.4183851822745903e+04)*a[4]);
a[6] = (xd[4]-xd[6]);
a[7] = ((real_t)(1.8000000000000000e+03)*a[6]);
a[8] = (xd[5]-xd[7]);
a[9] = ((real_t)(6.0000000000000000e+05)*a[8]);
a[10] = ((((((((((real_t)(2.6845637583892619e+00)*od[4])+((real_t)(2.6845637583892619e+00)*od[5]))+((real_t)(2.6845637583892619e+00)*od[3]))-((real_t)(5.0000000000000000e-01)*a[1]))-a[3])-a[5])-a[7])-a[9])/(real_t)(2.9090310796810954e+03));
a[11] = (xd[10]-xd[8]);
a[12] = (real_t)(0.0000000000000000e+00);
a[13] = (real_t)(0.0000000000000000e+00);
a[14] = (real_t)(0.0000000000000000e+00);
a[15] = (real_t)(0.0000000000000000e+00);
a[16] = ((real_t)(2.0000000000000000e+00)*xd[4]);
a[17] = ((real_t)(4.4686207999999999e-01)*a[16]);
a[18] = (real_t)(1.8000000000000000e+03);
a[19] = ((real_t)(1.0000000000000000e+00)/(real_t)(2.9090310796810954e+03));
a[20] = ((((real_t)(0.0000000000000000e+00)-a[17])-a[18])*a[19]);
a[21] = (real_t)(6.0000000000000000e+05);
a[22] = (((real_t)(0.0000000000000000e+00)-a[21])*a[19]);
a[23] = ((real_t)(0.0000000000000000e+00)-(real_t)(1.0000000000000000e+00));
a[24] = ((real_t)(1.8000000000000000e+03)*a[23]);
a[25] = (((real_t)(0.0000000000000000e+00)-a[24])*a[19]);
a[26] = ((real_t)(0.0000000000000000e+00)-(real_t)(1.0000000000000000e+00));
a[27] = ((real_t)(6.0000000000000000e+05)*a[26]);
a[28] = (((real_t)(0.0000000000000000e+00)-a[27])*a[19]);
a[29] = (real_t)(0.0000000000000000e+00);
a[30] = (real_t)(0.0000000000000000e+00);
a[31] = (real_t)(0.0000000000000000e+00);
a[32] = (real_t)(0.0000000000000000e+00);
a[33] = (real_t)(0.0000000000000000e+00);
a[34] = (real_t)(0.0000000000000000e+00);
a[35] = (real_t)(0.0000000000000000e+00);
a[36] = (real_t)(0.0000000000000000e+00);
a[37] = (real_t)(0.0000000000000000e+00);
a[38] = (real_t)(0.0000000000000000e+00);
a[39] = (real_t)(0.0000000000000000e+00);
a[40] = (real_t)(0.0000000000000000e+00);
a[41] = (real_t)(0.0000000000000000e+00);
a[42] = ((real_t)(0.0000000000000000e+00)-(real_t)(1.0000000000000000e+00));
a[43] = (real_t)(0.0000000000000000e+00);
a[44] = (real_t)(1.0000000000000000e+00);
a[45] = (real_t)(0.0000000000000000e+00);
a[46] = (real_t)(0.0000000000000000e+00);

/* Compute outputs: */
out[0] = a[10];
out[1] = a[11];
out[2] = a[12];
out[3] = a[13];
out[4] = a[14];
out[5] = a[15];
out[6] = a[20];
out[7] = a[22];
out[8] = a[25];
out[9] = a[28];
out[10] = a[29];
out[11] = a[30];
out[12] = a[31];
out[13] = a[32];
out[14] = a[33];
out[15] = a[34];
out[16] = a[35];
out[17] = a[36];
out[18] = a[37];
out[19] = a[38];
out[20] = a[39];
out[21] = a[40];
out[22] = a[41];
out[23] = a[42];
out[24] = a[43];
out[25] = a[44];
out[26] = a[45];
out[27] = a[46];
}

void acado_evaluatePathConstraints(const real_t* in, real_t* out)
{
const real_t* xd = in;
const real_t* u = in + 13;
const real_t* od = in + 15;
/* Vector of auxiliary variables; number of elements: 71. */
real_t* a = acadoWorkspace.conAuxVar;

/* Compute intermediate quantities: */
a[0] = (((real_t)(-3.5000000000000000e+02)-u[0])-od[2]);
a[1] = (((real_t)(3.5000000000000000e+02)-u[0])-od[2]);
a[2] = ((real_t)(1.0000000000000000e+00)-(((real_t)(2.6845637583892619e+00)/xd[8])*xd[6]));
a[3] = ((a[2]-u[1])-od[7]);
a[4] = (real_t)(0.0000000000000000e+00);
a[5] = (real_t)(0.0000000000000000e+00);
a[6] = (real_t)(0.0000000000000000e+00);
a[7] = (real_t)(0.0000000000000000e+00);
a[8] = (real_t)(0.0000000000000000e+00);
a[9] = (real_t)(0.0000000000000000e+00);
a[10] = (real_t)(0.0000000000000000e+00);
a[11] = (real_t)(0.0000000000000000e+00);
a[12] = (real_t)(0.0000000000000000e+00);
a[13] = (real_t)(0.0000000000000000e+00);
a[14] = (real_t)(0.0000000000000000e+00);
a[15] = (real_t)(0.0000000000000000e+00);
a[16] = (real_t)(0.0000000000000000e+00);
a[17] = (real_t)(0.0000000000000000e+00);
a[18] = (real_t)(0.0000000000000000e+00);
a[19] = (real_t)(0.0000000000000000e+00);
a[20] = (real_t)(0.0000000000000000e+00);
a[21] = (real_t)(0.0000000000000000e+00);
a[22] = (real_t)(0.0000000000000000e+00);
a[23] = (real_t)(0.0000000000000000e+00);
a[24] = (real_t)(0.0000000000000000e+00);
a[25] = (real_t)(0.0000000000000000e+00);
a[26] = (real_t)(0.0000000000000000e+00);
a[27] = (real_t)(0.0000000000000000e+00);
a[28] = (real_t)(0.0000000000000000e+00);
a[29] = (real_t)(0.0000000000000000e+00);
a[30] = (real_t)(0.0000000000000000e+00);
a[31] = (real_t)(0.0000000000000000e+00);
a[32] = (real_t)(0.0000000000000000e+00);
a[33] = (real_t)(0.0000000000000000e+00);
a[34] = (real_t)(0.0000000000000000e+00);
a[35] = (real_t)(0.0000000000000000e+00);
a[36] = ((real_t)(2.6845637583892619e+00)/xd[8]);
a[37] = (real_t)(-1.0000000000000000e+00);
a[38] = (a[36]*a[37]);
a[39] = (real_t)(0.0000000000000000e+00);
a[40] = ((real_t)(1.0000000000000000e+00)/xd[8]);
a[41] = (a[40]*a[40]);
a[42] = ((real_t)(-1.0000000000000000e+00)*a[41]);
a[43] = (a[42]*(real_t)(2.6845637583892619e+00));
a[44] = (a[43]*xd[6]);
a[45] = (a[44]*a[37]);
a[46] = (real_t)(0.0000000000000000e+00);
a[47] = (real_t)(0.0000000000000000e+00);
a[48] = (real_t)(0.0000000000000000e+00);
a[49] = (real_t)(0.0000000000000000e+00);
a[50] = (real_t)(0.0000000000000000e+00);
a[51] = (real_t)(0.0000000000000000e+00);
a[52] = (real_t)(0.0000000000000000e+00);
a[53] = (real_t)(0.0000000000000000e+00);
a[54] = (real_t)(0.0000000000000000e+00);
a[55] = (real_t)(0.0000000000000000e+00);
a[56] = (real_t)(0.0000000000000000e+00);
a[57] = (real_t)(0.0000000000000000e+00);
a[58] = (real_t)(0.0000000000000000e+00);
a[59] = (real_t)(0.0000000000000000e+00);
a[60] = (real_t)(0.0000000000000000e+00);
a[61] = (real_t)(0.0000000000000000e+00);
a[62] = (real_t)(0.0000000000000000e+00);
a[63] = (real_t)(-1.0000000000000000e+00);
a[64] = (real_t)(0.0000000000000000e+00);
a[65] = (real_t)(-1.0000000000000000e+00);
a[66] = (real_t)(0.0000000000000000e+00);
a[67] = (real_t)(0.0000000000000000e+00);
a[68] = (real_t)(-1.0000000000000000e+00);
a[69] = (real_t)(0.0000000000000000e+00);
a[70] = (real_t)(1.0000000000000000e+00);

/* Compute outputs: */
out[0] = a[0];
out[1] = a[1];
out[2] = a[3];
out[3] = u[1];
out[4] = a[4];
out[5] = a[5];
out[6] = a[6];
out[7] = a[7];
out[8] = a[8];
out[9] = a[9];
out[10] = a[10];
out[11] = a[11];
out[12] = a[12];
out[13] = a[13];
out[14] = a[14];
out[15] = a[15];
out[16] = a[16];
out[17] = a[17];
out[18] = a[18];
out[19] = a[19];
out[20] = a[20];
out[21] = a[21];
out[22] = a[22];
out[23] = a[23];
out[24] = a[24];
out[25] = a[25];
out[26] = a[26];
out[27] = a[27];
out[28] = a[28];
out[29] = a[29];
out[30] = a[30];
out[31] = a[31];
out[32] = a[32];
out[33] = a[33];
out[34] = a[34];
out[35] = a[35];
out[36] = a[38];
out[37] = a[39];
out[38] = a[45];
out[39] = a[46];
out[40] = a[47];
out[41] = a[48];
out[42] = a[49];
out[43] = a[50];
out[44] = a[51];
out[45] = a[52];
out[46] = a[53];
out[47] = a[54];
out[48] = a[55];
out[49] = a[56];
out[50] = a[57];
out[51] = a[58];
out[52] = a[59];
out[53] = a[60];
out[54] = a[61];
out[55] = a[62];
out[56] = a[63];
out[57] = a[64];
out[58] = a[65];
out[59] = a[66];
out[60] = a[67];
out[61] = a[68];
out[62] = a[69];
out[63] = a[70];
}

void acado_setObjQ1Q2( real_t* const tmpFx, real_t* const tmpObjS, real_t* const tmpQ1, real_t* const tmpQ2 )
{
tmpQ2[0] = + tmpFx[0]*tmpObjS[0] + tmpFx[13]*tmpObjS[4] + tmpFx[26]*tmpObjS[8] + tmpFx[39]*tmpObjS[12];
tmpQ2[1] = + tmpFx[0]*tmpObjS[1] + tmpFx[13]*tmpObjS[5] + tmpFx[26]*tmpObjS[9] + tmpFx[39]*tmpObjS[13];
tmpQ2[2] = + tmpFx[0]*tmpObjS[2] + tmpFx[13]*tmpObjS[6] + tmpFx[26]*tmpObjS[10] + tmpFx[39]*tmpObjS[14];
tmpQ2[3] = + tmpFx[0]*tmpObjS[3] + tmpFx[13]*tmpObjS[7] + tmpFx[26]*tmpObjS[11] + tmpFx[39]*tmpObjS[15];
tmpQ2[4] = + tmpFx[1]*tmpObjS[0] + tmpFx[14]*tmpObjS[4] + tmpFx[27]*tmpObjS[8] + tmpFx[40]*tmpObjS[12];
tmpQ2[5] = + tmpFx[1]*tmpObjS[1] + tmpFx[14]*tmpObjS[5] + tmpFx[27]*tmpObjS[9] + tmpFx[40]*tmpObjS[13];
tmpQ2[6] = + tmpFx[1]*tmpObjS[2] + tmpFx[14]*tmpObjS[6] + tmpFx[27]*tmpObjS[10] + tmpFx[40]*tmpObjS[14];
tmpQ2[7] = + tmpFx[1]*tmpObjS[3] + tmpFx[14]*tmpObjS[7] + tmpFx[27]*tmpObjS[11] + tmpFx[40]*tmpObjS[15];
tmpQ2[8] = + tmpFx[2]*tmpObjS[0] + tmpFx[15]*tmpObjS[4] + tmpFx[28]*tmpObjS[8] + tmpFx[41]*tmpObjS[12];
tmpQ2[9] = + tmpFx[2]*tmpObjS[1] + tmpFx[15]*tmpObjS[5] + tmpFx[28]*tmpObjS[9] + tmpFx[41]*tmpObjS[13];
tmpQ2[10] = + tmpFx[2]*tmpObjS[2] + tmpFx[15]*tmpObjS[6] + tmpFx[28]*tmpObjS[10] + tmpFx[41]*tmpObjS[14];
tmpQ2[11] = + tmpFx[2]*tmpObjS[3] + tmpFx[15]*tmpObjS[7] + tmpFx[28]*tmpObjS[11] + tmpFx[41]*tmpObjS[15];
tmpQ2[12] = + tmpFx[3]*tmpObjS[0] + tmpFx[16]*tmpObjS[4] + tmpFx[29]*tmpObjS[8] + tmpFx[42]*tmpObjS[12];
tmpQ2[13] = + tmpFx[3]*tmpObjS[1] + tmpFx[16]*tmpObjS[5] + tmpFx[29]*tmpObjS[9] + tmpFx[42]*tmpObjS[13];
tmpQ2[14] = + tmpFx[3]*tmpObjS[2] + tmpFx[16]*tmpObjS[6] + tmpFx[29]*tmpObjS[10] + tmpFx[42]*tmpObjS[14];
tmpQ2[15] = + tmpFx[3]*tmpObjS[3] + tmpFx[16]*tmpObjS[7] + tmpFx[29]*tmpObjS[11] + tmpFx[42]*tmpObjS[15];
tmpQ2[16] = + tmpFx[4]*tmpObjS[0] + tmpFx[17]*tmpObjS[4] + tmpFx[30]*tmpObjS[8] + tmpFx[43]*tmpObjS[12];
tmpQ2[17] = + tmpFx[4]*tmpObjS[1] + tmpFx[17]*tmpObjS[5] + tmpFx[30]*tmpObjS[9] + tmpFx[43]*tmpObjS[13];
tmpQ2[18] = + tmpFx[4]*tmpObjS[2] + tmpFx[17]*tmpObjS[6] + tmpFx[30]*tmpObjS[10] + tmpFx[43]*tmpObjS[14];
tmpQ2[19] = + tmpFx[4]*tmpObjS[3] + tmpFx[17]*tmpObjS[7] + tmpFx[30]*tmpObjS[11] + tmpFx[43]*tmpObjS[15];
tmpQ2[20] = + tmpFx[5]*tmpObjS[0] + tmpFx[18]*tmpObjS[4] + tmpFx[31]*tmpObjS[8] + tmpFx[44]*tmpObjS[12];
tmpQ2[21] = + tmpFx[5]*tmpObjS[1] + tmpFx[18]*tmpObjS[5] + tmpFx[31]*tmpObjS[9] + tmpFx[44]*tmpObjS[13];
tmpQ2[22] = + tmpFx[5]*tmpObjS[2] + tmpFx[18]*tmpObjS[6] + tmpFx[31]*tmpObjS[10] + tmpFx[44]*tmpObjS[14];
tmpQ2[23] = + tmpFx[5]*tmpObjS[3] + tmpFx[18]*tmpObjS[7] + tmpFx[31]*tmpObjS[11] + tmpFx[44]*tmpObjS[15];
tmpQ2[24] = + tmpFx[6]*tmpObjS[0] + tmpFx[19]*tmpObjS[4] + tmpFx[32]*tmpObjS[8] + tmpFx[45]*tmpObjS[12];
tmpQ2[25] = + tmpFx[6]*tmpObjS[1] + tmpFx[19]*tmpObjS[5] + tmpFx[32]*tmpObjS[9] + tmpFx[45]*tmpObjS[13];
tmpQ2[26] = + tmpFx[6]*tmpObjS[2] + tmpFx[19]*tmpObjS[6] + tmpFx[32]*tmpObjS[10] + tmpFx[45]*tmpObjS[14];
tmpQ2[27] = + tmpFx[6]*tmpObjS[3] + tmpFx[19]*tmpObjS[7] + tmpFx[32]*tmpObjS[11] + tmpFx[45]*tmpObjS[15];
tmpQ2[28] = + tmpFx[7]*tmpObjS[0] + tmpFx[20]*tmpObjS[4] + tmpFx[33]*tmpObjS[8] + tmpFx[46]*tmpObjS[12];
tmpQ2[29] = + tmpFx[7]*tmpObjS[1] + tmpFx[20]*tmpObjS[5] + tmpFx[33]*tmpObjS[9] + tmpFx[46]*tmpObjS[13];
tmpQ2[30] = + tmpFx[7]*tmpObjS[2] + tmpFx[20]*tmpObjS[6] + tmpFx[33]*tmpObjS[10] + tmpFx[46]*tmpObjS[14];
tmpQ2[31] = + tmpFx[7]*tmpObjS[3] + tmpFx[20]*tmpObjS[7] + tmpFx[33]*tmpObjS[11] + tmpFx[46]*tmpObjS[15];
tmpQ2[32] = + tmpFx[8]*tmpObjS[0] + tmpFx[21]*tmpObjS[4] + tmpFx[34]*tmpObjS[8] + tmpFx[47]*tmpObjS[12];
tmpQ2[33] = + tmpFx[8]*tmpObjS[1] + tmpFx[21]*tmpObjS[5] + tmpFx[34]*tmpObjS[9] + tmpFx[47]*tmpObjS[13];
tmpQ2[34] = + tmpFx[8]*tmpObjS[2] + tmpFx[21]*tmpObjS[6] + tmpFx[34]*tmpObjS[10] + tmpFx[47]*tmpObjS[14];
tmpQ2[35] = + tmpFx[8]*tmpObjS[3] + tmpFx[21]*tmpObjS[7] + tmpFx[34]*tmpObjS[11] + tmpFx[47]*tmpObjS[15];
tmpQ2[36] = + tmpFx[9]*tmpObjS[0] + tmpFx[22]*tmpObjS[4] + tmpFx[35]*tmpObjS[8] + tmpFx[48]*tmpObjS[12];
tmpQ2[37] = + tmpFx[9]*tmpObjS[1] + tmpFx[22]*tmpObjS[5] + tmpFx[35]*tmpObjS[9] + tmpFx[48]*tmpObjS[13];
tmpQ2[38] = + tmpFx[9]*tmpObjS[2] + tmpFx[22]*tmpObjS[6] + tmpFx[35]*tmpObjS[10] + tmpFx[48]*tmpObjS[14];
tmpQ2[39] = + tmpFx[9]*tmpObjS[3] + tmpFx[22]*tmpObjS[7] + tmpFx[35]*tmpObjS[11] + tmpFx[48]*tmpObjS[15];
tmpQ2[40] = + tmpFx[10]*tmpObjS[0] + tmpFx[23]*tmpObjS[4] + tmpFx[36]*tmpObjS[8] + tmpFx[49]*tmpObjS[12];
tmpQ2[41] = + tmpFx[10]*tmpObjS[1] + tmpFx[23]*tmpObjS[5] + tmpFx[36]*tmpObjS[9] + tmpFx[49]*tmpObjS[13];
tmpQ2[42] = + tmpFx[10]*tmpObjS[2] + tmpFx[23]*tmpObjS[6] + tmpFx[36]*tmpObjS[10] + tmpFx[49]*tmpObjS[14];
tmpQ2[43] = + tmpFx[10]*tmpObjS[3] + tmpFx[23]*tmpObjS[7] + tmpFx[36]*tmpObjS[11] + tmpFx[49]*tmpObjS[15];
tmpQ2[44] = + tmpFx[11]*tmpObjS[0] + tmpFx[24]*tmpObjS[4] + tmpFx[37]*tmpObjS[8] + tmpFx[50]*tmpObjS[12];
tmpQ2[45] = + tmpFx[11]*tmpObjS[1] + tmpFx[24]*tmpObjS[5] + tmpFx[37]*tmpObjS[9] + tmpFx[50]*tmpObjS[13];
tmpQ2[46] = + tmpFx[11]*tmpObjS[2] + tmpFx[24]*tmpObjS[6] + tmpFx[37]*tmpObjS[10] + tmpFx[50]*tmpObjS[14];
tmpQ2[47] = + tmpFx[11]*tmpObjS[3] + tmpFx[24]*tmpObjS[7] + tmpFx[37]*tmpObjS[11] + tmpFx[50]*tmpObjS[15];
tmpQ2[48] = + tmpFx[12]*tmpObjS[0] + tmpFx[25]*tmpObjS[4] + tmpFx[38]*tmpObjS[8] + tmpFx[51]*tmpObjS[12];
tmpQ2[49] = + tmpFx[12]*tmpObjS[1] + tmpFx[25]*tmpObjS[5] + tmpFx[38]*tmpObjS[9] + tmpFx[51]*tmpObjS[13];
tmpQ2[50] = + tmpFx[12]*tmpObjS[2] + tmpFx[25]*tmpObjS[6] + tmpFx[38]*tmpObjS[10] + tmpFx[51]*tmpObjS[14];
tmpQ2[51] = + tmpFx[12]*tmpObjS[3] + tmpFx[25]*tmpObjS[7] + tmpFx[38]*tmpObjS[11] + tmpFx[51]*tmpObjS[15];
tmpQ1[0] = + tmpQ2[0]*tmpFx[0] + tmpQ2[1]*tmpFx[13] + tmpQ2[2]*tmpFx[26] + tmpQ2[3]*tmpFx[39];
tmpQ1[1] = + tmpQ2[0]*tmpFx[1] + tmpQ2[1]*tmpFx[14] + tmpQ2[2]*tmpFx[27] + tmpQ2[3]*tmpFx[40];
tmpQ1[2] = + tmpQ2[0]*tmpFx[2] + tmpQ2[1]*tmpFx[15] + tmpQ2[2]*tmpFx[28] + tmpQ2[3]*tmpFx[41];
tmpQ1[3] = + tmpQ2[0]*tmpFx[3] + tmpQ2[1]*tmpFx[16] + tmpQ2[2]*tmpFx[29] + tmpQ2[3]*tmpFx[42];
tmpQ1[4] = + tmpQ2[0]*tmpFx[4] + tmpQ2[1]*tmpFx[17] + tmpQ2[2]*tmpFx[30] + tmpQ2[3]*tmpFx[43];
tmpQ1[5] = + tmpQ2[0]*tmpFx[5] + tmpQ2[1]*tmpFx[18] + tmpQ2[2]*tmpFx[31] + tmpQ2[3]*tmpFx[44];
tmpQ1[6] = + tmpQ2[0]*tmpFx[6] + tmpQ2[1]*tmpFx[19] + tmpQ2[2]*tmpFx[32] + tmpQ2[3]*tmpFx[45];
tmpQ1[7] = + tmpQ2[0]*tmpFx[7] + tmpQ2[1]*tmpFx[20] + tmpQ2[2]*tmpFx[33] + tmpQ2[3]*tmpFx[46];
tmpQ1[8] = + tmpQ2[0]*tmpFx[8] + tmpQ2[1]*tmpFx[21] + tmpQ2[2]*tmpFx[34] + tmpQ2[3]*tmpFx[47];
tmpQ1[9] = + tmpQ2[0]*tmpFx[9] + tmpQ2[1]*tmpFx[22] + tmpQ2[2]*tmpFx[35] + tmpQ2[3]*tmpFx[48];
tmpQ1[10] = + tmpQ2[0]*tmpFx[10] + tmpQ2[1]*tmpFx[23] + tmpQ2[2]*tmpFx[36] + tmpQ2[3]*tmpFx[49];
tmpQ1[11] = + tmpQ2[0]*tmpFx[11] + tmpQ2[1]*tmpFx[24] + tmpQ2[2]*tmpFx[37] + tmpQ2[3]*tmpFx[50];
tmpQ1[12] = + tmpQ2[0]*tmpFx[12] + tmpQ2[1]*tmpFx[25] + tmpQ2[2]*tmpFx[38] + tmpQ2[3]*tmpFx[51];
tmpQ1[13] = + tmpQ2[4]*tmpFx[0] + tmpQ2[5]*tmpFx[13] + tmpQ2[6]*tmpFx[26] + tmpQ2[7]*tmpFx[39];
tmpQ1[14] = + tmpQ2[4]*tmpFx[1] + tmpQ2[5]*tmpFx[14] + tmpQ2[6]*tmpFx[27] + tmpQ2[7]*tmpFx[40];
tmpQ1[15] = + tmpQ2[4]*tmpFx[2] + tmpQ2[5]*tmpFx[15] + tmpQ2[6]*tmpFx[28] + tmpQ2[7]*tmpFx[41];
tmpQ1[16] = + tmpQ2[4]*tmpFx[3] + tmpQ2[5]*tmpFx[16] + tmpQ2[6]*tmpFx[29] + tmpQ2[7]*tmpFx[42];
tmpQ1[17] = + tmpQ2[4]*tmpFx[4] + tmpQ2[5]*tmpFx[17] + tmpQ2[6]*tmpFx[30] + tmpQ2[7]*tmpFx[43];
tmpQ1[18] = + tmpQ2[4]*tmpFx[5] + tmpQ2[5]*tmpFx[18] + tmpQ2[6]*tmpFx[31] + tmpQ2[7]*tmpFx[44];
tmpQ1[19] = + tmpQ2[4]*tmpFx[6] + tmpQ2[5]*tmpFx[19] + tmpQ2[6]*tmpFx[32] + tmpQ2[7]*tmpFx[45];
tmpQ1[20] = + tmpQ2[4]*tmpFx[7] + tmpQ2[5]*tmpFx[20] + tmpQ2[6]*tmpFx[33] + tmpQ2[7]*tmpFx[46];
tmpQ1[21] = + tmpQ2[4]*tmpFx[8] + tmpQ2[5]*tmpFx[21] + tmpQ2[6]*tmpFx[34] + tmpQ2[7]*tmpFx[47];
tmpQ1[22] = + tmpQ2[4]*tmpFx[9] + tmpQ2[5]*tmpFx[22] + tmpQ2[6]*tmpFx[35] + tmpQ2[7]*tmpFx[48];
tmpQ1[23] = + tmpQ2[4]*tmpFx[10] + tmpQ2[5]*tmpFx[23] + tmpQ2[6]*tmpFx[36] + tmpQ2[7]*tmpFx[49];
tmpQ1[24] = + tmpQ2[4]*tmpFx[11] + tmpQ2[5]*tmpFx[24] + tmpQ2[6]*tmpFx[37] + tmpQ2[7]*tmpFx[50];
tmpQ1[25] = + tmpQ2[4]*tmpFx[12] + tmpQ2[5]*tmpFx[25] + tmpQ2[6]*tmpFx[38] + tmpQ2[7]*tmpFx[51];
tmpQ1[26] = + tmpQ2[8]*tmpFx[0] + tmpQ2[9]*tmpFx[13] + tmpQ2[10]*tmpFx[26] + tmpQ2[11]*tmpFx[39];
tmpQ1[27] = + tmpQ2[8]*tmpFx[1] + tmpQ2[9]*tmpFx[14] + tmpQ2[10]*tmpFx[27] + tmpQ2[11]*tmpFx[40];
tmpQ1[28] = + tmpQ2[8]*tmpFx[2] + tmpQ2[9]*tmpFx[15] + tmpQ2[10]*tmpFx[28] + tmpQ2[11]*tmpFx[41];
tmpQ1[29] = + tmpQ2[8]*tmpFx[3] + tmpQ2[9]*tmpFx[16] + tmpQ2[10]*tmpFx[29] + tmpQ2[11]*tmpFx[42];
tmpQ1[30] = + tmpQ2[8]*tmpFx[4] + tmpQ2[9]*tmpFx[17] + tmpQ2[10]*tmpFx[30] + tmpQ2[11]*tmpFx[43];
tmpQ1[31] = + tmpQ2[8]*tmpFx[5] + tmpQ2[9]*tmpFx[18] + tmpQ2[10]*tmpFx[31] + tmpQ2[11]*tmpFx[44];
tmpQ1[32] = + tmpQ2[8]*tmpFx[6] + tmpQ2[9]*tmpFx[19] + tmpQ2[10]*tmpFx[32] + tmpQ2[11]*tmpFx[45];
tmpQ1[33] = + tmpQ2[8]*tmpFx[7] + tmpQ2[9]*tmpFx[20] + tmpQ2[10]*tmpFx[33] + tmpQ2[11]*tmpFx[46];
tmpQ1[34] = + tmpQ2[8]*tmpFx[8] + tmpQ2[9]*tmpFx[21] + tmpQ2[10]*tmpFx[34] + tmpQ2[11]*tmpFx[47];
tmpQ1[35] = + tmpQ2[8]*tmpFx[9] + tmpQ2[9]*tmpFx[22] + tmpQ2[10]*tmpFx[35] + tmpQ2[11]*tmpFx[48];
tmpQ1[36] = + tmpQ2[8]*tmpFx[10] + tmpQ2[9]*tmpFx[23] + tmpQ2[10]*tmpFx[36] + tmpQ2[11]*tmpFx[49];
tmpQ1[37] = + tmpQ2[8]*tmpFx[11] + tmpQ2[9]*tmpFx[24] + tmpQ2[10]*tmpFx[37] + tmpQ2[11]*tmpFx[50];
tmpQ1[38] = + tmpQ2[8]*tmpFx[12] + tmpQ2[9]*tmpFx[25] + tmpQ2[10]*tmpFx[38] + tmpQ2[11]*tmpFx[51];
tmpQ1[39] = + tmpQ2[12]*tmpFx[0] + tmpQ2[13]*tmpFx[13] + tmpQ2[14]*tmpFx[26] + tmpQ2[15]*tmpFx[39];
tmpQ1[40] = + tmpQ2[12]*tmpFx[1] + tmpQ2[13]*tmpFx[14] + tmpQ2[14]*tmpFx[27] + tmpQ2[15]*tmpFx[40];
tmpQ1[41] = + tmpQ2[12]*tmpFx[2] + tmpQ2[13]*tmpFx[15] + tmpQ2[14]*tmpFx[28] + tmpQ2[15]*tmpFx[41];
tmpQ1[42] = + tmpQ2[12]*tmpFx[3] + tmpQ2[13]*tmpFx[16] + tmpQ2[14]*tmpFx[29] + tmpQ2[15]*tmpFx[42];
tmpQ1[43] = + tmpQ2[12]*tmpFx[4] + tmpQ2[13]*tmpFx[17] + tmpQ2[14]*tmpFx[30] + tmpQ2[15]*tmpFx[43];
tmpQ1[44] = + tmpQ2[12]*tmpFx[5] + tmpQ2[13]*tmpFx[18] + tmpQ2[14]*tmpFx[31] + tmpQ2[15]*tmpFx[44];
tmpQ1[45] = + tmpQ2[12]*tmpFx[6] + tmpQ2[13]*tmpFx[19] + tmpQ2[14]*tmpFx[32] + tmpQ2[15]*tmpFx[45];
tmpQ1[46] = + tmpQ2[12]*tmpFx[7] + tmpQ2[13]*tmpFx[20] + tmpQ2[14]*tmpFx[33] + tmpQ2[15]*tmpFx[46];
tmpQ1[47] = + tmpQ2[12]*tmpFx[8] + tmpQ2[13]*tmpFx[21] + tmpQ2[14]*tmpFx[34] + tmpQ2[15]*tmpFx[47];
tmpQ1[48] = + tmpQ2[12]*tmpFx[9] + tmpQ2[13]*tmpFx[22] + tmpQ2[14]*tmpFx[35] + tmpQ2[15]*tmpFx[48];
tmpQ1[49] = + tmpQ2[12]*tmpFx[10] + tmpQ2[13]*tmpFx[23] + tmpQ2[14]*tmpFx[36] + tmpQ2[15]*tmpFx[49];
tmpQ1[50] = + tmpQ2[12]*tmpFx[11] + tmpQ2[13]*tmpFx[24] + tmpQ2[14]*tmpFx[37] + tmpQ2[15]*tmpFx[50];
tmpQ1[51] = + tmpQ2[12]*tmpFx[12] + tmpQ2[13]*tmpFx[25] + tmpQ2[14]*tmpFx[38] + tmpQ2[15]*tmpFx[51];
tmpQ1[52] = + tmpQ2[16]*tmpFx[0] + tmpQ2[17]*tmpFx[13] + tmpQ2[18]*tmpFx[26] + tmpQ2[19]*tmpFx[39];
tmpQ1[53] = + tmpQ2[16]*tmpFx[1] + tmpQ2[17]*tmpFx[14] + tmpQ2[18]*tmpFx[27] + tmpQ2[19]*tmpFx[40];
tmpQ1[54] = + tmpQ2[16]*tmpFx[2] + tmpQ2[17]*tmpFx[15] + tmpQ2[18]*tmpFx[28] + tmpQ2[19]*tmpFx[41];
tmpQ1[55] = + tmpQ2[16]*tmpFx[3] + tmpQ2[17]*tmpFx[16] + tmpQ2[18]*tmpFx[29] + tmpQ2[19]*tmpFx[42];
tmpQ1[56] = + tmpQ2[16]*tmpFx[4] + tmpQ2[17]*tmpFx[17] + tmpQ2[18]*tmpFx[30] + tmpQ2[19]*tmpFx[43];
tmpQ1[57] = + tmpQ2[16]*tmpFx[5] + tmpQ2[17]*tmpFx[18] + tmpQ2[18]*tmpFx[31] + tmpQ2[19]*tmpFx[44];
tmpQ1[58] = + tmpQ2[16]*tmpFx[6] + tmpQ2[17]*tmpFx[19] + tmpQ2[18]*tmpFx[32] + tmpQ2[19]*tmpFx[45];
tmpQ1[59] = + tmpQ2[16]*tmpFx[7] + tmpQ2[17]*tmpFx[20] + tmpQ2[18]*tmpFx[33] + tmpQ2[19]*tmpFx[46];
tmpQ1[60] = + tmpQ2[16]*tmpFx[8] + tmpQ2[17]*tmpFx[21] + tmpQ2[18]*tmpFx[34] + tmpQ2[19]*tmpFx[47];
tmpQ1[61] = + tmpQ2[16]*tmpFx[9] + tmpQ2[17]*tmpFx[22] + tmpQ2[18]*tmpFx[35] + tmpQ2[19]*tmpFx[48];
tmpQ1[62] = + tmpQ2[16]*tmpFx[10] + tmpQ2[17]*tmpFx[23] + tmpQ2[18]*tmpFx[36] + tmpQ2[19]*tmpFx[49];
tmpQ1[63] = + tmpQ2[16]*tmpFx[11] + tmpQ2[17]*tmpFx[24] + tmpQ2[18]*tmpFx[37] + tmpQ2[19]*tmpFx[50];
tmpQ1[64] = + tmpQ2[16]*tmpFx[12] + tmpQ2[17]*tmpFx[25] + tmpQ2[18]*tmpFx[38] + tmpQ2[19]*tmpFx[51];
tmpQ1[65] = + tmpQ2[20]*tmpFx[0] + tmpQ2[21]*tmpFx[13] + tmpQ2[22]*tmpFx[26] + tmpQ2[23]*tmpFx[39];
tmpQ1[66] = + tmpQ2[20]*tmpFx[1] + tmpQ2[21]*tmpFx[14] + tmpQ2[22]*tmpFx[27] + tmpQ2[23]*tmpFx[40];
tmpQ1[67] = + tmpQ2[20]*tmpFx[2] + tmpQ2[21]*tmpFx[15] + tmpQ2[22]*tmpFx[28] + tmpQ2[23]*tmpFx[41];
tmpQ1[68] = + tmpQ2[20]*tmpFx[3] + tmpQ2[21]*tmpFx[16] + tmpQ2[22]*tmpFx[29] + tmpQ2[23]*tmpFx[42];
tmpQ1[69] = + tmpQ2[20]*tmpFx[4] + tmpQ2[21]*tmpFx[17] + tmpQ2[22]*tmpFx[30] + tmpQ2[23]*tmpFx[43];
tmpQ1[70] = + tmpQ2[20]*tmpFx[5] + tmpQ2[21]*tmpFx[18] + tmpQ2[22]*tmpFx[31] + tmpQ2[23]*tmpFx[44];
tmpQ1[71] = + tmpQ2[20]*tmpFx[6] + tmpQ2[21]*tmpFx[19] + tmpQ2[22]*tmpFx[32] + tmpQ2[23]*tmpFx[45];
tmpQ1[72] = + tmpQ2[20]*tmpFx[7] + tmpQ2[21]*tmpFx[20] + tmpQ2[22]*tmpFx[33] + tmpQ2[23]*tmpFx[46];
tmpQ1[73] = + tmpQ2[20]*tmpFx[8] + tmpQ2[21]*tmpFx[21] + tmpQ2[22]*tmpFx[34] + tmpQ2[23]*tmpFx[47];
tmpQ1[74] = + tmpQ2[20]*tmpFx[9] + tmpQ2[21]*tmpFx[22] + tmpQ2[22]*tmpFx[35] + tmpQ2[23]*tmpFx[48];
tmpQ1[75] = + tmpQ2[20]*tmpFx[10] + tmpQ2[21]*tmpFx[23] + tmpQ2[22]*tmpFx[36] + tmpQ2[23]*tmpFx[49];
tmpQ1[76] = + tmpQ2[20]*tmpFx[11] + tmpQ2[21]*tmpFx[24] + tmpQ2[22]*tmpFx[37] + tmpQ2[23]*tmpFx[50];
tmpQ1[77] = + tmpQ2[20]*tmpFx[12] + tmpQ2[21]*tmpFx[25] + tmpQ2[22]*tmpFx[38] + tmpQ2[23]*tmpFx[51];
tmpQ1[78] = + tmpQ2[24]*tmpFx[0] + tmpQ2[25]*tmpFx[13] + tmpQ2[26]*tmpFx[26] + tmpQ2[27]*tmpFx[39];
tmpQ1[79] = + tmpQ2[24]*tmpFx[1] + tmpQ2[25]*tmpFx[14] + tmpQ2[26]*tmpFx[27] + tmpQ2[27]*tmpFx[40];
tmpQ1[80] = + tmpQ2[24]*tmpFx[2] + tmpQ2[25]*tmpFx[15] + tmpQ2[26]*tmpFx[28] + tmpQ2[27]*tmpFx[41];
tmpQ1[81] = + tmpQ2[24]*tmpFx[3] + tmpQ2[25]*tmpFx[16] + tmpQ2[26]*tmpFx[29] + tmpQ2[27]*tmpFx[42];
tmpQ1[82] = + tmpQ2[24]*tmpFx[4] + tmpQ2[25]*tmpFx[17] + tmpQ2[26]*tmpFx[30] + tmpQ2[27]*tmpFx[43];
tmpQ1[83] = + tmpQ2[24]*tmpFx[5] + tmpQ2[25]*tmpFx[18] + tmpQ2[26]*tmpFx[31] + tmpQ2[27]*tmpFx[44];
tmpQ1[84] = + tmpQ2[24]*tmpFx[6] + tmpQ2[25]*tmpFx[19] + tmpQ2[26]*tmpFx[32] + tmpQ2[27]*tmpFx[45];
tmpQ1[85] = + tmpQ2[24]*tmpFx[7] + tmpQ2[25]*tmpFx[20] + tmpQ2[26]*tmpFx[33] + tmpQ2[27]*tmpFx[46];
tmpQ1[86] = + tmpQ2[24]*tmpFx[8] + tmpQ2[25]*tmpFx[21] + tmpQ2[26]*tmpFx[34] + tmpQ2[27]*tmpFx[47];
tmpQ1[87] = + tmpQ2[24]*tmpFx[9] + tmpQ2[25]*tmpFx[22] + tmpQ2[26]*tmpFx[35] + tmpQ2[27]*tmpFx[48];
tmpQ1[88] = + tmpQ2[24]*tmpFx[10] + tmpQ2[25]*tmpFx[23] + tmpQ2[26]*tmpFx[36] + tmpQ2[27]*tmpFx[49];
tmpQ1[89] = + tmpQ2[24]*tmpFx[11] + tmpQ2[25]*tmpFx[24] + tmpQ2[26]*tmpFx[37] + tmpQ2[27]*tmpFx[50];
tmpQ1[90] = + tmpQ2[24]*tmpFx[12] + tmpQ2[25]*tmpFx[25] + tmpQ2[26]*tmpFx[38] + tmpQ2[27]*tmpFx[51];
tmpQ1[91] = + tmpQ2[28]*tmpFx[0] + tmpQ2[29]*tmpFx[13] + tmpQ2[30]*tmpFx[26] + tmpQ2[31]*tmpFx[39];
tmpQ1[92] = + tmpQ2[28]*tmpFx[1] + tmpQ2[29]*tmpFx[14] + tmpQ2[30]*tmpFx[27] + tmpQ2[31]*tmpFx[40];
tmpQ1[93] = + tmpQ2[28]*tmpFx[2] + tmpQ2[29]*tmpFx[15] + tmpQ2[30]*tmpFx[28] + tmpQ2[31]*tmpFx[41];
tmpQ1[94] = + tmpQ2[28]*tmpFx[3] + tmpQ2[29]*tmpFx[16] + tmpQ2[30]*tmpFx[29] + tmpQ2[31]*tmpFx[42];
tmpQ1[95] = + tmpQ2[28]*tmpFx[4] + tmpQ2[29]*tmpFx[17] + tmpQ2[30]*tmpFx[30] + tmpQ2[31]*tmpFx[43];
tmpQ1[96] = + tmpQ2[28]*tmpFx[5] + tmpQ2[29]*tmpFx[18] + tmpQ2[30]*tmpFx[31] + tmpQ2[31]*tmpFx[44];
tmpQ1[97] = + tmpQ2[28]*tmpFx[6] + tmpQ2[29]*tmpFx[19] + tmpQ2[30]*tmpFx[32] + tmpQ2[31]*tmpFx[45];
tmpQ1[98] = + tmpQ2[28]*tmpFx[7] + tmpQ2[29]*tmpFx[20] + tmpQ2[30]*tmpFx[33] + tmpQ2[31]*tmpFx[46];
tmpQ1[99] = + tmpQ2[28]*tmpFx[8] + tmpQ2[29]*tmpFx[21] + tmpQ2[30]*tmpFx[34] + tmpQ2[31]*tmpFx[47];
tmpQ1[100] = + tmpQ2[28]*tmpFx[9] + tmpQ2[29]*tmpFx[22] + tmpQ2[30]*tmpFx[35] + tmpQ2[31]*tmpFx[48];
tmpQ1[101] = + tmpQ2[28]*tmpFx[10] + tmpQ2[29]*tmpFx[23] + tmpQ2[30]*tmpFx[36] + tmpQ2[31]*tmpFx[49];
tmpQ1[102] = + tmpQ2[28]*tmpFx[11] + tmpQ2[29]*tmpFx[24] + tmpQ2[30]*tmpFx[37] + tmpQ2[31]*tmpFx[50];
tmpQ1[103] = + tmpQ2[28]*tmpFx[12] + tmpQ2[29]*tmpFx[25] + tmpQ2[30]*tmpFx[38] + tmpQ2[31]*tmpFx[51];
tmpQ1[104] = + tmpQ2[32]*tmpFx[0] + tmpQ2[33]*tmpFx[13] + tmpQ2[34]*tmpFx[26] + tmpQ2[35]*tmpFx[39];
tmpQ1[105] = + tmpQ2[32]*tmpFx[1] + tmpQ2[33]*tmpFx[14] + tmpQ2[34]*tmpFx[27] + tmpQ2[35]*tmpFx[40];
tmpQ1[106] = + tmpQ2[32]*tmpFx[2] + tmpQ2[33]*tmpFx[15] + tmpQ2[34]*tmpFx[28] + tmpQ2[35]*tmpFx[41];
tmpQ1[107] = + tmpQ2[32]*tmpFx[3] + tmpQ2[33]*tmpFx[16] + tmpQ2[34]*tmpFx[29] + tmpQ2[35]*tmpFx[42];
tmpQ1[108] = + tmpQ2[32]*tmpFx[4] + tmpQ2[33]*tmpFx[17] + tmpQ2[34]*tmpFx[30] + tmpQ2[35]*tmpFx[43];
tmpQ1[109] = + tmpQ2[32]*tmpFx[5] + tmpQ2[33]*tmpFx[18] + tmpQ2[34]*tmpFx[31] + tmpQ2[35]*tmpFx[44];
tmpQ1[110] = + tmpQ2[32]*tmpFx[6] + tmpQ2[33]*tmpFx[19] + tmpQ2[34]*tmpFx[32] + tmpQ2[35]*tmpFx[45];
tmpQ1[111] = + tmpQ2[32]*tmpFx[7] + tmpQ2[33]*tmpFx[20] + tmpQ2[34]*tmpFx[33] + tmpQ2[35]*tmpFx[46];
tmpQ1[112] = + tmpQ2[32]*tmpFx[8] + tmpQ2[33]*tmpFx[21] + tmpQ2[34]*tmpFx[34] + tmpQ2[35]*tmpFx[47];
tmpQ1[113] = + tmpQ2[32]*tmpFx[9] + tmpQ2[33]*tmpFx[22] + tmpQ2[34]*tmpFx[35] + tmpQ2[35]*tmpFx[48];
tmpQ1[114] = + tmpQ2[32]*tmpFx[10] + tmpQ2[33]*tmpFx[23] + tmpQ2[34]*tmpFx[36] + tmpQ2[35]*tmpFx[49];
tmpQ1[115] = + tmpQ2[32]*tmpFx[11] + tmpQ2[33]*tmpFx[24] + tmpQ2[34]*tmpFx[37] + tmpQ2[35]*tmpFx[50];
tmpQ1[116] = + tmpQ2[32]*tmpFx[12] + tmpQ2[33]*tmpFx[25] + tmpQ2[34]*tmpFx[38] + tmpQ2[35]*tmpFx[51];
tmpQ1[117] = + tmpQ2[36]*tmpFx[0] + tmpQ2[37]*tmpFx[13] + tmpQ2[38]*tmpFx[26] + tmpQ2[39]*tmpFx[39];
tmpQ1[118] = + tmpQ2[36]*tmpFx[1] + tmpQ2[37]*tmpFx[14] + tmpQ2[38]*tmpFx[27] + tmpQ2[39]*tmpFx[40];
tmpQ1[119] = + tmpQ2[36]*tmpFx[2] + tmpQ2[37]*tmpFx[15] + tmpQ2[38]*tmpFx[28] + tmpQ2[39]*tmpFx[41];
tmpQ1[120] = + tmpQ2[36]*tmpFx[3] + tmpQ2[37]*tmpFx[16] + tmpQ2[38]*tmpFx[29] + tmpQ2[39]*tmpFx[42];
tmpQ1[121] = + tmpQ2[36]*tmpFx[4] + tmpQ2[37]*tmpFx[17] + tmpQ2[38]*tmpFx[30] + tmpQ2[39]*tmpFx[43];
tmpQ1[122] = + tmpQ2[36]*tmpFx[5] + tmpQ2[37]*tmpFx[18] + tmpQ2[38]*tmpFx[31] + tmpQ2[39]*tmpFx[44];
tmpQ1[123] = + tmpQ2[36]*tmpFx[6] + tmpQ2[37]*tmpFx[19] + tmpQ2[38]*tmpFx[32] + tmpQ2[39]*tmpFx[45];
tmpQ1[124] = + tmpQ2[36]*tmpFx[7] + tmpQ2[37]*tmpFx[20] + tmpQ2[38]*tmpFx[33] + tmpQ2[39]*tmpFx[46];
tmpQ1[125] = + tmpQ2[36]*tmpFx[8] + tmpQ2[37]*tmpFx[21] + tmpQ2[38]*tmpFx[34] + tmpQ2[39]*tmpFx[47];
tmpQ1[126] = + tmpQ2[36]*tmpFx[9] + tmpQ2[37]*tmpFx[22] + tmpQ2[38]*tmpFx[35] + tmpQ2[39]*tmpFx[48];
tmpQ1[127] = + tmpQ2[36]*tmpFx[10] + tmpQ2[37]*tmpFx[23] + tmpQ2[38]*tmpFx[36] + tmpQ2[39]*tmpFx[49];
tmpQ1[128] = + tmpQ2[36]*tmpFx[11] + tmpQ2[37]*tmpFx[24] + tmpQ2[38]*tmpFx[37] + tmpQ2[39]*tmpFx[50];
tmpQ1[129] = + tmpQ2[36]*tmpFx[12] + tmpQ2[37]*tmpFx[25] + tmpQ2[38]*tmpFx[38] + tmpQ2[39]*tmpFx[51];
tmpQ1[130] = + tmpQ2[40]*tmpFx[0] + tmpQ2[41]*tmpFx[13] + tmpQ2[42]*tmpFx[26] + tmpQ2[43]*tmpFx[39];
tmpQ1[131] = + tmpQ2[40]*tmpFx[1] + tmpQ2[41]*tmpFx[14] + tmpQ2[42]*tmpFx[27] + tmpQ2[43]*tmpFx[40];
tmpQ1[132] = + tmpQ2[40]*tmpFx[2] + tmpQ2[41]*tmpFx[15] + tmpQ2[42]*tmpFx[28] + tmpQ2[43]*tmpFx[41];
tmpQ1[133] = + tmpQ2[40]*tmpFx[3] + tmpQ2[41]*tmpFx[16] + tmpQ2[42]*tmpFx[29] + tmpQ2[43]*tmpFx[42];
tmpQ1[134] = + tmpQ2[40]*tmpFx[4] + tmpQ2[41]*tmpFx[17] + tmpQ2[42]*tmpFx[30] + tmpQ2[43]*tmpFx[43];
tmpQ1[135] = + tmpQ2[40]*tmpFx[5] + tmpQ2[41]*tmpFx[18] + tmpQ2[42]*tmpFx[31] + tmpQ2[43]*tmpFx[44];
tmpQ1[136] = + tmpQ2[40]*tmpFx[6] + tmpQ2[41]*tmpFx[19] + tmpQ2[42]*tmpFx[32] + tmpQ2[43]*tmpFx[45];
tmpQ1[137] = + tmpQ2[40]*tmpFx[7] + tmpQ2[41]*tmpFx[20] + tmpQ2[42]*tmpFx[33] + tmpQ2[43]*tmpFx[46];
tmpQ1[138] = + tmpQ2[40]*tmpFx[8] + tmpQ2[41]*tmpFx[21] + tmpQ2[42]*tmpFx[34] + tmpQ2[43]*tmpFx[47];
tmpQ1[139] = + tmpQ2[40]*tmpFx[9] + tmpQ2[41]*tmpFx[22] + tmpQ2[42]*tmpFx[35] + tmpQ2[43]*tmpFx[48];
tmpQ1[140] = + tmpQ2[40]*tmpFx[10] + tmpQ2[41]*tmpFx[23] + tmpQ2[42]*tmpFx[36] + tmpQ2[43]*tmpFx[49];
tmpQ1[141] = + tmpQ2[40]*tmpFx[11] + tmpQ2[41]*tmpFx[24] + tmpQ2[42]*tmpFx[37] + tmpQ2[43]*tmpFx[50];
tmpQ1[142] = + tmpQ2[40]*tmpFx[12] + tmpQ2[41]*tmpFx[25] + tmpQ2[42]*tmpFx[38] + tmpQ2[43]*tmpFx[51];
tmpQ1[143] = + tmpQ2[44]*tmpFx[0] + tmpQ2[45]*tmpFx[13] + tmpQ2[46]*tmpFx[26] + tmpQ2[47]*tmpFx[39];
tmpQ1[144] = + tmpQ2[44]*tmpFx[1] + tmpQ2[45]*tmpFx[14] + tmpQ2[46]*tmpFx[27] + tmpQ2[47]*tmpFx[40];
tmpQ1[145] = + tmpQ2[44]*tmpFx[2] + tmpQ2[45]*tmpFx[15] + tmpQ2[46]*tmpFx[28] + tmpQ2[47]*tmpFx[41];
tmpQ1[146] = + tmpQ2[44]*tmpFx[3] + tmpQ2[45]*tmpFx[16] + tmpQ2[46]*tmpFx[29] + tmpQ2[47]*tmpFx[42];
tmpQ1[147] = + tmpQ2[44]*tmpFx[4] + tmpQ2[45]*tmpFx[17] + tmpQ2[46]*tmpFx[30] + tmpQ2[47]*tmpFx[43];
tmpQ1[148] = + tmpQ2[44]*tmpFx[5] + tmpQ2[45]*tmpFx[18] + tmpQ2[46]*tmpFx[31] + tmpQ2[47]*tmpFx[44];
tmpQ1[149] = + tmpQ2[44]*tmpFx[6] + tmpQ2[45]*tmpFx[19] + tmpQ2[46]*tmpFx[32] + tmpQ2[47]*tmpFx[45];
tmpQ1[150] = + tmpQ2[44]*tmpFx[7] + tmpQ2[45]*tmpFx[20] + tmpQ2[46]*tmpFx[33] + tmpQ2[47]*tmpFx[46];
tmpQ1[151] = + tmpQ2[44]*tmpFx[8] + tmpQ2[45]*tmpFx[21] + tmpQ2[46]*tmpFx[34] + tmpQ2[47]*tmpFx[47];
tmpQ1[152] = + tmpQ2[44]*tmpFx[9] + tmpQ2[45]*tmpFx[22] + tmpQ2[46]*tmpFx[35] + tmpQ2[47]*tmpFx[48];
tmpQ1[153] = + tmpQ2[44]*tmpFx[10] + tmpQ2[45]*tmpFx[23] + tmpQ2[46]*tmpFx[36] + tmpQ2[47]*tmpFx[49];
tmpQ1[154] = + tmpQ2[44]*tmpFx[11] + tmpQ2[45]*tmpFx[24] + tmpQ2[46]*tmpFx[37] + tmpQ2[47]*tmpFx[50];
tmpQ1[155] = + tmpQ2[44]*tmpFx[12] + tmpQ2[45]*tmpFx[25] + tmpQ2[46]*tmpFx[38] + tmpQ2[47]*tmpFx[51];
tmpQ1[156] = + tmpQ2[48]*tmpFx[0] + tmpQ2[49]*tmpFx[13] + tmpQ2[50]*tmpFx[26] + tmpQ2[51]*tmpFx[39];
tmpQ1[157] = + tmpQ2[48]*tmpFx[1] + tmpQ2[49]*tmpFx[14] + tmpQ2[50]*tmpFx[27] + tmpQ2[51]*tmpFx[40];
tmpQ1[158] = + tmpQ2[48]*tmpFx[2] + tmpQ2[49]*tmpFx[15] + tmpQ2[50]*tmpFx[28] + tmpQ2[51]*tmpFx[41];
tmpQ1[159] = + tmpQ2[48]*tmpFx[3] + tmpQ2[49]*tmpFx[16] + tmpQ2[50]*tmpFx[29] + tmpQ2[51]*tmpFx[42];
tmpQ1[160] = + tmpQ2[48]*tmpFx[4] + tmpQ2[49]*tmpFx[17] + tmpQ2[50]*tmpFx[30] + tmpQ2[51]*tmpFx[43];
tmpQ1[161] = + tmpQ2[48]*tmpFx[5] + tmpQ2[49]*tmpFx[18] + tmpQ2[50]*tmpFx[31] + tmpQ2[51]*tmpFx[44];
tmpQ1[162] = + tmpQ2[48]*tmpFx[6] + tmpQ2[49]*tmpFx[19] + tmpQ2[50]*tmpFx[32] + tmpQ2[51]*tmpFx[45];
tmpQ1[163] = + tmpQ2[48]*tmpFx[7] + tmpQ2[49]*tmpFx[20] + tmpQ2[50]*tmpFx[33] + tmpQ2[51]*tmpFx[46];
tmpQ1[164] = + tmpQ2[48]*tmpFx[8] + tmpQ2[49]*tmpFx[21] + tmpQ2[50]*tmpFx[34] + tmpQ2[51]*tmpFx[47];
tmpQ1[165] = + tmpQ2[48]*tmpFx[9] + tmpQ2[49]*tmpFx[22] + tmpQ2[50]*tmpFx[35] + tmpQ2[51]*tmpFx[48];
tmpQ1[166] = + tmpQ2[48]*tmpFx[10] + tmpQ2[49]*tmpFx[23] + tmpQ2[50]*tmpFx[36] + tmpQ2[51]*tmpFx[49];
tmpQ1[167] = + tmpQ2[48]*tmpFx[11] + tmpQ2[49]*tmpFx[24] + tmpQ2[50]*tmpFx[37] + tmpQ2[51]*tmpFx[50];
tmpQ1[168] = + tmpQ2[48]*tmpFx[12] + tmpQ2[49]*tmpFx[25] + tmpQ2[50]*tmpFx[38] + tmpQ2[51]*tmpFx[51];
}

void acado_setObjR1R2( real_t* const tmpFu, real_t* const tmpObjS, real_t* const tmpR1, real_t* const tmpR2 )
{
tmpR2[0] = + tmpFu[0]*tmpObjS[0] + tmpFu[2]*tmpObjS[4] + tmpFu[4]*tmpObjS[8] + tmpFu[6]*tmpObjS[12];
tmpR2[1] = + tmpFu[0]*tmpObjS[1] + tmpFu[2]*tmpObjS[5] + tmpFu[4]*tmpObjS[9] + tmpFu[6]*tmpObjS[13];
tmpR2[2] = + tmpFu[0]*tmpObjS[2] + tmpFu[2]*tmpObjS[6] + tmpFu[4]*tmpObjS[10] + tmpFu[6]*tmpObjS[14];
tmpR2[3] = + tmpFu[0]*tmpObjS[3] + tmpFu[2]*tmpObjS[7] + tmpFu[4]*tmpObjS[11] + tmpFu[6]*tmpObjS[15];
tmpR2[4] = + tmpFu[1]*tmpObjS[0] + tmpFu[3]*tmpObjS[4] + tmpFu[5]*tmpObjS[8] + tmpFu[7]*tmpObjS[12];
tmpR2[5] = + tmpFu[1]*tmpObjS[1] + tmpFu[3]*tmpObjS[5] + tmpFu[5]*tmpObjS[9] + tmpFu[7]*tmpObjS[13];
tmpR2[6] = + tmpFu[1]*tmpObjS[2] + tmpFu[3]*tmpObjS[6] + tmpFu[5]*tmpObjS[10] + tmpFu[7]*tmpObjS[14];
tmpR2[7] = + tmpFu[1]*tmpObjS[3] + tmpFu[3]*tmpObjS[7] + tmpFu[5]*tmpObjS[11] + tmpFu[7]*tmpObjS[15];
tmpR1[0] = + tmpR2[0]*tmpFu[0] + tmpR2[1]*tmpFu[2] + tmpR2[2]*tmpFu[4] + tmpR2[3]*tmpFu[6];
tmpR1[1] = + tmpR2[0]*tmpFu[1] + tmpR2[1]*tmpFu[3] + tmpR2[2]*tmpFu[5] + tmpR2[3]*tmpFu[7];
tmpR1[2] = + tmpR2[4]*tmpFu[0] + tmpR2[5]*tmpFu[2] + tmpR2[6]*tmpFu[4] + tmpR2[7]*tmpFu[6];
tmpR1[3] = + tmpR2[4]*tmpFu[1] + tmpR2[5]*tmpFu[3] + tmpR2[6]*tmpFu[5] + tmpR2[7]*tmpFu[7];
}

void acado_setObjQN1QN2( real_t* const tmpFx, real_t* const tmpObjSEndTerm, real_t* const tmpQN1, real_t* const tmpQN2 )
{
tmpQN2[0] = + tmpFx[0]*tmpObjSEndTerm[0] + tmpFx[13]*tmpObjSEndTerm[2];
tmpQN2[1] = + tmpFx[0]*tmpObjSEndTerm[1] + tmpFx[13]*tmpObjSEndTerm[3];
tmpQN2[2] = + tmpFx[1]*tmpObjSEndTerm[0] + tmpFx[14]*tmpObjSEndTerm[2];
tmpQN2[3] = + tmpFx[1]*tmpObjSEndTerm[1] + tmpFx[14]*tmpObjSEndTerm[3];
tmpQN2[4] = + tmpFx[2]*tmpObjSEndTerm[0] + tmpFx[15]*tmpObjSEndTerm[2];
tmpQN2[5] = + tmpFx[2]*tmpObjSEndTerm[1] + tmpFx[15]*tmpObjSEndTerm[3];
tmpQN2[6] = + tmpFx[3]*tmpObjSEndTerm[0] + tmpFx[16]*tmpObjSEndTerm[2];
tmpQN2[7] = + tmpFx[3]*tmpObjSEndTerm[1] + tmpFx[16]*tmpObjSEndTerm[3];
tmpQN2[8] = + tmpFx[4]*tmpObjSEndTerm[0] + tmpFx[17]*tmpObjSEndTerm[2];
tmpQN2[9] = + tmpFx[4]*tmpObjSEndTerm[1] + tmpFx[17]*tmpObjSEndTerm[3];
tmpQN2[10] = + tmpFx[5]*tmpObjSEndTerm[0] + tmpFx[18]*tmpObjSEndTerm[2];
tmpQN2[11] = + tmpFx[5]*tmpObjSEndTerm[1] + tmpFx[18]*tmpObjSEndTerm[3];
tmpQN2[12] = + tmpFx[6]*tmpObjSEndTerm[0] + tmpFx[19]*tmpObjSEndTerm[2];
tmpQN2[13] = + tmpFx[6]*tmpObjSEndTerm[1] + tmpFx[19]*tmpObjSEndTerm[3];
tmpQN2[14] = + tmpFx[7]*tmpObjSEndTerm[0] + tmpFx[20]*tmpObjSEndTerm[2];
tmpQN2[15] = + tmpFx[7]*tmpObjSEndTerm[1] + tmpFx[20]*tmpObjSEndTerm[3];
tmpQN2[16] = + tmpFx[8]*tmpObjSEndTerm[0] + tmpFx[21]*tmpObjSEndTerm[2];
tmpQN2[17] = + tmpFx[8]*tmpObjSEndTerm[1] + tmpFx[21]*tmpObjSEndTerm[3];
tmpQN2[18] = + tmpFx[9]*tmpObjSEndTerm[0] + tmpFx[22]*tmpObjSEndTerm[2];
tmpQN2[19] = + tmpFx[9]*tmpObjSEndTerm[1] + tmpFx[22]*tmpObjSEndTerm[3];
tmpQN2[20] = + tmpFx[10]*tmpObjSEndTerm[0] + tmpFx[23]*tmpObjSEndTerm[2];
tmpQN2[21] = + tmpFx[10]*tmpObjSEndTerm[1] + tmpFx[23]*tmpObjSEndTerm[3];
tmpQN2[22] = + tmpFx[11]*tmpObjSEndTerm[0] + tmpFx[24]*tmpObjSEndTerm[2];
tmpQN2[23] = + tmpFx[11]*tmpObjSEndTerm[1] + tmpFx[24]*tmpObjSEndTerm[3];
tmpQN2[24] = + tmpFx[12]*tmpObjSEndTerm[0] + tmpFx[25]*tmpObjSEndTerm[2];
tmpQN2[25] = + tmpFx[12]*tmpObjSEndTerm[1] + tmpFx[25]*tmpObjSEndTerm[3];
tmpQN1[0] = + tmpQN2[0]*tmpFx[0] + tmpQN2[1]*tmpFx[13];
tmpQN1[1] = + tmpQN2[0]*tmpFx[1] + tmpQN2[1]*tmpFx[14];
tmpQN1[2] = + tmpQN2[0]*tmpFx[2] + tmpQN2[1]*tmpFx[15];
tmpQN1[3] = + tmpQN2[0]*tmpFx[3] + tmpQN2[1]*tmpFx[16];
tmpQN1[4] = + tmpQN2[0]*tmpFx[4] + tmpQN2[1]*tmpFx[17];
tmpQN1[5] = + tmpQN2[0]*tmpFx[5] + tmpQN2[1]*tmpFx[18];
tmpQN1[6] = + tmpQN2[0]*tmpFx[6] + tmpQN2[1]*tmpFx[19];
tmpQN1[7] = + tmpQN2[0]*tmpFx[7] + tmpQN2[1]*tmpFx[20];
tmpQN1[8] = + tmpQN2[0]*tmpFx[8] + tmpQN2[1]*tmpFx[21];
tmpQN1[9] = + tmpQN2[0]*tmpFx[9] + tmpQN2[1]*tmpFx[22];
tmpQN1[10] = + tmpQN2[0]*tmpFx[10] + tmpQN2[1]*tmpFx[23];
tmpQN1[11] = + tmpQN2[0]*tmpFx[11] + tmpQN2[1]*tmpFx[24];
tmpQN1[12] = + tmpQN2[0]*tmpFx[12] + tmpQN2[1]*tmpFx[25];
tmpQN1[13] = + tmpQN2[2]*tmpFx[0] + tmpQN2[3]*tmpFx[13];
tmpQN1[14] = + tmpQN2[2]*tmpFx[1] + tmpQN2[3]*tmpFx[14];
tmpQN1[15] = + tmpQN2[2]*tmpFx[2] + tmpQN2[3]*tmpFx[15];
tmpQN1[16] = + tmpQN2[2]*tmpFx[3] + tmpQN2[3]*tmpFx[16];
tmpQN1[17] = + tmpQN2[2]*tmpFx[4] + tmpQN2[3]*tmpFx[17];
tmpQN1[18] = + tmpQN2[2]*tmpFx[5] + tmpQN2[3]*tmpFx[18];
tmpQN1[19] = + tmpQN2[2]*tmpFx[6] + tmpQN2[3]*tmpFx[19];
tmpQN1[20] = + tmpQN2[2]*tmpFx[7] + tmpQN2[3]*tmpFx[20];
tmpQN1[21] = + tmpQN2[2]*tmpFx[8] + tmpQN2[3]*tmpFx[21];
tmpQN1[22] = + tmpQN2[2]*tmpFx[9] + tmpQN2[3]*tmpFx[22];
tmpQN1[23] = + tmpQN2[2]*tmpFx[10] + tmpQN2[3]*tmpFx[23];
tmpQN1[24] = + tmpQN2[2]*tmpFx[11] + tmpQN2[3]*tmpFx[24];
tmpQN1[25] = + tmpQN2[2]*tmpFx[12] + tmpQN2[3]*tmpFx[25];
tmpQN1[26] = + tmpQN2[4]*tmpFx[0] + tmpQN2[5]*tmpFx[13];
tmpQN1[27] = + tmpQN2[4]*tmpFx[1] + tmpQN2[5]*tmpFx[14];
tmpQN1[28] = + tmpQN2[4]*tmpFx[2] + tmpQN2[5]*tmpFx[15];
tmpQN1[29] = + tmpQN2[4]*tmpFx[3] + tmpQN2[5]*tmpFx[16];
tmpQN1[30] = + tmpQN2[4]*tmpFx[4] + tmpQN2[5]*tmpFx[17];
tmpQN1[31] = + tmpQN2[4]*tmpFx[5] + tmpQN2[5]*tmpFx[18];
tmpQN1[32] = + tmpQN2[4]*tmpFx[6] + tmpQN2[5]*tmpFx[19];
tmpQN1[33] = + tmpQN2[4]*tmpFx[7] + tmpQN2[5]*tmpFx[20];
tmpQN1[34] = + tmpQN2[4]*tmpFx[8] + tmpQN2[5]*tmpFx[21];
tmpQN1[35] = + tmpQN2[4]*tmpFx[9] + tmpQN2[5]*tmpFx[22];
tmpQN1[36] = + tmpQN2[4]*tmpFx[10] + tmpQN2[5]*tmpFx[23];
tmpQN1[37] = + tmpQN2[4]*tmpFx[11] + tmpQN2[5]*tmpFx[24];
tmpQN1[38] = + tmpQN2[4]*tmpFx[12] + tmpQN2[5]*tmpFx[25];
tmpQN1[39] = + tmpQN2[6]*tmpFx[0] + tmpQN2[7]*tmpFx[13];
tmpQN1[40] = + tmpQN2[6]*tmpFx[1] + tmpQN2[7]*tmpFx[14];
tmpQN1[41] = + tmpQN2[6]*tmpFx[2] + tmpQN2[7]*tmpFx[15];
tmpQN1[42] = + tmpQN2[6]*tmpFx[3] + tmpQN2[7]*tmpFx[16];
tmpQN1[43] = + tmpQN2[6]*tmpFx[4] + tmpQN2[7]*tmpFx[17];
tmpQN1[44] = + tmpQN2[6]*tmpFx[5] + tmpQN2[7]*tmpFx[18];
tmpQN1[45] = + tmpQN2[6]*tmpFx[6] + tmpQN2[7]*tmpFx[19];
tmpQN1[46] = + tmpQN2[6]*tmpFx[7] + tmpQN2[7]*tmpFx[20];
tmpQN1[47] = + tmpQN2[6]*tmpFx[8] + tmpQN2[7]*tmpFx[21];
tmpQN1[48] = + tmpQN2[6]*tmpFx[9] + tmpQN2[7]*tmpFx[22];
tmpQN1[49] = + tmpQN2[6]*tmpFx[10] + tmpQN2[7]*tmpFx[23];
tmpQN1[50] = + tmpQN2[6]*tmpFx[11] + tmpQN2[7]*tmpFx[24];
tmpQN1[51] = + tmpQN2[6]*tmpFx[12] + tmpQN2[7]*tmpFx[25];
tmpQN1[52] = + tmpQN2[8]*tmpFx[0] + tmpQN2[9]*tmpFx[13];
tmpQN1[53] = + tmpQN2[8]*tmpFx[1] + tmpQN2[9]*tmpFx[14];
tmpQN1[54] = + tmpQN2[8]*tmpFx[2] + tmpQN2[9]*tmpFx[15];
tmpQN1[55] = + tmpQN2[8]*tmpFx[3] + tmpQN2[9]*tmpFx[16];
tmpQN1[56] = + tmpQN2[8]*tmpFx[4] + tmpQN2[9]*tmpFx[17];
tmpQN1[57] = + tmpQN2[8]*tmpFx[5] + tmpQN2[9]*tmpFx[18];
tmpQN1[58] = + tmpQN2[8]*tmpFx[6] + tmpQN2[9]*tmpFx[19];
tmpQN1[59] = + tmpQN2[8]*tmpFx[7] + tmpQN2[9]*tmpFx[20];
tmpQN1[60] = + tmpQN2[8]*tmpFx[8] + tmpQN2[9]*tmpFx[21];
tmpQN1[61] = + tmpQN2[8]*tmpFx[9] + tmpQN2[9]*tmpFx[22];
tmpQN1[62] = + tmpQN2[8]*tmpFx[10] + tmpQN2[9]*tmpFx[23];
tmpQN1[63] = + tmpQN2[8]*tmpFx[11] + tmpQN2[9]*tmpFx[24];
tmpQN1[64] = + tmpQN2[8]*tmpFx[12] + tmpQN2[9]*tmpFx[25];
tmpQN1[65] = + tmpQN2[10]*tmpFx[0] + tmpQN2[11]*tmpFx[13];
tmpQN1[66] = + tmpQN2[10]*tmpFx[1] + tmpQN2[11]*tmpFx[14];
tmpQN1[67] = + tmpQN2[10]*tmpFx[2] + tmpQN2[11]*tmpFx[15];
tmpQN1[68] = + tmpQN2[10]*tmpFx[3] + tmpQN2[11]*tmpFx[16];
tmpQN1[69] = + tmpQN2[10]*tmpFx[4] + tmpQN2[11]*tmpFx[17];
tmpQN1[70] = + tmpQN2[10]*tmpFx[5] + tmpQN2[11]*tmpFx[18];
tmpQN1[71] = + tmpQN2[10]*tmpFx[6] + tmpQN2[11]*tmpFx[19];
tmpQN1[72] = + tmpQN2[10]*tmpFx[7] + tmpQN2[11]*tmpFx[20];
tmpQN1[73] = + tmpQN2[10]*tmpFx[8] + tmpQN2[11]*tmpFx[21];
tmpQN1[74] = + tmpQN2[10]*tmpFx[9] + tmpQN2[11]*tmpFx[22];
tmpQN1[75] = + tmpQN2[10]*tmpFx[10] + tmpQN2[11]*tmpFx[23];
tmpQN1[76] = + tmpQN2[10]*tmpFx[11] + tmpQN2[11]*tmpFx[24];
tmpQN1[77] = + tmpQN2[10]*tmpFx[12] + tmpQN2[11]*tmpFx[25];
tmpQN1[78] = + tmpQN2[12]*tmpFx[0] + tmpQN2[13]*tmpFx[13];
tmpQN1[79] = + tmpQN2[12]*tmpFx[1] + tmpQN2[13]*tmpFx[14];
tmpQN1[80] = + tmpQN2[12]*tmpFx[2] + tmpQN2[13]*tmpFx[15];
tmpQN1[81] = + tmpQN2[12]*tmpFx[3] + tmpQN2[13]*tmpFx[16];
tmpQN1[82] = + tmpQN2[12]*tmpFx[4] + tmpQN2[13]*tmpFx[17];
tmpQN1[83] = + tmpQN2[12]*tmpFx[5] + tmpQN2[13]*tmpFx[18];
tmpQN1[84] = + tmpQN2[12]*tmpFx[6] + tmpQN2[13]*tmpFx[19];
tmpQN1[85] = + tmpQN2[12]*tmpFx[7] + tmpQN2[13]*tmpFx[20];
tmpQN1[86] = + tmpQN2[12]*tmpFx[8] + tmpQN2[13]*tmpFx[21];
tmpQN1[87] = + tmpQN2[12]*tmpFx[9] + tmpQN2[13]*tmpFx[22];
tmpQN1[88] = + tmpQN2[12]*tmpFx[10] + tmpQN2[13]*tmpFx[23];
tmpQN1[89] = + tmpQN2[12]*tmpFx[11] + tmpQN2[13]*tmpFx[24];
tmpQN1[90] = + tmpQN2[12]*tmpFx[12] + tmpQN2[13]*tmpFx[25];
tmpQN1[91] = + tmpQN2[14]*tmpFx[0] + tmpQN2[15]*tmpFx[13];
tmpQN1[92] = + tmpQN2[14]*tmpFx[1] + tmpQN2[15]*tmpFx[14];
tmpQN1[93] = + tmpQN2[14]*tmpFx[2] + tmpQN2[15]*tmpFx[15];
tmpQN1[94] = + tmpQN2[14]*tmpFx[3] + tmpQN2[15]*tmpFx[16];
tmpQN1[95] = + tmpQN2[14]*tmpFx[4] + tmpQN2[15]*tmpFx[17];
tmpQN1[96] = + tmpQN2[14]*tmpFx[5] + tmpQN2[15]*tmpFx[18];
tmpQN1[97] = + tmpQN2[14]*tmpFx[6] + tmpQN2[15]*tmpFx[19];
tmpQN1[98] = + tmpQN2[14]*tmpFx[7] + tmpQN2[15]*tmpFx[20];
tmpQN1[99] = + tmpQN2[14]*tmpFx[8] + tmpQN2[15]*tmpFx[21];
tmpQN1[100] = + tmpQN2[14]*tmpFx[9] + tmpQN2[15]*tmpFx[22];
tmpQN1[101] = + tmpQN2[14]*tmpFx[10] + tmpQN2[15]*tmpFx[23];
tmpQN1[102] = + tmpQN2[14]*tmpFx[11] + tmpQN2[15]*tmpFx[24];
tmpQN1[103] = + tmpQN2[14]*tmpFx[12] + tmpQN2[15]*tmpFx[25];
tmpQN1[104] = + tmpQN2[16]*tmpFx[0] + tmpQN2[17]*tmpFx[13];
tmpQN1[105] = + tmpQN2[16]*tmpFx[1] + tmpQN2[17]*tmpFx[14];
tmpQN1[106] = + tmpQN2[16]*tmpFx[2] + tmpQN2[17]*tmpFx[15];
tmpQN1[107] = + tmpQN2[16]*tmpFx[3] + tmpQN2[17]*tmpFx[16];
tmpQN1[108] = + tmpQN2[16]*tmpFx[4] + tmpQN2[17]*tmpFx[17];
tmpQN1[109] = + tmpQN2[16]*tmpFx[5] + tmpQN2[17]*tmpFx[18];
tmpQN1[110] = + tmpQN2[16]*tmpFx[6] + tmpQN2[17]*tmpFx[19];
tmpQN1[111] = + tmpQN2[16]*tmpFx[7] + tmpQN2[17]*tmpFx[20];
tmpQN1[112] = + tmpQN2[16]*tmpFx[8] + tmpQN2[17]*tmpFx[21];
tmpQN1[113] = + tmpQN2[16]*tmpFx[9] + tmpQN2[17]*tmpFx[22];
tmpQN1[114] = + tmpQN2[16]*tmpFx[10] + tmpQN2[17]*tmpFx[23];
tmpQN1[115] = + tmpQN2[16]*tmpFx[11] + tmpQN2[17]*tmpFx[24];
tmpQN1[116] = + tmpQN2[16]*tmpFx[12] + tmpQN2[17]*tmpFx[25];
tmpQN1[117] = + tmpQN2[18]*tmpFx[0] + tmpQN2[19]*tmpFx[13];
tmpQN1[118] = + tmpQN2[18]*tmpFx[1] + tmpQN2[19]*tmpFx[14];
tmpQN1[119] = + tmpQN2[18]*tmpFx[2] + tmpQN2[19]*tmpFx[15];
tmpQN1[120] = + tmpQN2[18]*tmpFx[3] + tmpQN2[19]*tmpFx[16];
tmpQN1[121] = + tmpQN2[18]*tmpFx[4] + tmpQN2[19]*tmpFx[17];
tmpQN1[122] = + tmpQN2[18]*tmpFx[5] + tmpQN2[19]*tmpFx[18];
tmpQN1[123] = + tmpQN2[18]*tmpFx[6] + tmpQN2[19]*tmpFx[19];
tmpQN1[124] = + tmpQN2[18]*tmpFx[7] + tmpQN2[19]*tmpFx[20];
tmpQN1[125] = + tmpQN2[18]*tmpFx[8] + tmpQN2[19]*tmpFx[21];
tmpQN1[126] = + tmpQN2[18]*tmpFx[9] + tmpQN2[19]*tmpFx[22];
tmpQN1[127] = + tmpQN2[18]*tmpFx[10] + tmpQN2[19]*tmpFx[23];
tmpQN1[128] = + tmpQN2[18]*tmpFx[11] + tmpQN2[19]*tmpFx[24];
tmpQN1[129] = + tmpQN2[18]*tmpFx[12] + tmpQN2[19]*tmpFx[25];
tmpQN1[130] = + tmpQN2[20]*tmpFx[0] + tmpQN2[21]*tmpFx[13];
tmpQN1[131] = + tmpQN2[20]*tmpFx[1] + tmpQN2[21]*tmpFx[14];
tmpQN1[132] = + tmpQN2[20]*tmpFx[2] + tmpQN2[21]*tmpFx[15];
tmpQN1[133] = + tmpQN2[20]*tmpFx[3] + tmpQN2[21]*tmpFx[16];
tmpQN1[134] = + tmpQN2[20]*tmpFx[4] + tmpQN2[21]*tmpFx[17];
tmpQN1[135] = + tmpQN2[20]*tmpFx[5] + tmpQN2[21]*tmpFx[18];
tmpQN1[136] = + tmpQN2[20]*tmpFx[6] + tmpQN2[21]*tmpFx[19];
tmpQN1[137] = + tmpQN2[20]*tmpFx[7] + tmpQN2[21]*tmpFx[20];
tmpQN1[138] = + tmpQN2[20]*tmpFx[8] + tmpQN2[21]*tmpFx[21];
tmpQN1[139] = + tmpQN2[20]*tmpFx[9] + tmpQN2[21]*tmpFx[22];
tmpQN1[140] = + tmpQN2[20]*tmpFx[10] + tmpQN2[21]*tmpFx[23];
tmpQN1[141] = + tmpQN2[20]*tmpFx[11] + tmpQN2[21]*tmpFx[24];
tmpQN1[142] = + tmpQN2[20]*tmpFx[12] + tmpQN2[21]*tmpFx[25];
tmpQN1[143] = + tmpQN2[22]*tmpFx[0] + tmpQN2[23]*tmpFx[13];
tmpQN1[144] = + tmpQN2[22]*tmpFx[1] + tmpQN2[23]*tmpFx[14];
tmpQN1[145] = + tmpQN2[22]*tmpFx[2] + tmpQN2[23]*tmpFx[15];
tmpQN1[146] = + tmpQN2[22]*tmpFx[3] + tmpQN2[23]*tmpFx[16];
tmpQN1[147] = + tmpQN2[22]*tmpFx[4] + tmpQN2[23]*tmpFx[17];
tmpQN1[148] = + tmpQN2[22]*tmpFx[5] + tmpQN2[23]*tmpFx[18];
tmpQN1[149] = + tmpQN2[22]*tmpFx[6] + tmpQN2[23]*tmpFx[19];
tmpQN1[150] = + tmpQN2[22]*tmpFx[7] + tmpQN2[23]*tmpFx[20];
tmpQN1[151] = + tmpQN2[22]*tmpFx[8] + tmpQN2[23]*tmpFx[21];
tmpQN1[152] = + tmpQN2[22]*tmpFx[9] + tmpQN2[23]*tmpFx[22];
tmpQN1[153] = + tmpQN2[22]*tmpFx[10] + tmpQN2[23]*tmpFx[23];
tmpQN1[154] = + tmpQN2[22]*tmpFx[11] + tmpQN2[23]*tmpFx[24];
tmpQN1[155] = + tmpQN2[22]*tmpFx[12] + tmpQN2[23]*tmpFx[25];
tmpQN1[156] = + tmpQN2[24]*tmpFx[0] + tmpQN2[25]*tmpFx[13];
tmpQN1[157] = + tmpQN2[24]*tmpFx[1] + tmpQN2[25]*tmpFx[14];
tmpQN1[158] = + tmpQN2[24]*tmpFx[2] + tmpQN2[25]*tmpFx[15];
tmpQN1[159] = + tmpQN2[24]*tmpFx[3] + tmpQN2[25]*tmpFx[16];
tmpQN1[160] = + tmpQN2[24]*tmpFx[4] + tmpQN2[25]*tmpFx[17];
tmpQN1[161] = + tmpQN2[24]*tmpFx[5] + tmpQN2[25]*tmpFx[18];
tmpQN1[162] = + tmpQN2[24]*tmpFx[6] + tmpQN2[25]*tmpFx[19];
tmpQN1[163] = + tmpQN2[24]*tmpFx[7] + tmpQN2[25]*tmpFx[20];
tmpQN1[164] = + tmpQN2[24]*tmpFx[8] + tmpQN2[25]*tmpFx[21];
tmpQN1[165] = + tmpQN2[24]*tmpFx[9] + tmpQN2[25]*tmpFx[22];
tmpQN1[166] = + tmpQN2[24]*tmpFx[10] + tmpQN2[25]*tmpFx[23];
tmpQN1[167] = + tmpQN2[24]*tmpFx[11] + tmpQN2[25]*tmpFx[24];
tmpQN1[168] = + tmpQN2[24]*tmpFx[12] + tmpQN2[25]*tmpFx[25];
}

void acado_evaluateObjective(  )
{
int runObj;
for (runObj = 0; runObj < 10; ++runObj)
{
acadoWorkspace.objValueIn[0] = acadoVariables.x[runObj * 13];
acadoWorkspace.objValueIn[1] = acadoVariables.x[runObj * 13 + 1];
acadoWorkspace.objValueIn[2] = acadoVariables.x[runObj * 13 + 2];
acadoWorkspace.objValueIn[3] = acadoVariables.x[runObj * 13 + 3];
acadoWorkspace.objValueIn[4] = acadoVariables.x[runObj * 13 + 4];
acadoWorkspace.objValueIn[5] = acadoVariables.x[runObj * 13 + 5];
acadoWorkspace.objValueIn[6] = acadoVariables.x[runObj * 13 + 6];
acadoWorkspace.objValueIn[7] = acadoVariables.x[runObj * 13 + 7];
acadoWorkspace.objValueIn[8] = acadoVariables.x[runObj * 13 + 8];
acadoWorkspace.objValueIn[9] = acadoVariables.x[runObj * 13 + 9];
acadoWorkspace.objValueIn[10] = acadoVariables.x[runObj * 13 + 10];
acadoWorkspace.objValueIn[11] = acadoVariables.x[runObj * 13 + 11];
acadoWorkspace.objValueIn[12] = acadoVariables.x[runObj * 13 + 12];
acadoWorkspace.objValueIn[13] = acadoVariables.u[runObj * 2];
acadoWorkspace.objValueIn[14] = acadoVariables.u[runObj * 2 + 1];
acadoWorkspace.objValueIn[15] = acadoVariables.od[runObj * 8];
acadoWorkspace.objValueIn[16] = acadoVariables.od[runObj * 8 + 1];
acadoWorkspace.objValueIn[17] = acadoVariables.od[runObj * 8 + 2];
acadoWorkspace.objValueIn[18] = acadoVariables.od[runObj * 8 + 3];
acadoWorkspace.objValueIn[19] = acadoVariables.od[runObj * 8 + 4];
acadoWorkspace.objValueIn[20] = acadoVariables.od[runObj * 8 + 5];
acadoWorkspace.objValueIn[21] = acadoVariables.od[runObj * 8 + 6];
acadoWorkspace.objValueIn[22] = acadoVariables.od[runObj * 8 + 7];

acado_evaluateLSQ( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );
acadoWorkspace.Dy[runObj * 4] = acadoWorkspace.objValueOut[0];
acadoWorkspace.Dy[runObj * 4 + 1] = acadoWorkspace.objValueOut[1];
acadoWorkspace.Dy[runObj * 4 + 2] = acadoWorkspace.objValueOut[2];
acadoWorkspace.Dy[runObj * 4 + 3] = acadoWorkspace.objValueOut[3];

acado_setObjQ1Q2( &(acadoWorkspace.objValueOut[ 4 ]), acadoVariables.W, &(acadoWorkspace.Q1[ runObj * 169 ]), &(acadoWorkspace.Q2[ runObj * 52 ]) );

acado_setObjR1R2( &(acadoWorkspace.objValueOut[ 56 ]), acadoVariables.W, &(acadoWorkspace.R1[ runObj * 4 ]), &(acadoWorkspace.R2[ runObj * 8 ]) );

}
acadoWorkspace.objValueIn[0] = acadoVariables.x[130];
acadoWorkspace.objValueIn[1] = acadoVariables.x[131];
acadoWorkspace.objValueIn[2] = acadoVariables.x[132];
acadoWorkspace.objValueIn[3] = acadoVariables.x[133];
acadoWorkspace.objValueIn[4] = acadoVariables.x[134];
acadoWorkspace.objValueIn[5] = acadoVariables.x[135];
acadoWorkspace.objValueIn[6] = acadoVariables.x[136];
acadoWorkspace.objValueIn[7] = acadoVariables.x[137];
acadoWorkspace.objValueIn[8] = acadoVariables.x[138];
acadoWorkspace.objValueIn[9] = acadoVariables.x[139];
acadoWorkspace.objValueIn[10] = acadoVariables.x[140];
acadoWorkspace.objValueIn[11] = acadoVariables.x[141];
acadoWorkspace.objValueIn[12] = acadoVariables.x[142];
acadoWorkspace.objValueIn[13] = acadoVariables.od[80];
acadoWorkspace.objValueIn[14] = acadoVariables.od[81];
acadoWorkspace.objValueIn[15] = acadoVariables.od[82];
acadoWorkspace.objValueIn[16] = acadoVariables.od[83];
acadoWorkspace.objValueIn[17] = acadoVariables.od[84];
acadoWorkspace.objValueIn[18] = acadoVariables.od[85];
acadoWorkspace.objValueIn[19] = acadoVariables.od[86];
acadoWorkspace.objValueIn[20] = acadoVariables.od[87];
acado_evaluateLSQEndTerm( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );

acadoWorkspace.DyN[0] = acadoWorkspace.objValueOut[0];
acadoWorkspace.DyN[1] = acadoWorkspace.objValueOut[1];

acado_setObjQN1QN2( &(acadoWorkspace.objValueOut[ 2 ]), acadoVariables.WN, acadoWorkspace.QN1, acadoWorkspace.QN2 );

}

void acado_moveGxT( real_t* const Gx1, real_t* const Gx2 )
{
int lRun1;
int lRun2;
for (lRun1 = 0;lRun1 < 13; ++lRun1)
for (lRun2 = 0;lRun2 < 13; ++lRun2)
Gx2[(lRun1 * 13) + (lRun2)] = Gx1[(lRun1 * 13) + (lRun2)];
}

void acado_multGxGx( real_t* const Gx1, real_t* const Gx2, real_t* const Gx3 )
{
Gx3[0] = + Gx1[0]*Gx2[0] + Gx1[1]*Gx2[13] + Gx1[2]*Gx2[26] + Gx1[3]*Gx2[39] + Gx1[4]*Gx2[52] + Gx1[5]*Gx2[65] + Gx1[6]*Gx2[78] + Gx1[7]*Gx2[91] + Gx1[8]*Gx2[104] + Gx1[9]*Gx2[117] + Gx1[10]*Gx2[130] + Gx1[11]*Gx2[143] + Gx1[12]*Gx2[156];
Gx3[1] = + Gx1[0]*Gx2[1] + Gx1[1]*Gx2[14] + Gx1[2]*Gx2[27] + Gx1[3]*Gx2[40] + Gx1[4]*Gx2[53] + Gx1[5]*Gx2[66] + Gx1[6]*Gx2[79] + Gx1[7]*Gx2[92] + Gx1[8]*Gx2[105] + Gx1[9]*Gx2[118] + Gx1[10]*Gx2[131] + Gx1[11]*Gx2[144] + Gx1[12]*Gx2[157];
Gx3[2] = + Gx1[0]*Gx2[2] + Gx1[1]*Gx2[15] + Gx1[2]*Gx2[28] + Gx1[3]*Gx2[41] + Gx1[4]*Gx2[54] + Gx1[5]*Gx2[67] + Gx1[6]*Gx2[80] + Gx1[7]*Gx2[93] + Gx1[8]*Gx2[106] + Gx1[9]*Gx2[119] + Gx1[10]*Gx2[132] + Gx1[11]*Gx2[145] + Gx1[12]*Gx2[158];
Gx3[3] = + Gx1[0]*Gx2[3] + Gx1[1]*Gx2[16] + Gx1[2]*Gx2[29] + Gx1[3]*Gx2[42] + Gx1[4]*Gx2[55] + Gx1[5]*Gx2[68] + Gx1[6]*Gx2[81] + Gx1[7]*Gx2[94] + Gx1[8]*Gx2[107] + Gx1[9]*Gx2[120] + Gx1[10]*Gx2[133] + Gx1[11]*Gx2[146] + Gx1[12]*Gx2[159];
Gx3[4] = + Gx1[0]*Gx2[4] + Gx1[1]*Gx2[17] + Gx1[2]*Gx2[30] + Gx1[3]*Gx2[43] + Gx1[4]*Gx2[56] + Gx1[5]*Gx2[69] + Gx1[6]*Gx2[82] + Gx1[7]*Gx2[95] + Gx1[8]*Gx2[108] + Gx1[9]*Gx2[121] + Gx1[10]*Gx2[134] + Gx1[11]*Gx2[147] + Gx1[12]*Gx2[160];
Gx3[5] = + Gx1[0]*Gx2[5] + Gx1[1]*Gx2[18] + Gx1[2]*Gx2[31] + Gx1[3]*Gx2[44] + Gx1[4]*Gx2[57] + Gx1[5]*Gx2[70] + Gx1[6]*Gx2[83] + Gx1[7]*Gx2[96] + Gx1[8]*Gx2[109] + Gx1[9]*Gx2[122] + Gx1[10]*Gx2[135] + Gx1[11]*Gx2[148] + Gx1[12]*Gx2[161];
Gx3[6] = + Gx1[0]*Gx2[6] + Gx1[1]*Gx2[19] + Gx1[2]*Gx2[32] + Gx1[3]*Gx2[45] + Gx1[4]*Gx2[58] + Gx1[5]*Gx2[71] + Gx1[6]*Gx2[84] + Gx1[7]*Gx2[97] + Gx1[8]*Gx2[110] + Gx1[9]*Gx2[123] + Gx1[10]*Gx2[136] + Gx1[11]*Gx2[149] + Gx1[12]*Gx2[162];
Gx3[7] = + Gx1[0]*Gx2[7] + Gx1[1]*Gx2[20] + Gx1[2]*Gx2[33] + Gx1[3]*Gx2[46] + Gx1[4]*Gx2[59] + Gx1[5]*Gx2[72] + Gx1[6]*Gx2[85] + Gx1[7]*Gx2[98] + Gx1[8]*Gx2[111] + Gx1[9]*Gx2[124] + Gx1[10]*Gx2[137] + Gx1[11]*Gx2[150] + Gx1[12]*Gx2[163];
Gx3[8] = + Gx1[0]*Gx2[8] + Gx1[1]*Gx2[21] + Gx1[2]*Gx2[34] + Gx1[3]*Gx2[47] + Gx1[4]*Gx2[60] + Gx1[5]*Gx2[73] + Gx1[6]*Gx2[86] + Gx1[7]*Gx2[99] + Gx1[8]*Gx2[112] + Gx1[9]*Gx2[125] + Gx1[10]*Gx2[138] + Gx1[11]*Gx2[151] + Gx1[12]*Gx2[164];
Gx3[9] = + Gx1[0]*Gx2[9] + Gx1[1]*Gx2[22] + Gx1[2]*Gx2[35] + Gx1[3]*Gx2[48] + Gx1[4]*Gx2[61] + Gx1[5]*Gx2[74] + Gx1[6]*Gx2[87] + Gx1[7]*Gx2[100] + Gx1[8]*Gx2[113] + Gx1[9]*Gx2[126] + Gx1[10]*Gx2[139] + Gx1[11]*Gx2[152] + Gx1[12]*Gx2[165];
Gx3[10] = + Gx1[0]*Gx2[10] + Gx1[1]*Gx2[23] + Gx1[2]*Gx2[36] + Gx1[3]*Gx2[49] + Gx1[4]*Gx2[62] + Gx1[5]*Gx2[75] + Gx1[6]*Gx2[88] + Gx1[7]*Gx2[101] + Gx1[8]*Gx2[114] + Gx1[9]*Gx2[127] + Gx1[10]*Gx2[140] + Gx1[11]*Gx2[153] + Gx1[12]*Gx2[166];
Gx3[11] = + Gx1[0]*Gx2[11] + Gx1[1]*Gx2[24] + Gx1[2]*Gx2[37] + Gx1[3]*Gx2[50] + Gx1[4]*Gx2[63] + Gx1[5]*Gx2[76] + Gx1[6]*Gx2[89] + Gx1[7]*Gx2[102] + Gx1[8]*Gx2[115] + Gx1[9]*Gx2[128] + Gx1[10]*Gx2[141] + Gx1[11]*Gx2[154] + Gx1[12]*Gx2[167];
Gx3[12] = + Gx1[0]*Gx2[12] + Gx1[1]*Gx2[25] + Gx1[2]*Gx2[38] + Gx1[3]*Gx2[51] + Gx1[4]*Gx2[64] + Gx1[5]*Gx2[77] + Gx1[6]*Gx2[90] + Gx1[7]*Gx2[103] + Gx1[8]*Gx2[116] + Gx1[9]*Gx2[129] + Gx1[10]*Gx2[142] + Gx1[11]*Gx2[155] + Gx1[12]*Gx2[168];
Gx3[13] = + Gx1[13]*Gx2[0] + Gx1[14]*Gx2[13] + Gx1[15]*Gx2[26] + Gx1[16]*Gx2[39] + Gx1[17]*Gx2[52] + Gx1[18]*Gx2[65] + Gx1[19]*Gx2[78] + Gx1[20]*Gx2[91] + Gx1[21]*Gx2[104] + Gx1[22]*Gx2[117] + Gx1[23]*Gx2[130] + Gx1[24]*Gx2[143] + Gx1[25]*Gx2[156];
Gx3[14] = + Gx1[13]*Gx2[1] + Gx1[14]*Gx2[14] + Gx1[15]*Gx2[27] + Gx1[16]*Gx2[40] + Gx1[17]*Gx2[53] + Gx1[18]*Gx2[66] + Gx1[19]*Gx2[79] + Gx1[20]*Gx2[92] + Gx1[21]*Gx2[105] + Gx1[22]*Gx2[118] + Gx1[23]*Gx2[131] + Gx1[24]*Gx2[144] + Gx1[25]*Gx2[157];
Gx3[15] = + Gx1[13]*Gx2[2] + Gx1[14]*Gx2[15] + Gx1[15]*Gx2[28] + Gx1[16]*Gx2[41] + Gx1[17]*Gx2[54] + Gx1[18]*Gx2[67] + Gx1[19]*Gx2[80] + Gx1[20]*Gx2[93] + Gx1[21]*Gx2[106] + Gx1[22]*Gx2[119] + Gx1[23]*Gx2[132] + Gx1[24]*Gx2[145] + Gx1[25]*Gx2[158];
Gx3[16] = + Gx1[13]*Gx2[3] + Gx1[14]*Gx2[16] + Gx1[15]*Gx2[29] + Gx1[16]*Gx2[42] + Gx1[17]*Gx2[55] + Gx1[18]*Gx2[68] + Gx1[19]*Gx2[81] + Gx1[20]*Gx2[94] + Gx1[21]*Gx2[107] + Gx1[22]*Gx2[120] + Gx1[23]*Gx2[133] + Gx1[24]*Gx2[146] + Gx1[25]*Gx2[159];
Gx3[17] = + Gx1[13]*Gx2[4] + Gx1[14]*Gx2[17] + Gx1[15]*Gx2[30] + Gx1[16]*Gx2[43] + Gx1[17]*Gx2[56] + Gx1[18]*Gx2[69] + Gx1[19]*Gx2[82] + Gx1[20]*Gx2[95] + Gx1[21]*Gx2[108] + Gx1[22]*Gx2[121] + Gx1[23]*Gx2[134] + Gx1[24]*Gx2[147] + Gx1[25]*Gx2[160];
Gx3[18] = + Gx1[13]*Gx2[5] + Gx1[14]*Gx2[18] + Gx1[15]*Gx2[31] + Gx1[16]*Gx2[44] + Gx1[17]*Gx2[57] + Gx1[18]*Gx2[70] + Gx1[19]*Gx2[83] + Gx1[20]*Gx2[96] + Gx1[21]*Gx2[109] + Gx1[22]*Gx2[122] + Gx1[23]*Gx2[135] + Gx1[24]*Gx2[148] + Gx1[25]*Gx2[161];
Gx3[19] = + Gx1[13]*Gx2[6] + Gx1[14]*Gx2[19] + Gx1[15]*Gx2[32] + Gx1[16]*Gx2[45] + Gx1[17]*Gx2[58] + Gx1[18]*Gx2[71] + Gx1[19]*Gx2[84] + Gx1[20]*Gx2[97] + Gx1[21]*Gx2[110] + Gx1[22]*Gx2[123] + Gx1[23]*Gx2[136] + Gx1[24]*Gx2[149] + Gx1[25]*Gx2[162];
Gx3[20] = + Gx1[13]*Gx2[7] + Gx1[14]*Gx2[20] + Gx1[15]*Gx2[33] + Gx1[16]*Gx2[46] + Gx1[17]*Gx2[59] + Gx1[18]*Gx2[72] + Gx1[19]*Gx2[85] + Gx1[20]*Gx2[98] + Gx1[21]*Gx2[111] + Gx1[22]*Gx2[124] + Gx1[23]*Gx2[137] + Gx1[24]*Gx2[150] + Gx1[25]*Gx2[163];
Gx3[21] = + Gx1[13]*Gx2[8] + Gx1[14]*Gx2[21] + Gx1[15]*Gx2[34] + Gx1[16]*Gx2[47] + Gx1[17]*Gx2[60] + Gx1[18]*Gx2[73] + Gx1[19]*Gx2[86] + Gx1[20]*Gx2[99] + Gx1[21]*Gx2[112] + Gx1[22]*Gx2[125] + Gx1[23]*Gx2[138] + Gx1[24]*Gx2[151] + Gx1[25]*Gx2[164];
Gx3[22] = + Gx1[13]*Gx2[9] + Gx1[14]*Gx2[22] + Gx1[15]*Gx2[35] + Gx1[16]*Gx2[48] + Gx1[17]*Gx2[61] + Gx1[18]*Gx2[74] + Gx1[19]*Gx2[87] + Gx1[20]*Gx2[100] + Gx1[21]*Gx2[113] + Gx1[22]*Gx2[126] + Gx1[23]*Gx2[139] + Gx1[24]*Gx2[152] + Gx1[25]*Gx2[165];
Gx3[23] = + Gx1[13]*Gx2[10] + Gx1[14]*Gx2[23] + Gx1[15]*Gx2[36] + Gx1[16]*Gx2[49] + Gx1[17]*Gx2[62] + Gx1[18]*Gx2[75] + Gx1[19]*Gx2[88] + Gx1[20]*Gx2[101] + Gx1[21]*Gx2[114] + Gx1[22]*Gx2[127] + Gx1[23]*Gx2[140] + Gx1[24]*Gx2[153] + Gx1[25]*Gx2[166];
Gx3[24] = + Gx1[13]*Gx2[11] + Gx1[14]*Gx2[24] + Gx1[15]*Gx2[37] + Gx1[16]*Gx2[50] + Gx1[17]*Gx2[63] + Gx1[18]*Gx2[76] + Gx1[19]*Gx2[89] + Gx1[20]*Gx2[102] + Gx1[21]*Gx2[115] + Gx1[22]*Gx2[128] + Gx1[23]*Gx2[141] + Gx1[24]*Gx2[154] + Gx1[25]*Gx2[167];
Gx3[25] = + Gx1[13]*Gx2[12] + Gx1[14]*Gx2[25] + Gx1[15]*Gx2[38] + Gx1[16]*Gx2[51] + Gx1[17]*Gx2[64] + Gx1[18]*Gx2[77] + Gx1[19]*Gx2[90] + Gx1[20]*Gx2[103] + Gx1[21]*Gx2[116] + Gx1[22]*Gx2[129] + Gx1[23]*Gx2[142] + Gx1[24]*Gx2[155] + Gx1[25]*Gx2[168];
Gx3[26] = + Gx1[26]*Gx2[0] + Gx1[27]*Gx2[13] + Gx1[28]*Gx2[26] + Gx1[29]*Gx2[39] + Gx1[30]*Gx2[52] + Gx1[31]*Gx2[65] + Gx1[32]*Gx2[78] + Gx1[33]*Gx2[91] + Gx1[34]*Gx2[104] + Gx1[35]*Gx2[117] + Gx1[36]*Gx2[130] + Gx1[37]*Gx2[143] + Gx1[38]*Gx2[156];
Gx3[27] = + Gx1[26]*Gx2[1] + Gx1[27]*Gx2[14] + Gx1[28]*Gx2[27] + Gx1[29]*Gx2[40] + Gx1[30]*Gx2[53] + Gx1[31]*Gx2[66] + Gx1[32]*Gx2[79] + Gx1[33]*Gx2[92] + Gx1[34]*Gx2[105] + Gx1[35]*Gx2[118] + Gx1[36]*Gx2[131] + Gx1[37]*Gx2[144] + Gx1[38]*Gx2[157];
Gx3[28] = + Gx1[26]*Gx2[2] + Gx1[27]*Gx2[15] + Gx1[28]*Gx2[28] + Gx1[29]*Gx2[41] + Gx1[30]*Gx2[54] + Gx1[31]*Gx2[67] + Gx1[32]*Gx2[80] + Gx1[33]*Gx2[93] + Gx1[34]*Gx2[106] + Gx1[35]*Gx2[119] + Gx1[36]*Gx2[132] + Gx1[37]*Gx2[145] + Gx1[38]*Gx2[158];
Gx3[29] = + Gx1[26]*Gx2[3] + Gx1[27]*Gx2[16] + Gx1[28]*Gx2[29] + Gx1[29]*Gx2[42] + Gx1[30]*Gx2[55] + Gx1[31]*Gx2[68] + Gx1[32]*Gx2[81] + Gx1[33]*Gx2[94] + Gx1[34]*Gx2[107] + Gx1[35]*Gx2[120] + Gx1[36]*Gx2[133] + Gx1[37]*Gx2[146] + Gx1[38]*Gx2[159];
Gx3[30] = + Gx1[26]*Gx2[4] + Gx1[27]*Gx2[17] + Gx1[28]*Gx2[30] + Gx1[29]*Gx2[43] + Gx1[30]*Gx2[56] + Gx1[31]*Gx2[69] + Gx1[32]*Gx2[82] + Gx1[33]*Gx2[95] + Gx1[34]*Gx2[108] + Gx1[35]*Gx2[121] + Gx1[36]*Gx2[134] + Gx1[37]*Gx2[147] + Gx1[38]*Gx2[160];
Gx3[31] = + Gx1[26]*Gx2[5] + Gx1[27]*Gx2[18] + Gx1[28]*Gx2[31] + Gx1[29]*Gx2[44] + Gx1[30]*Gx2[57] + Gx1[31]*Gx2[70] + Gx1[32]*Gx2[83] + Gx1[33]*Gx2[96] + Gx1[34]*Gx2[109] + Gx1[35]*Gx2[122] + Gx1[36]*Gx2[135] + Gx1[37]*Gx2[148] + Gx1[38]*Gx2[161];
Gx3[32] = + Gx1[26]*Gx2[6] + Gx1[27]*Gx2[19] + Gx1[28]*Gx2[32] + Gx1[29]*Gx2[45] + Gx1[30]*Gx2[58] + Gx1[31]*Gx2[71] + Gx1[32]*Gx2[84] + Gx1[33]*Gx2[97] + Gx1[34]*Gx2[110] + Gx1[35]*Gx2[123] + Gx1[36]*Gx2[136] + Gx1[37]*Gx2[149] + Gx1[38]*Gx2[162];
Gx3[33] = + Gx1[26]*Gx2[7] + Gx1[27]*Gx2[20] + Gx1[28]*Gx2[33] + Gx1[29]*Gx2[46] + Gx1[30]*Gx2[59] + Gx1[31]*Gx2[72] + Gx1[32]*Gx2[85] + Gx1[33]*Gx2[98] + Gx1[34]*Gx2[111] + Gx1[35]*Gx2[124] + Gx1[36]*Gx2[137] + Gx1[37]*Gx2[150] + Gx1[38]*Gx2[163];
Gx3[34] = + Gx1[26]*Gx2[8] + Gx1[27]*Gx2[21] + Gx1[28]*Gx2[34] + Gx1[29]*Gx2[47] + Gx1[30]*Gx2[60] + Gx1[31]*Gx2[73] + Gx1[32]*Gx2[86] + Gx1[33]*Gx2[99] + Gx1[34]*Gx2[112] + Gx1[35]*Gx2[125] + Gx1[36]*Gx2[138] + Gx1[37]*Gx2[151] + Gx1[38]*Gx2[164];
Gx3[35] = + Gx1[26]*Gx2[9] + Gx1[27]*Gx2[22] + Gx1[28]*Gx2[35] + Gx1[29]*Gx2[48] + Gx1[30]*Gx2[61] + Gx1[31]*Gx2[74] + Gx1[32]*Gx2[87] + Gx1[33]*Gx2[100] + Gx1[34]*Gx2[113] + Gx1[35]*Gx2[126] + Gx1[36]*Gx2[139] + Gx1[37]*Gx2[152] + Gx1[38]*Gx2[165];
Gx3[36] = + Gx1[26]*Gx2[10] + Gx1[27]*Gx2[23] + Gx1[28]*Gx2[36] + Gx1[29]*Gx2[49] + Gx1[30]*Gx2[62] + Gx1[31]*Gx2[75] + Gx1[32]*Gx2[88] + Gx1[33]*Gx2[101] + Gx1[34]*Gx2[114] + Gx1[35]*Gx2[127] + Gx1[36]*Gx2[140] + Gx1[37]*Gx2[153] + Gx1[38]*Gx2[166];
Gx3[37] = + Gx1[26]*Gx2[11] + Gx1[27]*Gx2[24] + Gx1[28]*Gx2[37] + Gx1[29]*Gx2[50] + Gx1[30]*Gx2[63] + Gx1[31]*Gx2[76] + Gx1[32]*Gx2[89] + Gx1[33]*Gx2[102] + Gx1[34]*Gx2[115] + Gx1[35]*Gx2[128] + Gx1[36]*Gx2[141] + Gx1[37]*Gx2[154] + Gx1[38]*Gx2[167];
Gx3[38] = + Gx1[26]*Gx2[12] + Gx1[27]*Gx2[25] + Gx1[28]*Gx2[38] + Gx1[29]*Gx2[51] + Gx1[30]*Gx2[64] + Gx1[31]*Gx2[77] + Gx1[32]*Gx2[90] + Gx1[33]*Gx2[103] + Gx1[34]*Gx2[116] + Gx1[35]*Gx2[129] + Gx1[36]*Gx2[142] + Gx1[37]*Gx2[155] + Gx1[38]*Gx2[168];
Gx3[39] = + Gx1[39]*Gx2[0] + Gx1[40]*Gx2[13] + Gx1[41]*Gx2[26] + Gx1[42]*Gx2[39] + Gx1[43]*Gx2[52] + Gx1[44]*Gx2[65] + Gx1[45]*Gx2[78] + Gx1[46]*Gx2[91] + Gx1[47]*Gx2[104] + Gx1[48]*Gx2[117] + Gx1[49]*Gx2[130] + Gx1[50]*Gx2[143] + Gx1[51]*Gx2[156];
Gx3[40] = + Gx1[39]*Gx2[1] + Gx1[40]*Gx2[14] + Gx1[41]*Gx2[27] + Gx1[42]*Gx2[40] + Gx1[43]*Gx2[53] + Gx1[44]*Gx2[66] + Gx1[45]*Gx2[79] + Gx1[46]*Gx2[92] + Gx1[47]*Gx2[105] + Gx1[48]*Gx2[118] + Gx1[49]*Gx2[131] + Gx1[50]*Gx2[144] + Gx1[51]*Gx2[157];
Gx3[41] = + Gx1[39]*Gx2[2] + Gx1[40]*Gx2[15] + Gx1[41]*Gx2[28] + Gx1[42]*Gx2[41] + Gx1[43]*Gx2[54] + Gx1[44]*Gx2[67] + Gx1[45]*Gx2[80] + Gx1[46]*Gx2[93] + Gx1[47]*Gx2[106] + Gx1[48]*Gx2[119] + Gx1[49]*Gx2[132] + Gx1[50]*Gx2[145] + Gx1[51]*Gx2[158];
Gx3[42] = + Gx1[39]*Gx2[3] + Gx1[40]*Gx2[16] + Gx1[41]*Gx2[29] + Gx1[42]*Gx2[42] + Gx1[43]*Gx2[55] + Gx1[44]*Gx2[68] + Gx1[45]*Gx2[81] + Gx1[46]*Gx2[94] + Gx1[47]*Gx2[107] + Gx1[48]*Gx2[120] + Gx1[49]*Gx2[133] + Gx1[50]*Gx2[146] + Gx1[51]*Gx2[159];
Gx3[43] = + Gx1[39]*Gx2[4] + Gx1[40]*Gx2[17] + Gx1[41]*Gx2[30] + Gx1[42]*Gx2[43] + Gx1[43]*Gx2[56] + Gx1[44]*Gx2[69] + Gx1[45]*Gx2[82] + Gx1[46]*Gx2[95] + Gx1[47]*Gx2[108] + Gx1[48]*Gx2[121] + Gx1[49]*Gx2[134] + Gx1[50]*Gx2[147] + Gx1[51]*Gx2[160];
Gx3[44] = + Gx1[39]*Gx2[5] + Gx1[40]*Gx2[18] + Gx1[41]*Gx2[31] + Gx1[42]*Gx2[44] + Gx1[43]*Gx2[57] + Gx1[44]*Gx2[70] + Gx1[45]*Gx2[83] + Gx1[46]*Gx2[96] + Gx1[47]*Gx2[109] + Gx1[48]*Gx2[122] + Gx1[49]*Gx2[135] + Gx1[50]*Gx2[148] + Gx1[51]*Gx2[161];
Gx3[45] = + Gx1[39]*Gx2[6] + Gx1[40]*Gx2[19] + Gx1[41]*Gx2[32] + Gx1[42]*Gx2[45] + Gx1[43]*Gx2[58] + Gx1[44]*Gx2[71] + Gx1[45]*Gx2[84] + Gx1[46]*Gx2[97] + Gx1[47]*Gx2[110] + Gx1[48]*Gx2[123] + Gx1[49]*Gx2[136] + Gx1[50]*Gx2[149] + Gx1[51]*Gx2[162];
Gx3[46] = + Gx1[39]*Gx2[7] + Gx1[40]*Gx2[20] + Gx1[41]*Gx2[33] + Gx1[42]*Gx2[46] + Gx1[43]*Gx2[59] + Gx1[44]*Gx2[72] + Gx1[45]*Gx2[85] + Gx1[46]*Gx2[98] + Gx1[47]*Gx2[111] + Gx1[48]*Gx2[124] + Gx1[49]*Gx2[137] + Gx1[50]*Gx2[150] + Gx1[51]*Gx2[163];
Gx3[47] = + Gx1[39]*Gx2[8] + Gx1[40]*Gx2[21] + Gx1[41]*Gx2[34] + Gx1[42]*Gx2[47] + Gx1[43]*Gx2[60] + Gx1[44]*Gx2[73] + Gx1[45]*Gx2[86] + Gx1[46]*Gx2[99] + Gx1[47]*Gx2[112] + Gx1[48]*Gx2[125] + Gx1[49]*Gx2[138] + Gx1[50]*Gx2[151] + Gx1[51]*Gx2[164];
Gx3[48] = + Gx1[39]*Gx2[9] + Gx1[40]*Gx2[22] + Gx1[41]*Gx2[35] + Gx1[42]*Gx2[48] + Gx1[43]*Gx2[61] + Gx1[44]*Gx2[74] + Gx1[45]*Gx2[87] + Gx1[46]*Gx2[100] + Gx1[47]*Gx2[113] + Gx1[48]*Gx2[126] + Gx1[49]*Gx2[139] + Gx1[50]*Gx2[152] + Gx1[51]*Gx2[165];
Gx3[49] = + Gx1[39]*Gx2[10] + Gx1[40]*Gx2[23] + Gx1[41]*Gx2[36] + Gx1[42]*Gx2[49] + Gx1[43]*Gx2[62] + Gx1[44]*Gx2[75] + Gx1[45]*Gx2[88] + Gx1[46]*Gx2[101] + Gx1[47]*Gx2[114] + Gx1[48]*Gx2[127] + Gx1[49]*Gx2[140] + Gx1[50]*Gx2[153] + Gx1[51]*Gx2[166];
Gx3[50] = + Gx1[39]*Gx2[11] + Gx1[40]*Gx2[24] + Gx1[41]*Gx2[37] + Gx1[42]*Gx2[50] + Gx1[43]*Gx2[63] + Gx1[44]*Gx2[76] + Gx1[45]*Gx2[89] + Gx1[46]*Gx2[102] + Gx1[47]*Gx2[115] + Gx1[48]*Gx2[128] + Gx1[49]*Gx2[141] + Gx1[50]*Gx2[154] + Gx1[51]*Gx2[167];
Gx3[51] = + Gx1[39]*Gx2[12] + Gx1[40]*Gx2[25] + Gx1[41]*Gx2[38] + Gx1[42]*Gx2[51] + Gx1[43]*Gx2[64] + Gx1[44]*Gx2[77] + Gx1[45]*Gx2[90] + Gx1[46]*Gx2[103] + Gx1[47]*Gx2[116] + Gx1[48]*Gx2[129] + Gx1[49]*Gx2[142] + Gx1[50]*Gx2[155] + Gx1[51]*Gx2[168];
Gx3[52] = + Gx1[52]*Gx2[0] + Gx1[53]*Gx2[13] + Gx1[54]*Gx2[26] + Gx1[55]*Gx2[39] + Gx1[56]*Gx2[52] + Gx1[57]*Gx2[65] + Gx1[58]*Gx2[78] + Gx1[59]*Gx2[91] + Gx1[60]*Gx2[104] + Gx1[61]*Gx2[117] + Gx1[62]*Gx2[130] + Gx1[63]*Gx2[143] + Gx1[64]*Gx2[156];
Gx3[53] = + Gx1[52]*Gx2[1] + Gx1[53]*Gx2[14] + Gx1[54]*Gx2[27] + Gx1[55]*Gx2[40] + Gx1[56]*Gx2[53] + Gx1[57]*Gx2[66] + Gx1[58]*Gx2[79] + Gx1[59]*Gx2[92] + Gx1[60]*Gx2[105] + Gx1[61]*Gx2[118] + Gx1[62]*Gx2[131] + Gx1[63]*Gx2[144] + Gx1[64]*Gx2[157];
Gx3[54] = + Gx1[52]*Gx2[2] + Gx1[53]*Gx2[15] + Gx1[54]*Gx2[28] + Gx1[55]*Gx2[41] + Gx1[56]*Gx2[54] + Gx1[57]*Gx2[67] + Gx1[58]*Gx2[80] + Gx1[59]*Gx2[93] + Gx1[60]*Gx2[106] + Gx1[61]*Gx2[119] + Gx1[62]*Gx2[132] + Gx1[63]*Gx2[145] + Gx1[64]*Gx2[158];
Gx3[55] = + Gx1[52]*Gx2[3] + Gx1[53]*Gx2[16] + Gx1[54]*Gx2[29] + Gx1[55]*Gx2[42] + Gx1[56]*Gx2[55] + Gx1[57]*Gx2[68] + Gx1[58]*Gx2[81] + Gx1[59]*Gx2[94] + Gx1[60]*Gx2[107] + Gx1[61]*Gx2[120] + Gx1[62]*Gx2[133] + Gx1[63]*Gx2[146] + Gx1[64]*Gx2[159];
Gx3[56] = + Gx1[52]*Gx2[4] + Gx1[53]*Gx2[17] + Gx1[54]*Gx2[30] + Gx1[55]*Gx2[43] + Gx1[56]*Gx2[56] + Gx1[57]*Gx2[69] + Gx1[58]*Gx2[82] + Gx1[59]*Gx2[95] + Gx1[60]*Gx2[108] + Gx1[61]*Gx2[121] + Gx1[62]*Gx2[134] + Gx1[63]*Gx2[147] + Gx1[64]*Gx2[160];
Gx3[57] = + Gx1[52]*Gx2[5] + Gx1[53]*Gx2[18] + Gx1[54]*Gx2[31] + Gx1[55]*Gx2[44] + Gx1[56]*Gx2[57] + Gx1[57]*Gx2[70] + Gx1[58]*Gx2[83] + Gx1[59]*Gx2[96] + Gx1[60]*Gx2[109] + Gx1[61]*Gx2[122] + Gx1[62]*Gx2[135] + Gx1[63]*Gx2[148] + Gx1[64]*Gx2[161];
Gx3[58] = + Gx1[52]*Gx2[6] + Gx1[53]*Gx2[19] + Gx1[54]*Gx2[32] + Gx1[55]*Gx2[45] + Gx1[56]*Gx2[58] + Gx1[57]*Gx2[71] + Gx1[58]*Gx2[84] + Gx1[59]*Gx2[97] + Gx1[60]*Gx2[110] + Gx1[61]*Gx2[123] + Gx1[62]*Gx2[136] + Gx1[63]*Gx2[149] + Gx1[64]*Gx2[162];
Gx3[59] = + Gx1[52]*Gx2[7] + Gx1[53]*Gx2[20] + Gx1[54]*Gx2[33] + Gx1[55]*Gx2[46] + Gx1[56]*Gx2[59] + Gx1[57]*Gx2[72] + Gx1[58]*Gx2[85] + Gx1[59]*Gx2[98] + Gx1[60]*Gx2[111] + Gx1[61]*Gx2[124] + Gx1[62]*Gx2[137] + Gx1[63]*Gx2[150] + Gx1[64]*Gx2[163];
Gx3[60] = + Gx1[52]*Gx2[8] + Gx1[53]*Gx2[21] + Gx1[54]*Gx2[34] + Gx1[55]*Gx2[47] + Gx1[56]*Gx2[60] + Gx1[57]*Gx2[73] + Gx1[58]*Gx2[86] + Gx1[59]*Gx2[99] + Gx1[60]*Gx2[112] + Gx1[61]*Gx2[125] + Gx1[62]*Gx2[138] + Gx1[63]*Gx2[151] + Gx1[64]*Gx2[164];
Gx3[61] = + Gx1[52]*Gx2[9] + Gx1[53]*Gx2[22] + Gx1[54]*Gx2[35] + Gx1[55]*Gx2[48] + Gx1[56]*Gx2[61] + Gx1[57]*Gx2[74] + Gx1[58]*Gx2[87] + Gx1[59]*Gx2[100] + Gx1[60]*Gx2[113] + Gx1[61]*Gx2[126] + Gx1[62]*Gx2[139] + Gx1[63]*Gx2[152] + Gx1[64]*Gx2[165];
Gx3[62] = + Gx1[52]*Gx2[10] + Gx1[53]*Gx2[23] + Gx1[54]*Gx2[36] + Gx1[55]*Gx2[49] + Gx1[56]*Gx2[62] + Gx1[57]*Gx2[75] + Gx1[58]*Gx2[88] + Gx1[59]*Gx2[101] + Gx1[60]*Gx2[114] + Gx1[61]*Gx2[127] + Gx1[62]*Gx2[140] + Gx1[63]*Gx2[153] + Gx1[64]*Gx2[166];
Gx3[63] = + Gx1[52]*Gx2[11] + Gx1[53]*Gx2[24] + Gx1[54]*Gx2[37] + Gx1[55]*Gx2[50] + Gx1[56]*Gx2[63] + Gx1[57]*Gx2[76] + Gx1[58]*Gx2[89] + Gx1[59]*Gx2[102] + Gx1[60]*Gx2[115] + Gx1[61]*Gx2[128] + Gx1[62]*Gx2[141] + Gx1[63]*Gx2[154] + Gx1[64]*Gx2[167];
Gx3[64] = + Gx1[52]*Gx2[12] + Gx1[53]*Gx2[25] + Gx1[54]*Gx2[38] + Gx1[55]*Gx2[51] + Gx1[56]*Gx2[64] + Gx1[57]*Gx2[77] + Gx1[58]*Gx2[90] + Gx1[59]*Gx2[103] + Gx1[60]*Gx2[116] + Gx1[61]*Gx2[129] + Gx1[62]*Gx2[142] + Gx1[63]*Gx2[155] + Gx1[64]*Gx2[168];
Gx3[65] = + Gx1[65]*Gx2[0] + Gx1[66]*Gx2[13] + Gx1[67]*Gx2[26] + Gx1[68]*Gx2[39] + Gx1[69]*Gx2[52] + Gx1[70]*Gx2[65] + Gx1[71]*Gx2[78] + Gx1[72]*Gx2[91] + Gx1[73]*Gx2[104] + Gx1[74]*Gx2[117] + Gx1[75]*Gx2[130] + Gx1[76]*Gx2[143] + Gx1[77]*Gx2[156];
Gx3[66] = + Gx1[65]*Gx2[1] + Gx1[66]*Gx2[14] + Gx1[67]*Gx2[27] + Gx1[68]*Gx2[40] + Gx1[69]*Gx2[53] + Gx1[70]*Gx2[66] + Gx1[71]*Gx2[79] + Gx1[72]*Gx2[92] + Gx1[73]*Gx2[105] + Gx1[74]*Gx2[118] + Gx1[75]*Gx2[131] + Gx1[76]*Gx2[144] + Gx1[77]*Gx2[157];
Gx3[67] = + Gx1[65]*Gx2[2] + Gx1[66]*Gx2[15] + Gx1[67]*Gx2[28] + Gx1[68]*Gx2[41] + Gx1[69]*Gx2[54] + Gx1[70]*Gx2[67] + Gx1[71]*Gx2[80] + Gx1[72]*Gx2[93] + Gx1[73]*Gx2[106] + Gx1[74]*Gx2[119] + Gx1[75]*Gx2[132] + Gx1[76]*Gx2[145] + Gx1[77]*Gx2[158];
Gx3[68] = + Gx1[65]*Gx2[3] + Gx1[66]*Gx2[16] + Gx1[67]*Gx2[29] + Gx1[68]*Gx2[42] + Gx1[69]*Gx2[55] + Gx1[70]*Gx2[68] + Gx1[71]*Gx2[81] + Gx1[72]*Gx2[94] + Gx1[73]*Gx2[107] + Gx1[74]*Gx2[120] + Gx1[75]*Gx2[133] + Gx1[76]*Gx2[146] + Gx1[77]*Gx2[159];
Gx3[69] = + Gx1[65]*Gx2[4] + Gx1[66]*Gx2[17] + Gx1[67]*Gx2[30] + Gx1[68]*Gx2[43] + Gx1[69]*Gx2[56] + Gx1[70]*Gx2[69] + Gx1[71]*Gx2[82] + Gx1[72]*Gx2[95] + Gx1[73]*Gx2[108] + Gx1[74]*Gx2[121] + Gx1[75]*Gx2[134] + Gx1[76]*Gx2[147] + Gx1[77]*Gx2[160];
Gx3[70] = + Gx1[65]*Gx2[5] + Gx1[66]*Gx2[18] + Gx1[67]*Gx2[31] + Gx1[68]*Gx2[44] + Gx1[69]*Gx2[57] + Gx1[70]*Gx2[70] + Gx1[71]*Gx2[83] + Gx1[72]*Gx2[96] + Gx1[73]*Gx2[109] + Gx1[74]*Gx2[122] + Gx1[75]*Gx2[135] + Gx1[76]*Gx2[148] + Gx1[77]*Gx2[161];
Gx3[71] = + Gx1[65]*Gx2[6] + Gx1[66]*Gx2[19] + Gx1[67]*Gx2[32] + Gx1[68]*Gx2[45] + Gx1[69]*Gx2[58] + Gx1[70]*Gx2[71] + Gx1[71]*Gx2[84] + Gx1[72]*Gx2[97] + Gx1[73]*Gx2[110] + Gx1[74]*Gx2[123] + Gx1[75]*Gx2[136] + Gx1[76]*Gx2[149] + Gx1[77]*Gx2[162];
Gx3[72] = + Gx1[65]*Gx2[7] + Gx1[66]*Gx2[20] + Gx1[67]*Gx2[33] + Gx1[68]*Gx2[46] + Gx1[69]*Gx2[59] + Gx1[70]*Gx2[72] + Gx1[71]*Gx2[85] + Gx1[72]*Gx2[98] + Gx1[73]*Gx2[111] + Gx1[74]*Gx2[124] + Gx1[75]*Gx2[137] + Gx1[76]*Gx2[150] + Gx1[77]*Gx2[163];
Gx3[73] = + Gx1[65]*Gx2[8] + Gx1[66]*Gx2[21] + Gx1[67]*Gx2[34] + Gx1[68]*Gx2[47] + Gx1[69]*Gx2[60] + Gx1[70]*Gx2[73] + Gx1[71]*Gx2[86] + Gx1[72]*Gx2[99] + Gx1[73]*Gx2[112] + Gx1[74]*Gx2[125] + Gx1[75]*Gx2[138] + Gx1[76]*Gx2[151] + Gx1[77]*Gx2[164];
Gx3[74] = + Gx1[65]*Gx2[9] + Gx1[66]*Gx2[22] + Gx1[67]*Gx2[35] + Gx1[68]*Gx2[48] + Gx1[69]*Gx2[61] + Gx1[70]*Gx2[74] + Gx1[71]*Gx2[87] + Gx1[72]*Gx2[100] + Gx1[73]*Gx2[113] + Gx1[74]*Gx2[126] + Gx1[75]*Gx2[139] + Gx1[76]*Gx2[152] + Gx1[77]*Gx2[165];
Gx3[75] = + Gx1[65]*Gx2[10] + Gx1[66]*Gx2[23] + Gx1[67]*Gx2[36] + Gx1[68]*Gx2[49] + Gx1[69]*Gx2[62] + Gx1[70]*Gx2[75] + Gx1[71]*Gx2[88] + Gx1[72]*Gx2[101] + Gx1[73]*Gx2[114] + Gx1[74]*Gx2[127] + Gx1[75]*Gx2[140] + Gx1[76]*Gx2[153] + Gx1[77]*Gx2[166];
Gx3[76] = + Gx1[65]*Gx2[11] + Gx1[66]*Gx2[24] + Gx1[67]*Gx2[37] + Gx1[68]*Gx2[50] + Gx1[69]*Gx2[63] + Gx1[70]*Gx2[76] + Gx1[71]*Gx2[89] + Gx1[72]*Gx2[102] + Gx1[73]*Gx2[115] + Gx1[74]*Gx2[128] + Gx1[75]*Gx2[141] + Gx1[76]*Gx2[154] + Gx1[77]*Gx2[167];
Gx3[77] = + Gx1[65]*Gx2[12] + Gx1[66]*Gx2[25] + Gx1[67]*Gx2[38] + Gx1[68]*Gx2[51] + Gx1[69]*Gx2[64] + Gx1[70]*Gx2[77] + Gx1[71]*Gx2[90] + Gx1[72]*Gx2[103] + Gx1[73]*Gx2[116] + Gx1[74]*Gx2[129] + Gx1[75]*Gx2[142] + Gx1[76]*Gx2[155] + Gx1[77]*Gx2[168];
Gx3[78] = + Gx1[78]*Gx2[0] + Gx1[79]*Gx2[13] + Gx1[80]*Gx2[26] + Gx1[81]*Gx2[39] + Gx1[82]*Gx2[52] + Gx1[83]*Gx2[65] + Gx1[84]*Gx2[78] + Gx1[85]*Gx2[91] + Gx1[86]*Gx2[104] + Gx1[87]*Gx2[117] + Gx1[88]*Gx2[130] + Gx1[89]*Gx2[143] + Gx1[90]*Gx2[156];
Gx3[79] = + Gx1[78]*Gx2[1] + Gx1[79]*Gx2[14] + Gx1[80]*Gx2[27] + Gx1[81]*Gx2[40] + Gx1[82]*Gx2[53] + Gx1[83]*Gx2[66] + Gx1[84]*Gx2[79] + Gx1[85]*Gx2[92] + Gx1[86]*Gx2[105] + Gx1[87]*Gx2[118] + Gx1[88]*Gx2[131] + Gx1[89]*Gx2[144] + Gx1[90]*Gx2[157];
Gx3[80] = + Gx1[78]*Gx2[2] + Gx1[79]*Gx2[15] + Gx1[80]*Gx2[28] + Gx1[81]*Gx2[41] + Gx1[82]*Gx2[54] + Gx1[83]*Gx2[67] + Gx1[84]*Gx2[80] + Gx1[85]*Gx2[93] + Gx1[86]*Gx2[106] + Gx1[87]*Gx2[119] + Gx1[88]*Gx2[132] + Gx1[89]*Gx2[145] + Gx1[90]*Gx2[158];
Gx3[81] = + Gx1[78]*Gx2[3] + Gx1[79]*Gx2[16] + Gx1[80]*Gx2[29] + Gx1[81]*Gx2[42] + Gx1[82]*Gx2[55] + Gx1[83]*Gx2[68] + Gx1[84]*Gx2[81] + Gx1[85]*Gx2[94] + Gx1[86]*Gx2[107] + Gx1[87]*Gx2[120] + Gx1[88]*Gx2[133] + Gx1[89]*Gx2[146] + Gx1[90]*Gx2[159];
Gx3[82] = + Gx1[78]*Gx2[4] + Gx1[79]*Gx2[17] + Gx1[80]*Gx2[30] + Gx1[81]*Gx2[43] + Gx1[82]*Gx2[56] + Gx1[83]*Gx2[69] + Gx1[84]*Gx2[82] + Gx1[85]*Gx2[95] + Gx1[86]*Gx2[108] + Gx1[87]*Gx2[121] + Gx1[88]*Gx2[134] + Gx1[89]*Gx2[147] + Gx1[90]*Gx2[160];
Gx3[83] = + Gx1[78]*Gx2[5] + Gx1[79]*Gx2[18] + Gx1[80]*Gx2[31] + Gx1[81]*Gx2[44] + Gx1[82]*Gx2[57] + Gx1[83]*Gx2[70] + Gx1[84]*Gx2[83] + Gx1[85]*Gx2[96] + Gx1[86]*Gx2[109] + Gx1[87]*Gx2[122] + Gx1[88]*Gx2[135] + Gx1[89]*Gx2[148] + Gx1[90]*Gx2[161];
Gx3[84] = + Gx1[78]*Gx2[6] + Gx1[79]*Gx2[19] + Gx1[80]*Gx2[32] + Gx1[81]*Gx2[45] + Gx1[82]*Gx2[58] + Gx1[83]*Gx2[71] + Gx1[84]*Gx2[84] + Gx1[85]*Gx2[97] + Gx1[86]*Gx2[110] + Gx1[87]*Gx2[123] + Gx1[88]*Gx2[136] + Gx1[89]*Gx2[149] + Gx1[90]*Gx2[162];
Gx3[85] = + Gx1[78]*Gx2[7] + Gx1[79]*Gx2[20] + Gx1[80]*Gx2[33] + Gx1[81]*Gx2[46] + Gx1[82]*Gx2[59] + Gx1[83]*Gx2[72] + Gx1[84]*Gx2[85] + Gx1[85]*Gx2[98] + Gx1[86]*Gx2[111] + Gx1[87]*Gx2[124] + Gx1[88]*Gx2[137] + Gx1[89]*Gx2[150] + Gx1[90]*Gx2[163];
Gx3[86] = + Gx1[78]*Gx2[8] + Gx1[79]*Gx2[21] + Gx1[80]*Gx2[34] + Gx1[81]*Gx2[47] + Gx1[82]*Gx2[60] + Gx1[83]*Gx2[73] + Gx1[84]*Gx2[86] + Gx1[85]*Gx2[99] + Gx1[86]*Gx2[112] + Gx1[87]*Gx2[125] + Gx1[88]*Gx2[138] + Gx1[89]*Gx2[151] + Gx1[90]*Gx2[164];
Gx3[87] = + Gx1[78]*Gx2[9] + Gx1[79]*Gx2[22] + Gx1[80]*Gx2[35] + Gx1[81]*Gx2[48] + Gx1[82]*Gx2[61] + Gx1[83]*Gx2[74] + Gx1[84]*Gx2[87] + Gx1[85]*Gx2[100] + Gx1[86]*Gx2[113] + Gx1[87]*Gx2[126] + Gx1[88]*Gx2[139] + Gx1[89]*Gx2[152] + Gx1[90]*Gx2[165];
Gx3[88] = + Gx1[78]*Gx2[10] + Gx1[79]*Gx2[23] + Gx1[80]*Gx2[36] + Gx1[81]*Gx2[49] + Gx1[82]*Gx2[62] + Gx1[83]*Gx2[75] + Gx1[84]*Gx2[88] + Gx1[85]*Gx2[101] + Gx1[86]*Gx2[114] + Gx1[87]*Gx2[127] + Gx1[88]*Gx2[140] + Gx1[89]*Gx2[153] + Gx1[90]*Gx2[166];
Gx3[89] = + Gx1[78]*Gx2[11] + Gx1[79]*Gx2[24] + Gx1[80]*Gx2[37] + Gx1[81]*Gx2[50] + Gx1[82]*Gx2[63] + Gx1[83]*Gx2[76] + Gx1[84]*Gx2[89] + Gx1[85]*Gx2[102] + Gx1[86]*Gx2[115] + Gx1[87]*Gx2[128] + Gx1[88]*Gx2[141] + Gx1[89]*Gx2[154] + Gx1[90]*Gx2[167];
Gx3[90] = + Gx1[78]*Gx2[12] + Gx1[79]*Gx2[25] + Gx1[80]*Gx2[38] + Gx1[81]*Gx2[51] + Gx1[82]*Gx2[64] + Gx1[83]*Gx2[77] + Gx1[84]*Gx2[90] + Gx1[85]*Gx2[103] + Gx1[86]*Gx2[116] + Gx1[87]*Gx2[129] + Gx1[88]*Gx2[142] + Gx1[89]*Gx2[155] + Gx1[90]*Gx2[168];
Gx3[91] = + Gx1[91]*Gx2[0] + Gx1[92]*Gx2[13] + Gx1[93]*Gx2[26] + Gx1[94]*Gx2[39] + Gx1[95]*Gx2[52] + Gx1[96]*Gx2[65] + Gx1[97]*Gx2[78] + Gx1[98]*Gx2[91] + Gx1[99]*Gx2[104] + Gx1[100]*Gx2[117] + Gx1[101]*Gx2[130] + Gx1[102]*Gx2[143] + Gx1[103]*Gx2[156];
Gx3[92] = + Gx1[91]*Gx2[1] + Gx1[92]*Gx2[14] + Gx1[93]*Gx2[27] + Gx1[94]*Gx2[40] + Gx1[95]*Gx2[53] + Gx1[96]*Gx2[66] + Gx1[97]*Gx2[79] + Gx1[98]*Gx2[92] + Gx1[99]*Gx2[105] + Gx1[100]*Gx2[118] + Gx1[101]*Gx2[131] + Gx1[102]*Gx2[144] + Gx1[103]*Gx2[157];
Gx3[93] = + Gx1[91]*Gx2[2] + Gx1[92]*Gx2[15] + Gx1[93]*Gx2[28] + Gx1[94]*Gx2[41] + Gx1[95]*Gx2[54] + Gx1[96]*Gx2[67] + Gx1[97]*Gx2[80] + Gx1[98]*Gx2[93] + Gx1[99]*Gx2[106] + Gx1[100]*Gx2[119] + Gx1[101]*Gx2[132] + Gx1[102]*Gx2[145] + Gx1[103]*Gx2[158];
Gx3[94] = + Gx1[91]*Gx2[3] + Gx1[92]*Gx2[16] + Gx1[93]*Gx2[29] + Gx1[94]*Gx2[42] + Gx1[95]*Gx2[55] + Gx1[96]*Gx2[68] + Gx1[97]*Gx2[81] + Gx1[98]*Gx2[94] + Gx1[99]*Gx2[107] + Gx1[100]*Gx2[120] + Gx1[101]*Gx2[133] + Gx1[102]*Gx2[146] + Gx1[103]*Gx2[159];
Gx3[95] = + Gx1[91]*Gx2[4] + Gx1[92]*Gx2[17] + Gx1[93]*Gx2[30] + Gx1[94]*Gx2[43] + Gx1[95]*Gx2[56] + Gx1[96]*Gx2[69] + Gx1[97]*Gx2[82] + Gx1[98]*Gx2[95] + Gx1[99]*Gx2[108] + Gx1[100]*Gx2[121] + Gx1[101]*Gx2[134] + Gx1[102]*Gx2[147] + Gx1[103]*Gx2[160];
Gx3[96] = + Gx1[91]*Gx2[5] + Gx1[92]*Gx2[18] + Gx1[93]*Gx2[31] + Gx1[94]*Gx2[44] + Gx1[95]*Gx2[57] + Gx1[96]*Gx2[70] + Gx1[97]*Gx2[83] + Gx1[98]*Gx2[96] + Gx1[99]*Gx2[109] + Gx1[100]*Gx2[122] + Gx1[101]*Gx2[135] + Gx1[102]*Gx2[148] + Gx1[103]*Gx2[161];
Gx3[97] = + Gx1[91]*Gx2[6] + Gx1[92]*Gx2[19] + Gx1[93]*Gx2[32] + Gx1[94]*Gx2[45] + Gx1[95]*Gx2[58] + Gx1[96]*Gx2[71] + Gx1[97]*Gx2[84] + Gx1[98]*Gx2[97] + Gx1[99]*Gx2[110] + Gx1[100]*Gx2[123] + Gx1[101]*Gx2[136] + Gx1[102]*Gx2[149] + Gx1[103]*Gx2[162];
Gx3[98] = + Gx1[91]*Gx2[7] + Gx1[92]*Gx2[20] + Gx1[93]*Gx2[33] + Gx1[94]*Gx2[46] + Gx1[95]*Gx2[59] + Gx1[96]*Gx2[72] + Gx1[97]*Gx2[85] + Gx1[98]*Gx2[98] + Gx1[99]*Gx2[111] + Gx1[100]*Gx2[124] + Gx1[101]*Gx2[137] + Gx1[102]*Gx2[150] + Gx1[103]*Gx2[163];
Gx3[99] = + Gx1[91]*Gx2[8] + Gx1[92]*Gx2[21] + Gx1[93]*Gx2[34] + Gx1[94]*Gx2[47] + Gx1[95]*Gx2[60] + Gx1[96]*Gx2[73] + Gx1[97]*Gx2[86] + Gx1[98]*Gx2[99] + Gx1[99]*Gx2[112] + Gx1[100]*Gx2[125] + Gx1[101]*Gx2[138] + Gx1[102]*Gx2[151] + Gx1[103]*Gx2[164];
Gx3[100] = + Gx1[91]*Gx2[9] + Gx1[92]*Gx2[22] + Gx1[93]*Gx2[35] + Gx1[94]*Gx2[48] + Gx1[95]*Gx2[61] + Gx1[96]*Gx2[74] + Gx1[97]*Gx2[87] + Gx1[98]*Gx2[100] + Gx1[99]*Gx2[113] + Gx1[100]*Gx2[126] + Gx1[101]*Gx2[139] + Gx1[102]*Gx2[152] + Gx1[103]*Gx2[165];
Gx3[101] = + Gx1[91]*Gx2[10] + Gx1[92]*Gx2[23] + Gx1[93]*Gx2[36] + Gx1[94]*Gx2[49] + Gx1[95]*Gx2[62] + Gx1[96]*Gx2[75] + Gx1[97]*Gx2[88] + Gx1[98]*Gx2[101] + Gx1[99]*Gx2[114] + Gx1[100]*Gx2[127] + Gx1[101]*Gx2[140] + Gx1[102]*Gx2[153] + Gx1[103]*Gx2[166];
Gx3[102] = + Gx1[91]*Gx2[11] + Gx1[92]*Gx2[24] + Gx1[93]*Gx2[37] + Gx1[94]*Gx2[50] + Gx1[95]*Gx2[63] + Gx1[96]*Gx2[76] + Gx1[97]*Gx2[89] + Gx1[98]*Gx2[102] + Gx1[99]*Gx2[115] + Gx1[100]*Gx2[128] + Gx1[101]*Gx2[141] + Gx1[102]*Gx2[154] + Gx1[103]*Gx2[167];
Gx3[103] = + Gx1[91]*Gx2[12] + Gx1[92]*Gx2[25] + Gx1[93]*Gx2[38] + Gx1[94]*Gx2[51] + Gx1[95]*Gx2[64] + Gx1[96]*Gx2[77] + Gx1[97]*Gx2[90] + Gx1[98]*Gx2[103] + Gx1[99]*Gx2[116] + Gx1[100]*Gx2[129] + Gx1[101]*Gx2[142] + Gx1[102]*Gx2[155] + Gx1[103]*Gx2[168];
Gx3[104] = + Gx1[104]*Gx2[0] + Gx1[105]*Gx2[13] + Gx1[106]*Gx2[26] + Gx1[107]*Gx2[39] + Gx1[108]*Gx2[52] + Gx1[109]*Gx2[65] + Gx1[110]*Gx2[78] + Gx1[111]*Gx2[91] + Gx1[112]*Gx2[104] + Gx1[113]*Gx2[117] + Gx1[114]*Gx2[130] + Gx1[115]*Gx2[143] + Gx1[116]*Gx2[156];
Gx3[105] = + Gx1[104]*Gx2[1] + Gx1[105]*Gx2[14] + Gx1[106]*Gx2[27] + Gx1[107]*Gx2[40] + Gx1[108]*Gx2[53] + Gx1[109]*Gx2[66] + Gx1[110]*Gx2[79] + Gx1[111]*Gx2[92] + Gx1[112]*Gx2[105] + Gx1[113]*Gx2[118] + Gx1[114]*Gx2[131] + Gx1[115]*Gx2[144] + Gx1[116]*Gx2[157];
Gx3[106] = + Gx1[104]*Gx2[2] + Gx1[105]*Gx2[15] + Gx1[106]*Gx2[28] + Gx1[107]*Gx2[41] + Gx1[108]*Gx2[54] + Gx1[109]*Gx2[67] + Gx1[110]*Gx2[80] + Gx1[111]*Gx2[93] + Gx1[112]*Gx2[106] + Gx1[113]*Gx2[119] + Gx1[114]*Gx2[132] + Gx1[115]*Gx2[145] + Gx1[116]*Gx2[158];
Gx3[107] = + Gx1[104]*Gx2[3] + Gx1[105]*Gx2[16] + Gx1[106]*Gx2[29] + Gx1[107]*Gx2[42] + Gx1[108]*Gx2[55] + Gx1[109]*Gx2[68] + Gx1[110]*Gx2[81] + Gx1[111]*Gx2[94] + Gx1[112]*Gx2[107] + Gx1[113]*Gx2[120] + Gx1[114]*Gx2[133] + Gx1[115]*Gx2[146] + Gx1[116]*Gx2[159];
Gx3[108] = + Gx1[104]*Gx2[4] + Gx1[105]*Gx2[17] + Gx1[106]*Gx2[30] + Gx1[107]*Gx2[43] + Gx1[108]*Gx2[56] + Gx1[109]*Gx2[69] + Gx1[110]*Gx2[82] + Gx1[111]*Gx2[95] + Gx1[112]*Gx2[108] + Gx1[113]*Gx2[121] + Gx1[114]*Gx2[134] + Gx1[115]*Gx2[147] + Gx1[116]*Gx2[160];
Gx3[109] = + Gx1[104]*Gx2[5] + Gx1[105]*Gx2[18] + Gx1[106]*Gx2[31] + Gx1[107]*Gx2[44] + Gx1[108]*Gx2[57] + Gx1[109]*Gx2[70] + Gx1[110]*Gx2[83] + Gx1[111]*Gx2[96] + Gx1[112]*Gx2[109] + Gx1[113]*Gx2[122] + Gx1[114]*Gx2[135] + Gx1[115]*Gx2[148] + Gx1[116]*Gx2[161];
Gx3[110] = + Gx1[104]*Gx2[6] + Gx1[105]*Gx2[19] + Gx1[106]*Gx2[32] + Gx1[107]*Gx2[45] + Gx1[108]*Gx2[58] + Gx1[109]*Gx2[71] + Gx1[110]*Gx2[84] + Gx1[111]*Gx2[97] + Gx1[112]*Gx2[110] + Gx1[113]*Gx2[123] + Gx1[114]*Gx2[136] + Gx1[115]*Gx2[149] + Gx1[116]*Gx2[162];
Gx3[111] = + Gx1[104]*Gx2[7] + Gx1[105]*Gx2[20] + Gx1[106]*Gx2[33] + Gx1[107]*Gx2[46] + Gx1[108]*Gx2[59] + Gx1[109]*Gx2[72] + Gx1[110]*Gx2[85] + Gx1[111]*Gx2[98] + Gx1[112]*Gx2[111] + Gx1[113]*Gx2[124] + Gx1[114]*Gx2[137] + Gx1[115]*Gx2[150] + Gx1[116]*Gx2[163];
Gx3[112] = + Gx1[104]*Gx2[8] + Gx1[105]*Gx2[21] + Gx1[106]*Gx2[34] + Gx1[107]*Gx2[47] + Gx1[108]*Gx2[60] + Gx1[109]*Gx2[73] + Gx1[110]*Gx2[86] + Gx1[111]*Gx2[99] + Gx1[112]*Gx2[112] + Gx1[113]*Gx2[125] + Gx1[114]*Gx2[138] + Gx1[115]*Gx2[151] + Gx1[116]*Gx2[164];
Gx3[113] = + Gx1[104]*Gx2[9] + Gx1[105]*Gx2[22] + Gx1[106]*Gx2[35] + Gx1[107]*Gx2[48] + Gx1[108]*Gx2[61] + Gx1[109]*Gx2[74] + Gx1[110]*Gx2[87] + Gx1[111]*Gx2[100] + Gx1[112]*Gx2[113] + Gx1[113]*Gx2[126] + Gx1[114]*Gx2[139] + Gx1[115]*Gx2[152] + Gx1[116]*Gx2[165];
Gx3[114] = + Gx1[104]*Gx2[10] + Gx1[105]*Gx2[23] + Gx1[106]*Gx2[36] + Gx1[107]*Gx2[49] + Gx1[108]*Gx2[62] + Gx1[109]*Gx2[75] + Gx1[110]*Gx2[88] + Gx1[111]*Gx2[101] + Gx1[112]*Gx2[114] + Gx1[113]*Gx2[127] + Gx1[114]*Gx2[140] + Gx1[115]*Gx2[153] + Gx1[116]*Gx2[166];
Gx3[115] = + Gx1[104]*Gx2[11] + Gx1[105]*Gx2[24] + Gx1[106]*Gx2[37] + Gx1[107]*Gx2[50] + Gx1[108]*Gx2[63] + Gx1[109]*Gx2[76] + Gx1[110]*Gx2[89] + Gx1[111]*Gx2[102] + Gx1[112]*Gx2[115] + Gx1[113]*Gx2[128] + Gx1[114]*Gx2[141] + Gx1[115]*Gx2[154] + Gx1[116]*Gx2[167];
Gx3[116] = + Gx1[104]*Gx2[12] + Gx1[105]*Gx2[25] + Gx1[106]*Gx2[38] + Gx1[107]*Gx2[51] + Gx1[108]*Gx2[64] + Gx1[109]*Gx2[77] + Gx1[110]*Gx2[90] + Gx1[111]*Gx2[103] + Gx1[112]*Gx2[116] + Gx1[113]*Gx2[129] + Gx1[114]*Gx2[142] + Gx1[115]*Gx2[155] + Gx1[116]*Gx2[168];
Gx3[117] = + Gx1[117]*Gx2[0] + Gx1[118]*Gx2[13] + Gx1[119]*Gx2[26] + Gx1[120]*Gx2[39] + Gx1[121]*Gx2[52] + Gx1[122]*Gx2[65] + Gx1[123]*Gx2[78] + Gx1[124]*Gx2[91] + Gx1[125]*Gx2[104] + Gx1[126]*Gx2[117] + Gx1[127]*Gx2[130] + Gx1[128]*Gx2[143] + Gx1[129]*Gx2[156];
Gx3[118] = + Gx1[117]*Gx2[1] + Gx1[118]*Gx2[14] + Gx1[119]*Gx2[27] + Gx1[120]*Gx2[40] + Gx1[121]*Gx2[53] + Gx1[122]*Gx2[66] + Gx1[123]*Gx2[79] + Gx1[124]*Gx2[92] + Gx1[125]*Gx2[105] + Gx1[126]*Gx2[118] + Gx1[127]*Gx2[131] + Gx1[128]*Gx2[144] + Gx1[129]*Gx2[157];
Gx3[119] = + Gx1[117]*Gx2[2] + Gx1[118]*Gx2[15] + Gx1[119]*Gx2[28] + Gx1[120]*Gx2[41] + Gx1[121]*Gx2[54] + Gx1[122]*Gx2[67] + Gx1[123]*Gx2[80] + Gx1[124]*Gx2[93] + Gx1[125]*Gx2[106] + Gx1[126]*Gx2[119] + Gx1[127]*Gx2[132] + Gx1[128]*Gx2[145] + Gx1[129]*Gx2[158];
Gx3[120] = + Gx1[117]*Gx2[3] + Gx1[118]*Gx2[16] + Gx1[119]*Gx2[29] + Gx1[120]*Gx2[42] + Gx1[121]*Gx2[55] + Gx1[122]*Gx2[68] + Gx1[123]*Gx2[81] + Gx1[124]*Gx2[94] + Gx1[125]*Gx2[107] + Gx1[126]*Gx2[120] + Gx1[127]*Gx2[133] + Gx1[128]*Gx2[146] + Gx1[129]*Gx2[159];
Gx3[121] = + Gx1[117]*Gx2[4] + Gx1[118]*Gx2[17] + Gx1[119]*Gx2[30] + Gx1[120]*Gx2[43] + Gx1[121]*Gx2[56] + Gx1[122]*Gx2[69] + Gx1[123]*Gx2[82] + Gx1[124]*Gx2[95] + Gx1[125]*Gx2[108] + Gx1[126]*Gx2[121] + Gx1[127]*Gx2[134] + Gx1[128]*Gx2[147] + Gx1[129]*Gx2[160];
Gx3[122] = + Gx1[117]*Gx2[5] + Gx1[118]*Gx2[18] + Gx1[119]*Gx2[31] + Gx1[120]*Gx2[44] + Gx1[121]*Gx2[57] + Gx1[122]*Gx2[70] + Gx1[123]*Gx2[83] + Gx1[124]*Gx2[96] + Gx1[125]*Gx2[109] + Gx1[126]*Gx2[122] + Gx1[127]*Gx2[135] + Gx1[128]*Gx2[148] + Gx1[129]*Gx2[161];
Gx3[123] = + Gx1[117]*Gx2[6] + Gx1[118]*Gx2[19] + Gx1[119]*Gx2[32] + Gx1[120]*Gx2[45] + Gx1[121]*Gx2[58] + Gx1[122]*Gx2[71] + Gx1[123]*Gx2[84] + Gx1[124]*Gx2[97] + Gx1[125]*Gx2[110] + Gx1[126]*Gx2[123] + Gx1[127]*Gx2[136] + Gx1[128]*Gx2[149] + Gx1[129]*Gx2[162];
Gx3[124] = + Gx1[117]*Gx2[7] + Gx1[118]*Gx2[20] + Gx1[119]*Gx2[33] + Gx1[120]*Gx2[46] + Gx1[121]*Gx2[59] + Gx1[122]*Gx2[72] + Gx1[123]*Gx2[85] + Gx1[124]*Gx2[98] + Gx1[125]*Gx2[111] + Gx1[126]*Gx2[124] + Gx1[127]*Gx2[137] + Gx1[128]*Gx2[150] + Gx1[129]*Gx2[163];
Gx3[125] = + Gx1[117]*Gx2[8] + Gx1[118]*Gx2[21] + Gx1[119]*Gx2[34] + Gx1[120]*Gx2[47] + Gx1[121]*Gx2[60] + Gx1[122]*Gx2[73] + Gx1[123]*Gx2[86] + Gx1[124]*Gx2[99] + Gx1[125]*Gx2[112] + Gx1[126]*Gx2[125] + Gx1[127]*Gx2[138] + Gx1[128]*Gx2[151] + Gx1[129]*Gx2[164];
Gx3[126] = + Gx1[117]*Gx2[9] + Gx1[118]*Gx2[22] + Gx1[119]*Gx2[35] + Gx1[120]*Gx2[48] + Gx1[121]*Gx2[61] + Gx1[122]*Gx2[74] + Gx1[123]*Gx2[87] + Gx1[124]*Gx2[100] + Gx1[125]*Gx2[113] + Gx1[126]*Gx2[126] + Gx1[127]*Gx2[139] + Gx1[128]*Gx2[152] + Gx1[129]*Gx2[165];
Gx3[127] = + Gx1[117]*Gx2[10] + Gx1[118]*Gx2[23] + Gx1[119]*Gx2[36] + Gx1[120]*Gx2[49] + Gx1[121]*Gx2[62] + Gx1[122]*Gx2[75] + Gx1[123]*Gx2[88] + Gx1[124]*Gx2[101] + Gx1[125]*Gx2[114] + Gx1[126]*Gx2[127] + Gx1[127]*Gx2[140] + Gx1[128]*Gx2[153] + Gx1[129]*Gx2[166];
Gx3[128] = + Gx1[117]*Gx2[11] + Gx1[118]*Gx2[24] + Gx1[119]*Gx2[37] + Gx1[120]*Gx2[50] + Gx1[121]*Gx2[63] + Gx1[122]*Gx2[76] + Gx1[123]*Gx2[89] + Gx1[124]*Gx2[102] + Gx1[125]*Gx2[115] + Gx1[126]*Gx2[128] + Gx1[127]*Gx2[141] + Gx1[128]*Gx2[154] + Gx1[129]*Gx2[167];
Gx3[129] = + Gx1[117]*Gx2[12] + Gx1[118]*Gx2[25] + Gx1[119]*Gx2[38] + Gx1[120]*Gx2[51] + Gx1[121]*Gx2[64] + Gx1[122]*Gx2[77] + Gx1[123]*Gx2[90] + Gx1[124]*Gx2[103] + Gx1[125]*Gx2[116] + Gx1[126]*Gx2[129] + Gx1[127]*Gx2[142] + Gx1[128]*Gx2[155] + Gx1[129]*Gx2[168];
Gx3[130] = + Gx1[130]*Gx2[0] + Gx1[131]*Gx2[13] + Gx1[132]*Gx2[26] + Gx1[133]*Gx2[39] + Gx1[134]*Gx2[52] + Gx1[135]*Gx2[65] + Gx1[136]*Gx2[78] + Gx1[137]*Gx2[91] + Gx1[138]*Gx2[104] + Gx1[139]*Gx2[117] + Gx1[140]*Gx2[130] + Gx1[141]*Gx2[143] + Gx1[142]*Gx2[156];
Gx3[131] = + Gx1[130]*Gx2[1] + Gx1[131]*Gx2[14] + Gx1[132]*Gx2[27] + Gx1[133]*Gx2[40] + Gx1[134]*Gx2[53] + Gx1[135]*Gx2[66] + Gx1[136]*Gx2[79] + Gx1[137]*Gx2[92] + Gx1[138]*Gx2[105] + Gx1[139]*Gx2[118] + Gx1[140]*Gx2[131] + Gx1[141]*Gx2[144] + Gx1[142]*Gx2[157];
Gx3[132] = + Gx1[130]*Gx2[2] + Gx1[131]*Gx2[15] + Gx1[132]*Gx2[28] + Gx1[133]*Gx2[41] + Gx1[134]*Gx2[54] + Gx1[135]*Gx2[67] + Gx1[136]*Gx2[80] + Gx1[137]*Gx2[93] + Gx1[138]*Gx2[106] + Gx1[139]*Gx2[119] + Gx1[140]*Gx2[132] + Gx1[141]*Gx2[145] + Gx1[142]*Gx2[158];
Gx3[133] = + Gx1[130]*Gx2[3] + Gx1[131]*Gx2[16] + Gx1[132]*Gx2[29] + Gx1[133]*Gx2[42] + Gx1[134]*Gx2[55] + Gx1[135]*Gx2[68] + Gx1[136]*Gx2[81] + Gx1[137]*Gx2[94] + Gx1[138]*Gx2[107] + Gx1[139]*Gx2[120] + Gx1[140]*Gx2[133] + Gx1[141]*Gx2[146] + Gx1[142]*Gx2[159];
Gx3[134] = + Gx1[130]*Gx2[4] + Gx1[131]*Gx2[17] + Gx1[132]*Gx2[30] + Gx1[133]*Gx2[43] + Gx1[134]*Gx2[56] + Gx1[135]*Gx2[69] + Gx1[136]*Gx2[82] + Gx1[137]*Gx2[95] + Gx1[138]*Gx2[108] + Gx1[139]*Gx2[121] + Gx1[140]*Gx2[134] + Gx1[141]*Gx2[147] + Gx1[142]*Gx2[160];
Gx3[135] = + Gx1[130]*Gx2[5] + Gx1[131]*Gx2[18] + Gx1[132]*Gx2[31] + Gx1[133]*Gx2[44] + Gx1[134]*Gx2[57] + Gx1[135]*Gx2[70] + Gx1[136]*Gx2[83] + Gx1[137]*Gx2[96] + Gx1[138]*Gx2[109] + Gx1[139]*Gx2[122] + Gx1[140]*Gx2[135] + Gx1[141]*Gx2[148] + Gx1[142]*Gx2[161];
Gx3[136] = + Gx1[130]*Gx2[6] + Gx1[131]*Gx2[19] + Gx1[132]*Gx2[32] + Gx1[133]*Gx2[45] + Gx1[134]*Gx2[58] + Gx1[135]*Gx2[71] + Gx1[136]*Gx2[84] + Gx1[137]*Gx2[97] + Gx1[138]*Gx2[110] + Gx1[139]*Gx2[123] + Gx1[140]*Gx2[136] + Gx1[141]*Gx2[149] + Gx1[142]*Gx2[162];
Gx3[137] = + Gx1[130]*Gx2[7] + Gx1[131]*Gx2[20] + Gx1[132]*Gx2[33] + Gx1[133]*Gx2[46] + Gx1[134]*Gx2[59] + Gx1[135]*Gx2[72] + Gx1[136]*Gx2[85] + Gx1[137]*Gx2[98] + Gx1[138]*Gx2[111] + Gx1[139]*Gx2[124] + Gx1[140]*Gx2[137] + Gx1[141]*Gx2[150] + Gx1[142]*Gx2[163];
Gx3[138] = + Gx1[130]*Gx2[8] + Gx1[131]*Gx2[21] + Gx1[132]*Gx2[34] + Gx1[133]*Gx2[47] + Gx1[134]*Gx2[60] + Gx1[135]*Gx2[73] + Gx1[136]*Gx2[86] + Gx1[137]*Gx2[99] + Gx1[138]*Gx2[112] + Gx1[139]*Gx2[125] + Gx1[140]*Gx2[138] + Gx1[141]*Gx2[151] + Gx1[142]*Gx2[164];
Gx3[139] = + Gx1[130]*Gx2[9] + Gx1[131]*Gx2[22] + Gx1[132]*Gx2[35] + Gx1[133]*Gx2[48] + Gx1[134]*Gx2[61] + Gx1[135]*Gx2[74] + Gx1[136]*Gx2[87] + Gx1[137]*Gx2[100] + Gx1[138]*Gx2[113] + Gx1[139]*Gx2[126] + Gx1[140]*Gx2[139] + Gx1[141]*Gx2[152] + Gx1[142]*Gx2[165];
Gx3[140] = + Gx1[130]*Gx2[10] + Gx1[131]*Gx2[23] + Gx1[132]*Gx2[36] + Gx1[133]*Gx2[49] + Gx1[134]*Gx2[62] + Gx1[135]*Gx2[75] + Gx1[136]*Gx2[88] + Gx1[137]*Gx2[101] + Gx1[138]*Gx2[114] + Gx1[139]*Gx2[127] + Gx1[140]*Gx2[140] + Gx1[141]*Gx2[153] + Gx1[142]*Gx2[166];
Gx3[141] = + Gx1[130]*Gx2[11] + Gx1[131]*Gx2[24] + Gx1[132]*Gx2[37] + Gx1[133]*Gx2[50] + Gx1[134]*Gx2[63] + Gx1[135]*Gx2[76] + Gx1[136]*Gx2[89] + Gx1[137]*Gx2[102] + Gx1[138]*Gx2[115] + Gx1[139]*Gx2[128] + Gx1[140]*Gx2[141] + Gx1[141]*Gx2[154] + Gx1[142]*Gx2[167];
Gx3[142] = + Gx1[130]*Gx2[12] + Gx1[131]*Gx2[25] + Gx1[132]*Gx2[38] + Gx1[133]*Gx2[51] + Gx1[134]*Gx2[64] + Gx1[135]*Gx2[77] + Gx1[136]*Gx2[90] + Gx1[137]*Gx2[103] + Gx1[138]*Gx2[116] + Gx1[139]*Gx2[129] + Gx1[140]*Gx2[142] + Gx1[141]*Gx2[155] + Gx1[142]*Gx2[168];
Gx3[143] = + Gx1[143]*Gx2[0] + Gx1[144]*Gx2[13] + Gx1[145]*Gx2[26] + Gx1[146]*Gx2[39] + Gx1[147]*Gx2[52] + Gx1[148]*Gx2[65] + Gx1[149]*Gx2[78] + Gx1[150]*Gx2[91] + Gx1[151]*Gx2[104] + Gx1[152]*Gx2[117] + Gx1[153]*Gx2[130] + Gx1[154]*Gx2[143] + Gx1[155]*Gx2[156];
Gx3[144] = + Gx1[143]*Gx2[1] + Gx1[144]*Gx2[14] + Gx1[145]*Gx2[27] + Gx1[146]*Gx2[40] + Gx1[147]*Gx2[53] + Gx1[148]*Gx2[66] + Gx1[149]*Gx2[79] + Gx1[150]*Gx2[92] + Gx1[151]*Gx2[105] + Gx1[152]*Gx2[118] + Gx1[153]*Gx2[131] + Gx1[154]*Gx2[144] + Gx1[155]*Gx2[157];
Gx3[145] = + Gx1[143]*Gx2[2] + Gx1[144]*Gx2[15] + Gx1[145]*Gx2[28] + Gx1[146]*Gx2[41] + Gx1[147]*Gx2[54] + Gx1[148]*Gx2[67] + Gx1[149]*Gx2[80] + Gx1[150]*Gx2[93] + Gx1[151]*Gx2[106] + Gx1[152]*Gx2[119] + Gx1[153]*Gx2[132] + Gx1[154]*Gx2[145] + Gx1[155]*Gx2[158];
Gx3[146] = + Gx1[143]*Gx2[3] + Gx1[144]*Gx2[16] + Gx1[145]*Gx2[29] + Gx1[146]*Gx2[42] + Gx1[147]*Gx2[55] + Gx1[148]*Gx2[68] + Gx1[149]*Gx2[81] + Gx1[150]*Gx2[94] + Gx1[151]*Gx2[107] + Gx1[152]*Gx2[120] + Gx1[153]*Gx2[133] + Gx1[154]*Gx2[146] + Gx1[155]*Gx2[159];
Gx3[147] = + Gx1[143]*Gx2[4] + Gx1[144]*Gx2[17] + Gx1[145]*Gx2[30] + Gx1[146]*Gx2[43] + Gx1[147]*Gx2[56] + Gx1[148]*Gx2[69] + Gx1[149]*Gx2[82] + Gx1[150]*Gx2[95] + Gx1[151]*Gx2[108] + Gx1[152]*Gx2[121] + Gx1[153]*Gx2[134] + Gx1[154]*Gx2[147] + Gx1[155]*Gx2[160];
Gx3[148] = + Gx1[143]*Gx2[5] + Gx1[144]*Gx2[18] + Gx1[145]*Gx2[31] + Gx1[146]*Gx2[44] + Gx1[147]*Gx2[57] + Gx1[148]*Gx2[70] + Gx1[149]*Gx2[83] + Gx1[150]*Gx2[96] + Gx1[151]*Gx2[109] + Gx1[152]*Gx2[122] + Gx1[153]*Gx2[135] + Gx1[154]*Gx2[148] + Gx1[155]*Gx2[161];
Gx3[149] = + Gx1[143]*Gx2[6] + Gx1[144]*Gx2[19] + Gx1[145]*Gx2[32] + Gx1[146]*Gx2[45] + Gx1[147]*Gx2[58] + Gx1[148]*Gx2[71] + Gx1[149]*Gx2[84] + Gx1[150]*Gx2[97] + Gx1[151]*Gx2[110] + Gx1[152]*Gx2[123] + Gx1[153]*Gx2[136] + Gx1[154]*Gx2[149] + Gx1[155]*Gx2[162];
Gx3[150] = + Gx1[143]*Gx2[7] + Gx1[144]*Gx2[20] + Gx1[145]*Gx2[33] + Gx1[146]*Gx2[46] + Gx1[147]*Gx2[59] + Gx1[148]*Gx2[72] + Gx1[149]*Gx2[85] + Gx1[150]*Gx2[98] + Gx1[151]*Gx2[111] + Gx1[152]*Gx2[124] + Gx1[153]*Gx2[137] + Gx1[154]*Gx2[150] + Gx1[155]*Gx2[163];
Gx3[151] = + Gx1[143]*Gx2[8] + Gx1[144]*Gx2[21] + Gx1[145]*Gx2[34] + Gx1[146]*Gx2[47] + Gx1[147]*Gx2[60] + Gx1[148]*Gx2[73] + Gx1[149]*Gx2[86] + Gx1[150]*Gx2[99] + Gx1[151]*Gx2[112] + Gx1[152]*Gx2[125] + Gx1[153]*Gx2[138] + Gx1[154]*Gx2[151] + Gx1[155]*Gx2[164];
Gx3[152] = + Gx1[143]*Gx2[9] + Gx1[144]*Gx2[22] + Gx1[145]*Gx2[35] + Gx1[146]*Gx2[48] + Gx1[147]*Gx2[61] + Gx1[148]*Gx2[74] + Gx1[149]*Gx2[87] + Gx1[150]*Gx2[100] + Gx1[151]*Gx2[113] + Gx1[152]*Gx2[126] + Gx1[153]*Gx2[139] + Gx1[154]*Gx2[152] + Gx1[155]*Gx2[165];
Gx3[153] = + Gx1[143]*Gx2[10] + Gx1[144]*Gx2[23] + Gx1[145]*Gx2[36] + Gx1[146]*Gx2[49] + Gx1[147]*Gx2[62] + Gx1[148]*Gx2[75] + Gx1[149]*Gx2[88] + Gx1[150]*Gx2[101] + Gx1[151]*Gx2[114] + Gx1[152]*Gx2[127] + Gx1[153]*Gx2[140] + Gx1[154]*Gx2[153] + Gx1[155]*Gx2[166];
Gx3[154] = + Gx1[143]*Gx2[11] + Gx1[144]*Gx2[24] + Gx1[145]*Gx2[37] + Gx1[146]*Gx2[50] + Gx1[147]*Gx2[63] + Gx1[148]*Gx2[76] + Gx1[149]*Gx2[89] + Gx1[150]*Gx2[102] + Gx1[151]*Gx2[115] + Gx1[152]*Gx2[128] + Gx1[153]*Gx2[141] + Gx1[154]*Gx2[154] + Gx1[155]*Gx2[167];
Gx3[155] = + Gx1[143]*Gx2[12] + Gx1[144]*Gx2[25] + Gx1[145]*Gx2[38] + Gx1[146]*Gx2[51] + Gx1[147]*Gx2[64] + Gx1[148]*Gx2[77] + Gx1[149]*Gx2[90] + Gx1[150]*Gx2[103] + Gx1[151]*Gx2[116] + Gx1[152]*Gx2[129] + Gx1[153]*Gx2[142] + Gx1[154]*Gx2[155] + Gx1[155]*Gx2[168];
Gx3[156] = + Gx1[156]*Gx2[0] + Gx1[157]*Gx2[13] + Gx1[158]*Gx2[26] + Gx1[159]*Gx2[39] + Gx1[160]*Gx2[52] + Gx1[161]*Gx2[65] + Gx1[162]*Gx2[78] + Gx1[163]*Gx2[91] + Gx1[164]*Gx2[104] + Gx1[165]*Gx2[117] + Gx1[166]*Gx2[130] + Gx1[167]*Gx2[143] + Gx1[168]*Gx2[156];
Gx3[157] = + Gx1[156]*Gx2[1] + Gx1[157]*Gx2[14] + Gx1[158]*Gx2[27] + Gx1[159]*Gx2[40] + Gx1[160]*Gx2[53] + Gx1[161]*Gx2[66] + Gx1[162]*Gx2[79] + Gx1[163]*Gx2[92] + Gx1[164]*Gx2[105] + Gx1[165]*Gx2[118] + Gx1[166]*Gx2[131] + Gx1[167]*Gx2[144] + Gx1[168]*Gx2[157];
Gx3[158] = + Gx1[156]*Gx2[2] + Gx1[157]*Gx2[15] + Gx1[158]*Gx2[28] + Gx1[159]*Gx2[41] + Gx1[160]*Gx2[54] + Gx1[161]*Gx2[67] + Gx1[162]*Gx2[80] + Gx1[163]*Gx2[93] + Gx1[164]*Gx2[106] + Gx1[165]*Gx2[119] + Gx1[166]*Gx2[132] + Gx1[167]*Gx2[145] + Gx1[168]*Gx2[158];
Gx3[159] = + Gx1[156]*Gx2[3] + Gx1[157]*Gx2[16] + Gx1[158]*Gx2[29] + Gx1[159]*Gx2[42] + Gx1[160]*Gx2[55] + Gx1[161]*Gx2[68] + Gx1[162]*Gx2[81] + Gx1[163]*Gx2[94] + Gx1[164]*Gx2[107] + Gx1[165]*Gx2[120] + Gx1[166]*Gx2[133] + Gx1[167]*Gx2[146] + Gx1[168]*Gx2[159];
Gx3[160] = + Gx1[156]*Gx2[4] + Gx1[157]*Gx2[17] + Gx1[158]*Gx2[30] + Gx1[159]*Gx2[43] + Gx1[160]*Gx2[56] + Gx1[161]*Gx2[69] + Gx1[162]*Gx2[82] + Gx1[163]*Gx2[95] + Gx1[164]*Gx2[108] + Gx1[165]*Gx2[121] + Gx1[166]*Gx2[134] + Gx1[167]*Gx2[147] + Gx1[168]*Gx2[160];
Gx3[161] = + Gx1[156]*Gx2[5] + Gx1[157]*Gx2[18] + Gx1[158]*Gx2[31] + Gx1[159]*Gx2[44] + Gx1[160]*Gx2[57] + Gx1[161]*Gx2[70] + Gx1[162]*Gx2[83] + Gx1[163]*Gx2[96] + Gx1[164]*Gx2[109] + Gx1[165]*Gx2[122] + Gx1[166]*Gx2[135] + Gx1[167]*Gx2[148] + Gx1[168]*Gx2[161];
Gx3[162] = + Gx1[156]*Gx2[6] + Gx1[157]*Gx2[19] + Gx1[158]*Gx2[32] + Gx1[159]*Gx2[45] + Gx1[160]*Gx2[58] + Gx1[161]*Gx2[71] + Gx1[162]*Gx2[84] + Gx1[163]*Gx2[97] + Gx1[164]*Gx2[110] + Gx1[165]*Gx2[123] + Gx1[166]*Gx2[136] + Gx1[167]*Gx2[149] + Gx1[168]*Gx2[162];
Gx3[163] = + Gx1[156]*Gx2[7] + Gx1[157]*Gx2[20] + Gx1[158]*Gx2[33] + Gx1[159]*Gx2[46] + Gx1[160]*Gx2[59] + Gx1[161]*Gx2[72] + Gx1[162]*Gx2[85] + Gx1[163]*Gx2[98] + Gx1[164]*Gx2[111] + Gx1[165]*Gx2[124] + Gx1[166]*Gx2[137] + Gx1[167]*Gx2[150] + Gx1[168]*Gx2[163];
Gx3[164] = + Gx1[156]*Gx2[8] + Gx1[157]*Gx2[21] + Gx1[158]*Gx2[34] + Gx1[159]*Gx2[47] + Gx1[160]*Gx2[60] + Gx1[161]*Gx2[73] + Gx1[162]*Gx2[86] + Gx1[163]*Gx2[99] + Gx1[164]*Gx2[112] + Gx1[165]*Gx2[125] + Gx1[166]*Gx2[138] + Gx1[167]*Gx2[151] + Gx1[168]*Gx2[164];
Gx3[165] = + Gx1[156]*Gx2[9] + Gx1[157]*Gx2[22] + Gx1[158]*Gx2[35] + Gx1[159]*Gx2[48] + Gx1[160]*Gx2[61] + Gx1[161]*Gx2[74] + Gx1[162]*Gx2[87] + Gx1[163]*Gx2[100] + Gx1[164]*Gx2[113] + Gx1[165]*Gx2[126] + Gx1[166]*Gx2[139] + Gx1[167]*Gx2[152] + Gx1[168]*Gx2[165];
Gx3[166] = + Gx1[156]*Gx2[10] + Gx1[157]*Gx2[23] + Gx1[158]*Gx2[36] + Gx1[159]*Gx2[49] + Gx1[160]*Gx2[62] + Gx1[161]*Gx2[75] + Gx1[162]*Gx2[88] + Gx1[163]*Gx2[101] + Gx1[164]*Gx2[114] + Gx1[165]*Gx2[127] + Gx1[166]*Gx2[140] + Gx1[167]*Gx2[153] + Gx1[168]*Gx2[166];
Gx3[167] = + Gx1[156]*Gx2[11] + Gx1[157]*Gx2[24] + Gx1[158]*Gx2[37] + Gx1[159]*Gx2[50] + Gx1[160]*Gx2[63] + Gx1[161]*Gx2[76] + Gx1[162]*Gx2[89] + Gx1[163]*Gx2[102] + Gx1[164]*Gx2[115] + Gx1[165]*Gx2[128] + Gx1[166]*Gx2[141] + Gx1[167]*Gx2[154] + Gx1[168]*Gx2[167];
Gx3[168] = + Gx1[156]*Gx2[12] + Gx1[157]*Gx2[25] + Gx1[158]*Gx2[38] + Gx1[159]*Gx2[51] + Gx1[160]*Gx2[64] + Gx1[161]*Gx2[77] + Gx1[162]*Gx2[90] + Gx1[163]*Gx2[103] + Gx1[164]*Gx2[116] + Gx1[165]*Gx2[129] + Gx1[166]*Gx2[142] + Gx1[167]*Gx2[155] + Gx1[168]*Gx2[168];
}

void acado_multGxGu( real_t* const Gx1, real_t* const Gu1, real_t* const Gu2 )
{
Gu2[0] = + Gx1[0]*Gu1[0] + Gx1[1]*Gu1[2] + Gx1[2]*Gu1[4] + Gx1[3]*Gu1[6] + Gx1[4]*Gu1[8] + Gx1[5]*Gu1[10] + Gx1[6]*Gu1[12] + Gx1[7]*Gu1[14] + Gx1[8]*Gu1[16] + Gx1[9]*Gu1[18] + Gx1[10]*Gu1[20] + Gx1[11]*Gu1[22] + Gx1[12]*Gu1[24];
Gu2[1] = + Gx1[0]*Gu1[1] + Gx1[1]*Gu1[3] + Gx1[2]*Gu1[5] + Gx1[3]*Gu1[7] + Gx1[4]*Gu1[9] + Gx1[5]*Gu1[11] + Gx1[6]*Gu1[13] + Gx1[7]*Gu1[15] + Gx1[8]*Gu1[17] + Gx1[9]*Gu1[19] + Gx1[10]*Gu1[21] + Gx1[11]*Gu1[23] + Gx1[12]*Gu1[25];
Gu2[2] = + Gx1[13]*Gu1[0] + Gx1[14]*Gu1[2] + Gx1[15]*Gu1[4] + Gx1[16]*Gu1[6] + Gx1[17]*Gu1[8] + Gx1[18]*Gu1[10] + Gx1[19]*Gu1[12] + Gx1[20]*Gu1[14] + Gx1[21]*Gu1[16] + Gx1[22]*Gu1[18] + Gx1[23]*Gu1[20] + Gx1[24]*Gu1[22] + Gx1[25]*Gu1[24];
Gu2[3] = + Gx1[13]*Gu1[1] + Gx1[14]*Gu1[3] + Gx1[15]*Gu1[5] + Gx1[16]*Gu1[7] + Gx1[17]*Gu1[9] + Gx1[18]*Gu1[11] + Gx1[19]*Gu1[13] + Gx1[20]*Gu1[15] + Gx1[21]*Gu1[17] + Gx1[22]*Gu1[19] + Gx1[23]*Gu1[21] + Gx1[24]*Gu1[23] + Gx1[25]*Gu1[25];
Gu2[4] = + Gx1[26]*Gu1[0] + Gx1[27]*Gu1[2] + Gx1[28]*Gu1[4] + Gx1[29]*Gu1[6] + Gx1[30]*Gu1[8] + Gx1[31]*Gu1[10] + Gx1[32]*Gu1[12] + Gx1[33]*Gu1[14] + Gx1[34]*Gu1[16] + Gx1[35]*Gu1[18] + Gx1[36]*Gu1[20] + Gx1[37]*Gu1[22] + Gx1[38]*Gu1[24];
Gu2[5] = + Gx1[26]*Gu1[1] + Gx1[27]*Gu1[3] + Gx1[28]*Gu1[5] + Gx1[29]*Gu1[7] + Gx1[30]*Gu1[9] + Gx1[31]*Gu1[11] + Gx1[32]*Gu1[13] + Gx1[33]*Gu1[15] + Gx1[34]*Gu1[17] + Gx1[35]*Gu1[19] + Gx1[36]*Gu1[21] + Gx1[37]*Gu1[23] + Gx1[38]*Gu1[25];
Gu2[6] = + Gx1[39]*Gu1[0] + Gx1[40]*Gu1[2] + Gx1[41]*Gu1[4] + Gx1[42]*Gu1[6] + Gx1[43]*Gu1[8] + Gx1[44]*Gu1[10] + Gx1[45]*Gu1[12] + Gx1[46]*Gu1[14] + Gx1[47]*Gu1[16] + Gx1[48]*Gu1[18] + Gx1[49]*Gu1[20] + Gx1[50]*Gu1[22] + Gx1[51]*Gu1[24];
Gu2[7] = + Gx1[39]*Gu1[1] + Gx1[40]*Gu1[3] + Gx1[41]*Gu1[5] + Gx1[42]*Gu1[7] + Gx1[43]*Gu1[9] + Gx1[44]*Gu1[11] + Gx1[45]*Gu1[13] + Gx1[46]*Gu1[15] + Gx1[47]*Gu1[17] + Gx1[48]*Gu1[19] + Gx1[49]*Gu1[21] + Gx1[50]*Gu1[23] + Gx1[51]*Gu1[25];
Gu2[8] = + Gx1[52]*Gu1[0] + Gx1[53]*Gu1[2] + Gx1[54]*Gu1[4] + Gx1[55]*Gu1[6] + Gx1[56]*Gu1[8] + Gx1[57]*Gu1[10] + Gx1[58]*Gu1[12] + Gx1[59]*Gu1[14] + Gx1[60]*Gu1[16] + Gx1[61]*Gu1[18] + Gx1[62]*Gu1[20] + Gx1[63]*Gu1[22] + Gx1[64]*Gu1[24];
Gu2[9] = + Gx1[52]*Gu1[1] + Gx1[53]*Gu1[3] + Gx1[54]*Gu1[5] + Gx1[55]*Gu1[7] + Gx1[56]*Gu1[9] + Gx1[57]*Gu1[11] + Gx1[58]*Gu1[13] + Gx1[59]*Gu1[15] + Gx1[60]*Gu1[17] + Gx1[61]*Gu1[19] + Gx1[62]*Gu1[21] + Gx1[63]*Gu1[23] + Gx1[64]*Gu1[25];
Gu2[10] = + Gx1[65]*Gu1[0] + Gx1[66]*Gu1[2] + Gx1[67]*Gu1[4] + Gx1[68]*Gu1[6] + Gx1[69]*Gu1[8] + Gx1[70]*Gu1[10] + Gx1[71]*Gu1[12] + Gx1[72]*Gu1[14] + Gx1[73]*Gu1[16] + Gx1[74]*Gu1[18] + Gx1[75]*Gu1[20] + Gx1[76]*Gu1[22] + Gx1[77]*Gu1[24];
Gu2[11] = + Gx1[65]*Gu1[1] + Gx1[66]*Gu1[3] + Gx1[67]*Gu1[5] + Gx1[68]*Gu1[7] + Gx1[69]*Gu1[9] + Gx1[70]*Gu1[11] + Gx1[71]*Gu1[13] + Gx1[72]*Gu1[15] + Gx1[73]*Gu1[17] + Gx1[74]*Gu1[19] + Gx1[75]*Gu1[21] + Gx1[76]*Gu1[23] + Gx1[77]*Gu1[25];
Gu2[12] = + Gx1[78]*Gu1[0] + Gx1[79]*Gu1[2] + Gx1[80]*Gu1[4] + Gx1[81]*Gu1[6] + Gx1[82]*Gu1[8] + Gx1[83]*Gu1[10] + Gx1[84]*Gu1[12] + Gx1[85]*Gu1[14] + Gx1[86]*Gu1[16] + Gx1[87]*Gu1[18] + Gx1[88]*Gu1[20] + Gx1[89]*Gu1[22] + Gx1[90]*Gu1[24];
Gu2[13] = + Gx1[78]*Gu1[1] + Gx1[79]*Gu1[3] + Gx1[80]*Gu1[5] + Gx1[81]*Gu1[7] + Gx1[82]*Gu1[9] + Gx1[83]*Gu1[11] + Gx1[84]*Gu1[13] + Gx1[85]*Gu1[15] + Gx1[86]*Gu1[17] + Gx1[87]*Gu1[19] + Gx1[88]*Gu1[21] + Gx1[89]*Gu1[23] + Gx1[90]*Gu1[25];
Gu2[14] = + Gx1[91]*Gu1[0] + Gx1[92]*Gu1[2] + Gx1[93]*Gu1[4] + Gx1[94]*Gu1[6] + Gx1[95]*Gu1[8] + Gx1[96]*Gu1[10] + Gx1[97]*Gu1[12] + Gx1[98]*Gu1[14] + Gx1[99]*Gu1[16] + Gx1[100]*Gu1[18] + Gx1[101]*Gu1[20] + Gx1[102]*Gu1[22] + Gx1[103]*Gu1[24];
Gu2[15] = + Gx1[91]*Gu1[1] + Gx1[92]*Gu1[3] + Gx1[93]*Gu1[5] + Gx1[94]*Gu1[7] + Gx1[95]*Gu1[9] + Gx1[96]*Gu1[11] + Gx1[97]*Gu1[13] + Gx1[98]*Gu1[15] + Gx1[99]*Gu1[17] + Gx1[100]*Gu1[19] + Gx1[101]*Gu1[21] + Gx1[102]*Gu1[23] + Gx1[103]*Gu1[25];
Gu2[16] = + Gx1[104]*Gu1[0] + Gx1[105]*Gu1[2] + Gx1[106]*Gu1[4] + Gx1[107]*Gu1[6] + Gx1[108]*Gu1[8] + Gx1[109]*Gu1[10] + Gx1[110]*Gu1[12] + Gx1[111]*Gu1[14] + Gx1[112]*Gu1[16] + Gx1[113]*Gu1[18] + Gx1[114]*Gu1[20] + Gx1[115]*Gu1[22] + Gx1[116]*Gu1[24];
Gu2[17] = + Gx1[104]*Gu1[1] + Gx1[105]*Gu1[3] + Gx1[106]*Gu1[5] + Gx1[107]*Gu1[7] + Gx1[108]*Gu1[9] + Gx1[109]*Gu1[11] + Gx1[110]*Gu1[13] + Gx1[111]*Gu1[15] + Gx1[112]*Gu1[17] + Gx1[113]*Gu1[19] + Gx1[114]*Gu1[21] + Gx1[115]*Gu1[23] + Gx1[116]*Gu1[25];
Gu2[18] = + Gx1[117]*Gu1[0] + Gx1[118]*Gu1[2] + Gx1[119]*Gu1[4] + Gx1[120]*Gu1[6] + Gx1[121]*Gu1[8] + Gx1[122]*Gu1[10] + Gx1[123]*Gu1[12] + Gx1[124]*Gu1[14] + Gx1[125]*Gu1[16] + Gx1[126]*Gu1[18] + Gx1[127]*Gu1[20] + Gx1[128]*Gu1[22] + Gx1[129]*Gu1[24];
Gu2[19] = + Gx1[117]*Gu1[1] + Gx1[118]*Gu1[3] + Gx1[119]*Gu1[5] + Gx1[120]*Gu1[7] + Gx1[121]*Gu1[9] + Gx1[122]*Gu1[11] + Gx1[123]*Gu1[13] + Gx1[124]*Gu1[15] + Gx1[125]*Gu1[17] + Gx1[126]*Gu1[19] + Gx1[127]*Gu1[21] + Gx1[128]*Gu1[23] + Gx1[129]*Gu1[25];
Gu2[20] = + Gx1[130]*Gu1[0] + Gx1[131]*Gu1[2] + Gx1[132]*Gu1[4] + Gx1[133]*Gu1[6] + Gx1[134]*Gu1[8] + Gx1[135]*Gu1[10] + Gx1[136]*Gu1[12] + Gx1[137]*Gu1[14] + Gx1[138]*Gu1[16] + Gx1[139]*Gu1[18] + Gx1[140]*Gu1[20] + Gx1[141]*Gu1[22] + Gx1[142]*Gu1[24];
Gu2[21] = + Gx1[130]*Gu1[1] + Gx1[131]*Gu1[3] + Gx1[132]*Gu1[5] + Gx1[133]*Gu1[7] + Gx1[134]*Gu1[9] + Gx1[135]*Gu1[11] + Gx1[136]*Gu1[13] + Gx1[137]*Gu1[15] + Gx1[138]*Gu1[17] + Gx1[139]*Gu1[19] + Gx1[140]*Gu1[21] + Gx1[141]*Gu1[23] + Gx1[142]*Gu1[25];
Gu2[22] = + Gx1[143]*Gu1[0] + Gx1[144]*Gu1[2] + Gx1[145]*Gu1[4] + Gx1[146]*Gu1[6] + Gx1[147]*Gu1[8] + Gx1[148]*Gu1[10] + Gx1[149]*Gu1[12] + Gx1[150]*Gu1[14] + Gx1[151]*Gu1[16] + Gx1[152]*Gu1[18] + Gx1[153]*Gu1[20] + Gx1[154]*Gu1[22] + Gx1[155]*Gu1[24];
Gu2[23] = + Gx1[143]*Gu1[1] + Gx1[144]*Gu1[3] + Gx1[145]*Gu1[5] + Gx1[146]*Gu1[7] + Gx1[147]*Gu1[9] + Gx1[148]*Gu1[11] + Gx1[149]*Gu1[13] + Gx1[150]*Gu1[15] + Gx1[151]*Gu1[17] + Gx1[152]*Gu1[19] + Gx1[153]*Gu1[21] + Gx1[154]*Gu1[23] + Gx1[155]*Gu1[25];
Gu2[24] = + Gx1[156]*Gu1[0] + Gx1[157]*Gu1[2] + Gx1[158]*Gu1[4] + Gx1[159]*Gu1[6] + Gx1[160]*Gu1[8] + Gx1[161]*Gu1[10] + Gx1[162]*Gu1[12] + Gx1[163]*Gu1[14] + Gx1[164]*Gu1[16] + Gx1[165]*Gu1[18] + Gx1[166]*Gu1[20] + Gx1[167]*Gu1[22] + Gx1[168]*Gu1[24];
Gu2[25] = + Gx1[156]*Gu1[1] + Gx1[157]*Gu1[3] + Gx1[158]*Gu1[5] + Gx1[159]*Gu1[7] + Gx1[160]*Gu1[9] + Gx1[161]*Gu1[11] + Gx1[162]*Gu1[13] + Gx1[163]*Gu1[15] + Gx1[164]*Gu1[17] + Gx1[165]*Gu1[19] + Gx1[166]*Gu1[21] + Gx1[167]*Gu1[23] + Gx1[168]*Gu1[25];
}

void acado_moveGuE( real_t* const Gu1, real_t* const Gu2 )
{
Gu2[0] = Gu1[0];
Gu2[1] = Gu1[1];
Gu2[2] = Gu1[2];
Gu2[3] = Gu1[3];
Gu2[4] = Gu1[4];
Gu2[5] = Gu1[5];
Gu2[6] = Gu1[6];
Gu2[7] = Gu1[7];
Gu2[8] = Gu1[8];
Gu2[9] = Gu1[9];
Gu2[10] = Gu1[10];
Gu2[11] = Gu1[11];
Gu2[12] = Gu1[12];
Gu2[13] = Gu1[13];
Gu2[14] = Gu1[14];
Gu2[15] = Gu1[15];
Gu2[16] = Gu1[16];
Gu2[17] = Gu1[17];
Gu2[18] = Gu1[18];
Gu2[19] = Gu1[19];
Gu2[20] = Gu1[20];
Gu2[21] = Gu1[21];
Gu2[22] = Gu1[22];
Gu2[23] = Gu1[23];
Gu2[24] = Gu1[24];
Gu2[25] = Gu1[25];
}

void acado_multBTW1( real_t* const Gu1, real_t* const Gu2, int iRow, int iCol )
{
acadoWorkspace.H[(iRow * 40) + (iCol * 2)] = + Gu1[0]*Gu2[0] + Gu1[2]*Gu2[2] + Gu1[4]*Gu2[4] + Gu1[6]*Gu2[6] + Gu1[8]*Gu2[8] + Gu1[10]*Gu2[10] + Gu1[12]*Gu2[12] + Gu1[14]*Gu2[14] + Gu1[16]*Gu2[16] + Gu1[18]*Gu2[18] + Gu1[20]*Gu2[20] + Gu1[22]*Gu2[22] + Gu1[24]*Gu2[24];
acadoWorkspace.H[(iRow * 40) + (iCol * 2 + 1)] = + Gu1[0]*Gu2[1] + Gu1[2]*Gu2[3] + Gu1[4]*Gu2[5] + Gu1[6]*Gu2[7] + Gu1[8]*Gu2[9] + Gu1[10]*Gu2[11] + Gu1[12]*Gu2[13] + Gu1[14]*Gu2[15] + Gu1[16]*Gu2[17] + Gu1[18]*Gu2[19] + Gu1[20]*Gu2[21] + Gu1[22]*Gu2[23] + Gu1[24]*Gu2[25];
acadoWorkspace.H[(iRow * 40 + 20) + (iCol * 2)] = + Gu1[1]*Gu2[0] + Gu1[3]*Gu2[2] + Gu1[5]*Gu2[4] + Gu1[7]*Gu2[6] + Gu1[9]*Gu2[8] + Gu1[11]*Gu2[10] + Gu1[13]*Gu2[12] + Gu1[15]*Gu2[14] + Gu1[17]*Gu2[16] + Gu1[19]*Gu2[18] + Gu1[21]*Gu2[20] + Gu1[23]*Gu2[22] + Gu1[25]*Gu2[24];
acadoWorkspace.H[(iRow * 40 + 20) + (iCol * 2 + 1)] = + Gu1[1]*Gu2[1] + Gu1[3]*Gu2[3] + Gu1[5]*Gu2[5] + Gu1[7]*Gu2[7] + Gu1[9]*Gu2[9] + Gu1[11]*Gu2[11] + Gu1[13]*Gu2[13] + Gu1[15]*Gu2[15] + Gu1[17]*Gu2[17] + Gu1[19]*Gu2[19] + Gu1[21]*Gu2[21] + Gu1[23]*Gu2[23] + Gu1[25]*Gu2[25];
}

void acado_multBTW1_R1( real_t* const R11, real_t* const Gu1, real_t* const Gu2, int iRow )
{
acadoWorkspace.H[iRow * 42] = + Gu1[0]*Gu2[0] + Gu1[2]*Gu2[2] + Gu1[4]*Gu2[4] + Gu1[6]*Gu2[6] + Gu1[8]*Gu2[8] + Gu1[10]*Gu2[10] + Gu1[12]*Gu2[12] + Gu1[14]*Gu2[14] + Gu1[16]*Gu2[16] + Gu1[18]*Gu2[18] + Gu1[20]*Gu2[20] + Gu1[22]*Gu2[22] + Gu1[24]*Gu2[24] + R11[0];
acadoWorkspace.H[iRow * 42 + 1] = + Gu1[0]*Gu2[1] + Gu1[2]*Gu2[3] + Gu1[4]*Gu2[5] + Gu1[6]*Gu2[7] + Gu1[8]*Gu2[9] + Gu1[10]*Gu2[11] + Gu1[12]*Gu2[13] + Gu1[14]*Gu2[15] + Gu1[16]*Gu2[17] + Gu1[18]*Gu2[19] + Gu1[20]*Gu2[21] + Gu1[22]*Gu2[23] + Gu1[24]*Gu2[25] + R11[1];
acadoWorkspace.H[iRow * 42 + 20] = + Gu1[1]*Gu2[0] + Gu1[3]*Gu2[2] + Gu1[5]*Gu2[4] + Gu1[7]*Gu2[6] + Gu1[9]*Gu2[8] + Gu1[11]*Gu2[10] + Gu1[13]*Gu2[12] + Gu1[15]*Gu2[14] + Gu1[17]*Gu2[16] + Gu1[19]*Gu2[18] + Gu1[21]*Gu2[20] + Gu1[23]*Gu2[22] + Gu1[25]*Gu2[24] + R11[2];
acadoWorkspace.H[iRow * 42 + 21] = + Gu1[1]*Gu2[1] + Gu1[3]*Gu2[3] + Gu1[5]*Gu2[5] + Gu1[7]*Gu2[7] + Gu1[9]*Gu2[9] + Gu1[11]*Gu2[11] + Gu1[13]*Gu2[13] + Gu1[15]*Gu2[15] + Gu1[17]*Gu2[17] + Gu1[19]*Gu2[19] + Gu1[21]*Gu2[21] + Gu1[23]*Gu2[23] + Gu1[25]*Gu2[25] + R11[3];
acadoWorkspace.H[iRow * 42] += 9.8999999999999999e-01;
acadoWorkspace.H[iRow * 42 + 21] += 9.8999999999999999e-01;
}

void acado_multGxTGu( real_t* const Gx1, real_t* const Gu1, real_t* const Gu2 )
{
Gu2[0] = + Gx1[0]*Gu1[0] + Gx1[13]*Gu1[2] + Gx1[26]*Gu1[4] + Gx1[39]*Gu1[6] + Gx1[52]*Gu1[8] + Gx1[65]*Gu1[10] + Gx1[78]*Gu1[12] + Gx1[91]*Gu1[14] + Gx1[104]*Gu1[16] + Gx1[117]*Gu1[18] + Gx1[130]*Gu1[20] + Gx1[143]*Gu1[22] + Gx1[156]*Gu1[24];
Gu2[1] = + Gx1[0]*Gu1[1] + Gx1[13]*Gu1[3] + Gx1[26]*Gu1[5] + Gx1[39]*Gu1[7] + Gx1[52]*Gu1[9] + Gx1[65]*Gu1[11] + Gx1[78]*Gu1[13] + Gx1[91]*Gu1[15] + Gx1[104]*Gu1[17] + Gx1[117]*Gu1[19] + Gx1[130]*Gu1[21] + Gx1[143]*Gu1[23] + Gx1[156]*Gu1[25];
Gu2[2] = + Gx1[1]*Gu1[0] + Gx1[14]*Gu1[2] + Gx1[27]*Gu1[4] + Gx1[40]*Gu1[6] + Gx1[53]*Gu1[8] + Gx1[66]*Gu1[10] + Gx1[79]*Gu1[12] + Gx1[92]*Gu1[14] + Gx1[105]*Gu1[16] + Gx1[118]*Gu1[18] + Gx1[131]*Gu1[20] + Gx1[144]*Gu1[22] + Gx1[157]*Gu1[24];
Gu2[3] = + Gx1[1]*Gu1[1] + Gx1[14]*Gu1[3] + Gx1[27]*Gu1[5] + Gx1[40]*Gu1[7] + Gx1[53]*Gu1[9] + Gx1[66]*Gu1[11] + Gx1[79]*Gu1[13] + Gx1[92]*Gu1[15] + Gx1[105]*Gu1[17] + Gx1[118]*Gu1[19] + Gx1[131]*Gu1[21] + Gx1[144]*Gu1[23] + Gx1[157]*Gu1[25];
Gu2[4] = + Gx1[2]*Gu1[0] + Gx1[15]*Gu1[2] + Gx1[28]*Gu1[4] + Gx1[41]*Gu1[6] + Gx1[54]*Gu1[8] + Gx1[67]*Gu1[10] + Gx1[80]*Gu1[12] + Gx1[93]*Gu1[14] + Gx1[106]*Gu1[16] + Gx1[119]*Gu1[18] + Gx1[132]*Gu1[20] + Gx1[145]*Gu1[22] + Gx1[158]*Gu1[24];
Gu2[5] = + Gx1[2]*Gu1[1] + Gx1[15]*Gu1[3] + Gx1[28]*Gu1[5] + Gx1[41]*Gu1[7] + Gx1[54]*Gu1[9] + Gx1[67]*Gu1[11] + Gx1[80]*Gu1[13] + Gx1[93]*Gu1[15] + Gx1[106]*Gu1[17] + Gx1[119]*Gu1[19] + Gx1[132]*Gu1[21] + Gx1[145]*Gu1[23] + Gx1[158]*Gu1[25];
Gu2[6] = + Gx1[3]*Gu1[0] + Gx1[16]*Gu1[2] + Gx1[29]*Gu1[4] + Gx1[42]*Gu1[6] + Gx1[55]*Gu1[8] + Gx1[68]*Gu1[10] + Gx1[81]*Gu1[12] + Gx1[94]*Gu1[14] + Gx1[107]*Gu1[16] + Gx1[120]*Gu1[18] + Gx1[133]*Gu1[20] + Gx1[146]*Gu1[22] + Gx1[159]*Gu1[24];
Gu2[7] = + Gx1[3]*Gu1[1] + Gx1[16]*Gu1[3] + Gx1[29]*Gu1[5] + Gx1[42]*Gu1[7] + Gx1[55]*Gu1[9] + Gx1[68]*Gu1[11] + Gx1[81]*Gu1[13] + Gx1[94]*Gu1[15] + Gx1[107]*Gu1[17] + Gx1[120]*Gu1[19] + Gx1[133]*Gu1[21] + Gx1[146]*Gu1[23] + Gx1[159]*Gu1[25];
Gu2[8] = + Gx1[4]*Gu1[0] + Gx1[17]*Gu1[2] + Gx1[30]*Gu1[4] + Gx1[43]*Gu1[6] + Gx1[56]*Gu1[8] + Gx1[69]*Gu1[10] + Gx1[82]*Gu1[12] + Gx1[95]*Gu1[14] + Gx1[108]*Gu1[16] + Gx1[121]*Gu1[18] + Gx1[134]*Gu1[20] + Gx1[147]*Gu1[22] + Gx1[160]*Gu1[24];
Gu2[9] = + Gx1[4]*Gu1[1] + Gx1[17]*Gu1[3] + Gx1[30]*Gu1[5] + Gx1[43]*Gu1[7] + Gx1[56]*Gu1[9] + Gx1[69]*Gu1[11] + Gx1[82]*Gu1[13] + Gx1[95]*Gu1[15] + Gx1[108]*Gu1[17] + Gx1[121]*Gu1[19] + Gx1[134]*Gu1[21] + Gx1[147]*Gu1[23] + Gx1[160]*Gu1[25];
Gu2[10] = + Gx1[5]*Gu1[0] + Gx1[18]*Gu1[2] + Gx1[31]*Gu1[4] + Gx1[44]*Gu1[6] + Gx1[57]*Gu1[8] + Gx1[70]*Gu1[10] + Gx1[83]*Gu1[12] + Gx1[96]*Gu1[14] + Gx1[109]*Gu1[16] + Gx1[122]*Gu1[18] + Gx1[135]*Gu1[20] + Gx1[148]*Gu1[22] + Gx1[161]*Gu1[24];
Gu2[11] = + Gx1[5]*Gu1[1] + Gx1[18]*Gu1[3] + Gx1[31]*Gu1[5] + Gx1[44]*Gu1[7] + Gx1[57]*Gu1[9] + Gx1[70]*Gu1[11] + Gx1[83]*Gu1[13] + Gx1[96]*Gu1[15] + Gx1[109]*Gu1[17] + Gx1[122]*Gu1[19] + Gx1[135]*Gu1[21] + Gx1[148]*Gu1[23] + Gx1[161]*Gu1[25];
Gu2[12] = + Gx1[6]*Gu1[0] + Gx1[19]*Gu1[2] + Gx1[32]*Gu1[4] + Gx1[45]*Gu1[6] + Gx1[58]*Gu1[8] + Gx1[71]*Gu1[10] + Gx1[84]*Gu1[12] + Gx1[97]*Gu1[14] + Gx1[110]*Gu1[16] + Gx1[123]*Gu1[18] + Gx1[136]*Gu1[20] + Gx1[149]*Gu1[22] + Gx1[162]*Gu1[24];
Gu2[13] = + Gx1[6]*Gu1[1] + Gx1[19]*Gu1[3] + Gx1[32]*Gu1[5] + Gx1[45]*Gu1[7] + Gx1[58]*Gu1[9] + Gx1[71]*Gu1[11] + Gx1[84]*Gu1[13] + Gx1[97]*Gu1[15] + Gx1[110]*Gu1[17] + Gx1[123]*Gu1[19] + Gx1[136]*Gu1[21] + Gx1[149]*Gu1[23] + Gx1[162]*Gu1[25];
Gu2[14] = + Gx1[7]*Gu1[0] + Gx1[20]*Gu1[2] + Gx1[33]*Gu1[4] + Gx1[46]*Gu1[6] + Gx1[59]*Gu1[8] + Gx1[72]*Gu1[10] + Gx1[85]*Gu1[12] + Gx1[98]*Gu1[14] + Gx1[111]*Gu1[16] + Gx1[124]*Gu1[18] + Gx1[137]*Gu1[20] + Gx1[150]*Gu1[22] + Gx1[163]*Gu1[24];
Gu2[15] = + Gx1[7]*Gu1[1] + Gx1[20]*Gu1[3] + Gx1[33]*Gu1[5] + Gx1[46]*Gu1[7] + Gx1[59]*Gu1[9] + Gx1[72]*Gu1[11] + Gx1[85]*Gu1[13] + Gx1[98]*Gu1[15] + Gx1[111]*Gu1[17] + Gx1[124]*Gu1[19] + Gx1[137]*Gu1[21] + Gx1[150]*Gu1[23] + Gx1[163]*Gu1[25];
Gu2[16] = + Gx1[8]*Gu1[0] + Gx1[21]*Gu1[2] + Gx1[34]*Gu1[4] + Gx1[47]*Gu1[6] + Gx1[60]*Gu1[8] + Gx1[73]*Gu1[10] + Gx1[86]*Gu1[12] + Gx1[99]*Gu1[14] + Gx1[112]*Gu1[16] + Gx1[125]*Gu1[18] + Gx1[138]*Gu1[20] + Gx1[151]*Gu1[22] + Gx1[164]*Gu1[24];
Gu2[17] = + Gx1[8]*Gu1[1] + Gx1[21]*Gu1[3] + Gx1[34]*Gu1[5] + Gx1[47]*Gu1[7] + Gx1[60]*Gu1[9] + Gx1[73]*Gu1[11] + Gx1[86]*Gu1[13] + Gx1[99]*Gu1[15] + Gx1[112]*Gu1[17] + Gx1[125]*Gu1[19] + Gx1[138]*Gu1[21] + Gx1[151]*Gu1[23] + Gx1[164]*Gu1[25];
Gu2[18] = + Gx1[9]*Gu1[0] + Gx1[22]*Gu1[2] + Gx1[35]*Gu1[4] + Gx1[48]*Gu1[6] + Gx1[61]*Gu1[8] + Gx1[74]*Gu1[10] + Gx1[87]*Gu1[12] + Gx1[100]*Gu1[14] + Gx1[113]*Gu1[16] + Gx1[126]*Gu1[18] + Gx1[139]*Gu1[20] + Gx1[152]*Gu1[22] + Gx1[165]*Gu1[24];
Gu2[19] = + Gx1[9]*Gu1[1] + Gx1[22]*Gu1[3] + Gx1[35]*Gu1[5] + Gx1[48]*Gu1[7] + Gx1[61]*Gu1[9] + Gx1[74]*Gu1[11] + Gx1[87]*Gu1[13] + Gx1[100]*Gu1[15] + Gx1[113]*Gu1[17] + Gx1[126]*Gu1[19] + Gx1[139]*Gu1[21] + Gx1[152]*Gu1[23] + Gx1[165]*Gu1[25];
Gu2[20] = + Gx1[10]*Gu1[0] + Gx1[23]*Gu1[2] + Gx1[36]*Gu1[4] + Gx1[49]*Gu1[6] + Gx1[62]*Gu1[8] + Gx1[75]*Gu1[10] + Gx1[88]*Gu1[12] + Gx1[101]*Gu1[14] + Gx1[114]*Gu1[16] + Gx1[127]*Gu1[18] + Gx1[140]*Gu1[20] + Gx1[153]*Gu1[22] + Gx1[166]*Gu1[24];
Gu2[21] = + Gx1[10]*Gu1[1] + Gx1[23]*Gu1[3] + Gx1[36]*Gu1[5] + Gx1[49]*Gu1[7] + Gx1[62]*Gu1[9] + Gx1[75]*Gu1[11] + Gx1[88]*Gu1[13] + Gx1[101]*Gu1[15] + Gx1[114]*Gu1[17] + Gx1[127]*Gu1[19] + Gx1[140]*Gu1[21] + Gx1[153]*Gu1[23] + Gx1[166]*Gu1[25];
Gu2[22] = + Gx1[11]*Gu1[0] + Gx1[24]*Gu1[2] + Gx1[37]*Gu1[4] + Gx1[50]*Gu1[6] + Gx1[63]*Gu1[8] + Gx1[76]*Gu1[10] + Gx1[89]*Gu1[12] + Gx1[102]*Gu1[14] + Gx1[115]*Gu1[16] + Gx1[128]*Gu1[18] + Gx1[141]*Gu1[20] + Gx1[154]*Gu1[22] + Gx1[167]*Gu1[24];
Gu2[23] = + Gx1[11]*Gu1[1] + Gx1[24]*Gu1[3] + Gx1[37]*Gu1[5] + Gx1[50]*Gu1[7] + Gx1[63]*Gu1[9] + Gx1[76]*Gu1[11] + Gx1[89]*Gu1[13] + Gx1[102]*Gu1[15] + Gx1[115]*Gu1[17] + Gx1[128]*Gu1[19] + Gx1[141]*Gu1[21] + Gx1[154]*Gu1[23] + Gx1[167]*Gu1[25];
Gu2[24] = + Gx1[12]*Gu1[0] + Gx1[25]*Gu1[2] + Gx1[38]*Gu1[4] + Gx1[51]*Gu1[6] + Gx1[64]*Gu1[8] + Gx1[77]*Gu1[10] + Gx1[90]*Gu1[12] + Gx1[103]*Gu1[14] + Gx1[116]*Gu1[16] + Gx1[129]*Gu1[18] + Gx1[142]*Gu1[20] + Gx1[155]*Gu1[22] + Gx1[168]*Gu1[24];
Gu2[25] = + Gx1[12]*Gu1[1] + Gx1[25]*Gu1[3] + Gx1[38]*Gu1[5] + Gx1[51]*Gu1[7] + Gx1[64]*Gu1[9] + Gx1[77]*Gu1[11] + Gx1[90]*Gu1[13] + Gx1[103]*Gu1[15] + Gx1[116]*Gu1[17] + Gx1[129]*Gu1[19] + Gx1[142]*Gu1[21] + Gx1[155]*Gu1[23] + Gx1[168]*Gu1[25];
}

void acado_multQEW2( real_t* const Q11, real_t* const Gu1, real_t* const Gu2, real_t* const Gu3 )
{
Gu3[0] = + Q11[0]*Gu1[0] + Q11[1]*Gu1[2] + Q11[2]*Gu1[4] + Q11[3]*Gu1[6] + Q11[4]*Gu1[8] + Q11[5]*Gu1[10] + Q11[6]*Gu1[12] + Q11[7]*Gu1[14] + Q11[8]*Gu1[16] + Q11[9]*Gu1[18] + Q11[10]*Gu1[20] + Q11[11]*Gu1[22] + Q11[12]*Gu1[24] + Gu2[0];
Gu3[1] = + Q11[0]*Gu1[1] + Q11[1]*Gu1[3] + Q11[2]*Gu1[5] + Q11[3]*Gu1[7] + Q11[4]*Gu1[9] + Q11[5]*Gu1[11] + Q11[6]*Gu1[13] + Q11[7]*Gu1[15] + Q11[8]*Gu1[17] + Q11[9]*Gu1[19] + Q11[10]*Gu1[21] + Q11[11]*Gu1[23] + Q11[12]*Gu1[25] + Gu2[1];
Gu3[2] = + Q11[13]*Gu1[0] + Q11[14]*Gu1[2] + Q11[15]*Gu1[4] + Q11[16]*Gu1[6] + Q11[17]*Gu1[8] + Q11[18]*Gu1[10] + Q11[19]*Gu1[12] + Q11[20]*Gu1[14] + Q11[21]*Gu1[16] + Q11[22]*Gu1[18] + Q11[23]*Gu1[20] + Q11[24]*Gu1[22] + Q11[25]*Gu1[24] + Gu2[2];
Gu3[3] = + Q11[13]*Gu1[1] + Q11[14]*Gu1[3] + Q11[15]*Gu1[5] + Q11[16]*Gu1[7] + Q11[17]*Gu1[9] + Q11[18]*Gu1[11] + Q11[19]*Gu1[13] + Q11[20]*Gu1[15] + Q11[21]*Gu1[17] + Q11[22]*Gu1[19] + Q11[23]*Gu1[21] + Q11[24]*Gu1[23] + Q11[25]*Gu1[25] + Gu2[3];
Gu3[4] = + Q11[26]*Gu1[0] + Q11[27]*Gu1[2] + Q11[28]*Gu1[4] + Q11[29]*Gu1[6] + Q11[30]*Gu1[8] + Q11[31]*Gu1[10] + Q11[32]*Gu1[12] + Q11[33]*Gu1[14] + Q11[34]*Gu1[16] + Q11[35]*Gu1[18] + Q11[36]*Gu1[20] + Q11[37]*Gu1[22] + Q11[38]*Gu1[24] + Gu2[4];
Gu3[5] = + Q11[26]*Gu1[1] + Q11[27]*Gu1[3] + Q11[28]*Gu1[5] + Q11[29]*Gu1[7] + Q11[30]*Gu1[9] + Q11[31]*Gu1[11] + Q11[32]*Gu1[13] + Q11[33]*Gu1[15] + Q11[34]*Gu1[17] + Q11[35]*Gu1[19] + Q11[36]*Gu1[21] + Q11[37]*Gu1[23] + Q11[38]*Gu1[25] + Gu2[5];
Gu3[6] = + Q11[39]*Gu1[0] + Q11[40]*Gu1[2] + Q11[41]*Gu1[4] + Q11[42]*Gu1[6] + Q11[43]*Gu1[8] + Q11[44]*Gu1[10] + Q11[45]*Gu1[12] + Q11[46]*Gu1[14] + Q11[47]*Gu1[16] + Q11[48]*Gu1[18] + Q11[49]*Gu1[20] + Q11[50]*Gu1[22] + Q11[51]*Gu1[24] + Gu2[6];
Gu3[7] = + Q11[39]*Gu1[1] + Q11[40]*Gu1[3] + Q11[41]*Gu1[5] + Q11[42]*Gu1[7] + Q11[43]*Gu1[9] + Q11[44]*Gu1[11] + Q11[45]*Gu1[13] + Q11[46]*Gu1[15] + Q11[47]*Gu1[17] + Q11[48]*Gu1[19] + Q11[49]*Gu1[21] + Q11[50]*Gu1[23] + Q11[51]*Gu1[25] + Gu2[7];
Gu3[8] = + Q11[52]*Gu1[0] + Q11[53]*Gu1[2] + Q11[54]*Gu1[4] + Q11[55]*Gu1[6] + Q11[56]*Gu1[8] + Q11[57]*Gu1[10] + Q11[58]*Gu1[12] + Q11[59]*Gu1[14] + Q11[60]*Gu1[16] + Q11[61]*Gu1[18] + Q11[62]*Gu1[20] + Q11[63]*Gu1[22] + Q11[64]*Gu1[24] + Gu2[8];
Gu3[9] = + Q11[52]*Gu1[1] + Q11[53]*Gu1[3] + Q11[54]*Gu1[5] + Q11[55]*Gu1[7] + Q11[56]*Gu1[9] + Q11[57]*Gu1[11] + Q11[58]*Gu1[13] + Q11[59]*Gu1[15] + Q11[60]*Gu1[17] + Q11[61]*Gu1[19] + Q11[62]*Gu1[21] + Q11[63]*Gu1[23] + Q11[64]*Gu1[25] + Gu2[9];
Gu3[10] = + Q11[65]*Gu1[0] + Q11[66]*Gu1[2] + Q11[67]*Gu1[4] + Q11[68]*Gu1[6] + Q11[69]*Gu1[8] + Q11[70]*Gu1[10] + Q11[71]*Gu1[12] + Q11[72]*Gu1[14] + Q11[73]*Gu1[16] + Q11[74]*Gu1[18] + Q11[75]*Gu1[20] + Q11[76]*Gu1[22] + Q11[77]*Gu1[24] + Gu2[10];
Gu3[11] = + Q11[65]*Gu1[1] + Q11[66]*Gu1[3] + Q11[67]*Gu1[5] + Q11[68]*Gu1[7] + Q11[69]*Gu1[9] + Q11[70]*Gu1[11] + Q11[71]*Gu1[13] + Q11[72]*Gu1[15] + Q11[73]*Gu1[17] + Q11[74]*Gu1[19] + Q11[75]*Gu1[21] + Q11[76]*Gu1[23] + Q11[77]*Gu1[25] + Gu2[11];
Gu3[12] = + Q11[78]*Gu1[0] + Q11[79]*Gu1[2] + Q11[80]*Gu1[4] + Q11[81]*Gu1[6] + Q11[82]*Gu1[8] + Q11[83]*Gu1[10] + Q11[84]*Gu1[12] + Q11[85]*Gu1[14] + Q11[86]*Gu1[16] + Q11[87]*Gu1[18] + Q11[88]*Gu1[20] + Q11[89]*Gu1[22] + Q11[90]*Gu1[24] + Gu2[12];
Gu3[13] = + Q11[78]*Gu1[1] + Q11[79]*Gu1[3] + Q11[80]*Gu1[5] + Q11[81]*Gu1[7] + Q11[82]*Gu1[9] + Q11[83]*Gu1[11] + Q11[84]*Gu1[13] + Q11[85]*Gu1[15] + Q11[86]*Gu1[17] + Q11[87]*Gu1[19] + Q11[88]*Gu1[21] + Q11[89]*Gu1[23] + Q11[90]*Gu1[25] + Gu2[13];
Gu3[14] = + Q11[91]*Gu1[0] + Q11[92]*Gu1[2] + Q11[93]*Gu1[4] + Q11[94]*Gu1[6] + Q11[95]*Gu1[8] + Q11[96]*Gu1[10] + Q11[97]*Gu1[12] + Q11[98]*Gu1[14] + Q11[99]*Gu1[16] + Q11[100]*Gu1[18] + Q11[101]*Gu1[20] + Q11[102]*Gu1[22] + Q11[103]*Gu1[24] + Gu2[14];
Gu3[15] = + Q11[91]*Gu1[1] + Q11[92]*Gu1[3] + Q11[93]*Gu1[5] + Q11[94]*Gu1[7] + Q11[95]*Gu1[9] + Q11[96]*Gu1[11] + Q11[97]*Gu1[13] + Q11[98]*Gu1[15] + Q11[99]*Gu1[17] + Q11[100]*Gu1[19] + Q11[101]*Gu1[21] + Q11[102]*Gu1[23] + Q11[103]*Gu1[25] + Gu2[15];
Gu3[16] = + Q11[104]*Gu1[0] + Q11[105]*Gu1[2] + Q11[106]*Gu1[4] + Q11[107]*Gu1[6] + Q11[108]*Gu1[8] + Q11[109]*Gu1[10] + Q11[110]*Gu1[12] + Q11[111]*Gu1[14] + Q11[112]*Gu1[16] + Q11[113]*Gu1[18] + Q11[114]*Gu1[20] + Q11[115]*Gu1[22] + Q11[116]*Gu1[24] + Gu2[16];
Gu3[17] = + Q11[104]*Gu1[1] + Q11[105]*Gu1[3] + Q11[106]*Gu1[5] + Q11[107]*Gu1[7] + Q11[108]*Gu1[9] + Q11[109]*Gu1[11] + Q11[110]*Gu1[13] + Q11[111]*Gu1[15] + Q11[112]*Gu1[17] + Q11[113]*Gu1[19] + Q11[114]*Gu1[21] + Q11[115]*Gu1[23] + Q11[116]*Gu1[25] + Gu2[17];
Gu3[18] = + Q11[117]*Gu1[0] + Q11[118]*Gu1[2] + Q11[119]*Gu1[4] + Q11[120]*Gu1[6] + Q11[121]*Gu1[8] + Q11[122]*Gu1[10] + Q11[123]*Gu1[12] + Q11[124]*Gu1[14] + Q11[125]*Gu1[16] + Q11[126]*Gu1[18] + Q11[127]*Gu1[20] + Q11[128]*Gu1[22] + Q11[129]*Gu1[24] + Gu2[18];
Gu3[19] = + Q11[117]*Gu1[1] + Q11[118]*Gu1[3] + Q11[119]*Gu1[5] + Q11[120]*Gu1[7] + Q11[121]*Gu1[9] + Q11[122]*Gu1[11] + Q11[123]*Gu1[13] + Q11[124]*Gu1[15] + Q11[125]*Gu1[17] + Q11[126]*Gu1[19] + Q11[127]*Gu1[21] + Q11[128]*Gu1[23] + Q11[129]*Gu1[25] + Gu2[19];
Gu3[20] = + Q11[130]*Gu1[0] + Q11[131]*Gu1[2] + Q11[132]*Gu1[4] + Q11[133]*Gu1[6] + Q11[134]*Gu1[8] + Q11[135]*Gu1[10] + Q11[136]*Gu1[12] + Q11[137]*Gu1[14] + Q11[138]*Gu1[16] + Q11[139]*Gu1[18] + Q11[140]*Gu1[20] + Q11[141]*Gu1[22] + Q11[142]*Gu1[24] + Gu2[20];
Gu3[21] = + Q11[130]*Gu1[1] + Q11[131]*Gu1[3] + Q11[132]*Gu1[5] + Q11[133]*Gu1[7] + Q11[134]*Gu1[9] + Q11[135]*Gu1[11] + Q11[136]*Gu1[13] + Q11[137]*Gu1[15] + Q11[138]*Gu1[17] + Q11[139]*Gu1[19] + Q11[140]*Gu1[21] + Q11[141]*Gu1[23] + Q11[142]*Gu1[25] + Gu2[21];
Gu3[22] = + Q11[143]*Gu1[0] + Q11[144]*Gu1[2] + Q11[145]*Gu1[4] + Q11[146]*Gu1[6] + Q11[147]*Gu1[8] + Q11[148]*Gu1[10] + Q11[149]*Gu1[12] + Q11[150]*Gu1[14] + Q11[151]*Gu1[16] + Q11[152]*Gu1[18] + Q11[153]*Gu1[20] + Q11[154]*Gu1[22] + Q11[155]*Gu1[24] + Gu2[22];
Gu3[23] = + Q11[143]*Gu1[1] + Q11[144]*Gu1[3] + Q11[145]*Gu1[5] + Q11[146]*Gu1[7] + Q11[147]*Gu1[9] + Q11[148]*Gu1[11] + Q11[149]*Gu1[13] + Q11[150]*Gu1[15] + Q11[151]*Gu1[17] + Q11[152]*Gu1[19] + Q11[153]*Gu1[21] + Q11[154]*Gu1[23] + Q11[155]*Gu1[25] + Gu2[23];
Gu3[24] = + Q11[156]*Gu1[0] + Q11[157]*Gu1[2] + Q11[158]*Gu1[4] + Q11[159]*Gu1[6] + Q11[160]*Gu1[8] + Q11[161]*Gu1[10] + Q11[162]*Gu1[12] + Q11[163]*Gu1[14] + Q11[164]*Gu1[16] + Q11[165]*Gu1[18] + Q11[166]*Gu1[20] + Q11[167]*Gu1[22] + Q11[168]*Gu1[24] + Gu2[24];
Gu3[25] = + Q11[156]*Gu1[1] + Q11[157]*Gu1[3] + Q11[158]*Gu1[5] + Q11[159]*Gu1[7] + Q11[160]*Gu1[9] + Q11[161]*Gu1[11] + Q11[162]*Gu1[13] + Q11[163]*Gu1[15] + Q11[164]*Gu1[17] + Q11[165]*Gu1[19] + Q11[166]*Gu1[21] + Q11[167]*Gu1[23] + Q11[168]*Gu1[25] + Gu2[25];
}

void acado_macATw1QDy( real_t* const Gx1, real_t* const w11, real_t* const w12, real_t* const w13 )
{
w13[0] = + Gx1[0]*w11[0] + Gx1[13]*w11[1] + Gx1[26]*w11[2] + Gx1[39]*w11[3] + Gx1[52]*w11[4] + Gx1[65]*w11[5] + Gx1[78]*w11[6] + Gx1[91]*w11[7] + Gx1[104]*w11[8] + Gx1[117]*w11[9] + Gx1[130]*w11[10] + Gx1[143]*w11[11] + Gx1[156]*w11[12] + w12[0];
w13[1] = + Gx1[1]*w11[0] + Gx1[14]*w11[1] + Gx1[27]*w11[2] + Gx1[40]*w11[3] + Gx1[53]*w11[4] + Gx1[66]*w11[5] + Gx1[79]*w11[6] + Gx1[92]*w11[7] + Gx1[105]*w11[8] + Gx1[118]*w11[9] + Gx1[131]*w11[10] + Gx1[144]*w11[11] + Gx1[157]*w11[12] + w12[1];
w13[2] = + Gx1[2]*w11[0] + Gx1[15]*w11[1] + Gx1[28]*w11[2] + Gx1[41]*w11[3] + Gx1[54]*w11[4] + Gx1[67]*w11[5] + Gx1[80]*w11[6] + Gx1[93]*w11[7] + Gx1[106]*w11[8] + Gx1[119]*w11[9] + Gx1[132]*w11[10] + Gx1[145]*w11[11] + Gx1[158]*w11[12] + w12[2];
w13[3] = + Gx1[3]*w11[0] + Gx1[16]*w11[1] + Gx1[29]*w11[2] + Gx1[42]*w11[3] + Gx1[55]*w11[4] + Gx1[68]*w11[5] + Gx1[81]*w11[6] + Gx1[94]*w11[7] + Gx1[107]*w11[8] + Gx1[120]*w11[9] + Gx1[133]*w11[10] + Gx1[146]*w11[11] + Gx1[159]*w11[12] + w12[3];
w13[4] = + Gx1[4]*w11[0] + Gx1[17]*w11[1] + Gx1[30]*w11[2] + Gx1[43]*w11[3] + Gx1[56]*w11[4] + Gx1[69]*w11[5] + Gx1[82]*w11[6] + Gx1[95]*w11[7] + Gx1[108]*w11[8] + Gx1[121]*w11[9] + Gx1[134]*w11[10] + Gx1[147]*w11[11] + Gx1[160]*w11[12] + w12[4];
w13[5] = + Gx1[5]*w11[0] + Gx1[18]*w11[1] + Gx1[31]*w11[2] + Gx1[44]*w11[3] + Gx1[57]*w11[4] + Gx1[70]*w11[5] + Gx1[83]*w11[6] + Gx1[96]*w11[7] + Gx1[109]*w11[8] + Gx1[122]*w11[9] + Gx1[135]*w11[10] + Gx1[148]*w11[11] + Gx1[161]*w11[12] + w12[5];
w13[6] = + Gx1[6]*w11[0] + Gx1[19]*w11[1] + Gx1[32]*w11[2] + Gx1[45]*w11[3] + Gx1[58]*w11[4] + Gx1[71]*w11[5] + Gx1[84]*w11[6] + Gx1[97]*w11[7] + Gx1[110]*w11[8] + Gx1[123]*w11[9] + Gx1[136]*w11[10] + Gx1[149]*w11[11] + Gx1[162]*w11[12] + w12[6];
w13[7] = + Gx1[7]*w11[0] + Gx1[20]*w11[1] + Gx1[33]*w11[2] + Gx1[46]*w11[3] + Gx1[59]*w11[4] + Gx1[72]*w11[5] + Gx1[85]*w11[6] + Gx1[98]*w11[7] + Gx1[111]*w11[8] + Gx1[124]*w11[9] + Gx1[137]*w11[10] + Gx1[150]*w11[11] + Gx1[163]*w11[12] + w12[7];
w13[8] = + Gx1[8]*w11[0] + Gx1[21]*w11[1] + Gx1[34]*w11[2] + Gx1[47]*w11[3] + Gx1[60]*w11[4] + Gx1[73]*w11[5] + Gx1[86]*w11[6] + Gx1[99]*w11[7] + Gx1[112]*w11[8] + Gx1[125]*w11[9] + Gx1[138]*w11[10] + Gx1[151]*w11[11] + Gx1[164]*w11[12] + w12[8];
w13[9] = + Gx1[9]*w11[0] + Gx1[22]*w11[1] + Gx1[35]*w11[2] + Gx1[48]*w11[3] + Gx1[61]*w11[4] + Gx1[74]*w11[5] + Gx1[87]*w11[6] + Gx1[100]*w11[7] + Gx1[113]*w11[8] + Gx1[126]*w11[9] + Gx1[139]*w11[10] + Gx1[152]*w11[11] + Gx1[165]*w11[12] + w12[9];
w13[10] = + Gx1[10]*w11[0] + Gx1[23]*w11[1] + Gx1[36]*w11[2] + Gx1[49]*w11[3] + Gx1[62]*w11[4] + Gx1[75]*w11[5] + Gx1[88]*w11[6] + Gx1[101]*w11[7] + Gx1[114]*w11[8] + Gx1[127]*w11[9] + Gx1[140]*w11[10] + Gx1[153]*w11[11] + Gx1[166]*w11[12] + w12[10];
w13[11] = + Gx1[11]*w11[0] + Gx1[24]*w11[1] + Gx1[37]*w11[2] + Gx1[50]*w11[3] + Gx1[63]*w11[4] + Gx1[76]*w11[5] + Gx1[89]*w11[6] + Gx1[102]*w11[7] + Gx1[115]*w11[8] + Gx1[128]*w11[9] + Gx1[141]*w11[10] + Gx1[154]*w11[11] + Gx1[167]*w11[12] + w12[11];
w13[12] = + Gx1[12]*w11[0] + Gx1[25]*w11[1] + Gx1[38]*w11[2] + Gx1[51]*w11[3] + Gx1[64]*w11[4] + Gx1[77]*w11[5] + Gx1[90]*w11[6] + Gx1[103]*w11[7] + Gx1[116]*w11[8] + Gx1[129]*w11[9] + Gx1[142]*w11[10] + Gx1[155]*w11[11] + Gx1[168]*w11[12] + w12[12];
}

void acado_macBTw1( real_t* const Gu1, real_t* const w11, real_t* const U1 )
{
U1[0] += + Gu1[0]*w11[0] + Gu1[2]*w11[1] + Gu1[4]*w11[2] + Gu1[6]*w11[3] + Gu1[8]*w11[4] + Gu1[10]*w11[5] + Gu1[12]*w11[6] + Gu1[14]*w11[7] + Gu1[16]*w11[8] + Gu1[18]*w11[9] + Gu1[20]*w11[10] + Gu1[22]*w11[11] + Gu1[24]*w11[12];
U1[1] += + Gu1[1]*w11[0] + Gu1[3]*w11[1] + Gu1[5]*w11[2] + Gu1[7]*w11[3] + Gu1[9]*w11[4] + Gu1[11]*w11[5] + Gu1[13]*w11[6] + Gu1[15]*w11[7] + Gu1[17]*w11[8] + Gu1[19]*w11[9] + Gu1[21]*w11[10] + Gu1[23]*w11[11] + Gu1[25]*w11[12];
}

void acado_macQSbarW2( real_t* const Q11, real_t* const w11, real_t* const w12, real_t* const w13 )
{
w13[0] = + Q11[0]*w11[0] + Q11[1]*w11[1] + Q11[2]*w11[2] + Q11[3]*w11[3] + Q11[4]*w11[4] + Q11[5]*w11[5] + Q11[6]*w11[6] + Q11[7]*w11[7] + Q11[8]*w11[8] + Q11[9]*w11[9] + Q11[10]*w11[10] + Q11[11]*w11[11] + Q11[12]*w11[12] + w12[0];
w13[1] = + Q11[13]*w11[0] + Q11[14]*w11[1] + Q11[15]*w11[2] + Q11[16]*w11[3] + Q11[17]*w11[4] + Q11[18]*w11[5] + Q11[19]*w11[6] + Q11[20]*w11[7] + Q11[21]*w11[8] + Q11[22]*w11[9] + Q11[23]*w11[10] + Q11[24]*w11[11] + Q11[25]*w11[12] + w12[1];
w13[2] = + Q11[26]*w11[0] + Q11[27]*w11[1] + Q11[28]*w11[2] + Q11[29]*w11[3] + Q11[30]*w11[4] + Q11[31]*w11[5] + Q11[32]*w11[6] + Q11[33]*w11[7] + Q11[34]*w11[8] + Q11[35]*w11[9] + Q11[36]*w11[10] + Q11[37]*w11[11] + Q11[38]*w11[12] + w12[2];
w13[3] = + Q11[39]*w11[0] + Q11[40]*w11[1] + Q11[41]*w11[2] + Q11[42]*w11[3] + Q11[43]*w11[4] + Q11[44]*w11[5] + Q11[45]*w11[6] + Q11[46]*w11[7] + Q11[47]*w11[8] + Q11[48]*w11[9] + Q11[49]*w11[10] + Q11[50]*w11[11] + Q11[51]*w11[12] + w12[3];
w13[4] = + Q11[52]*w11[0] + Q11[53]*w11[1] + Q11[54]*w11[2] + Q11[55]*w11[3] + Q11[56]*w11[4] + Q11[57]*w11[5] + Q11[58]*w11[6] + Q11[59]*w11[7] + Q11[60]*w11[8] + Q11[61]*w11[9] + Q11[62]*w11[10] + Q11[63]*w11[11] + Q11[64]*w11[12] + w12[4];
w13[5] = + Q11[65]*w11[0] + Q11[66]*w11[1] + Q11[67]*w11[2] + Q11[68]*w11[3] + Q11[69]*w11[4] + Q11[70]*w11[5] + Q11[71]*w11[6] + Q11[72]*w11[7] + Q11[73]*w11[8] + Q11[74]*w11[9] + Q11[75]*w11[10] + Q11[76]*w11[11] + Q11[77]*w11[12] + w12[5];
w13[6] = + Q11[78]*w11[0] + Q11[79]*w11[1] + Q11[80]*w11[2] + Q11[81]*w11[3] + Q11[82]*w11[4] + Q11[83]*w11[5] + Q11[84]*w11[6] + Q11[85]*w11[7] + Q11[86]*w11[8] + Q11[87]*w11[9] + Q11[88]*w11[10] + Q11[89]*w11[11] + Q11[90]*w11[12] + w12[6];
w13[7] = + Q11[91]*w11[0] + Q11[92]*w11[1] + Q11[93]*w11[2] + Q11[94]*w11[3] + Q11[95]*w11[4] + Q11[96]*w11[5] + Q11[97]*w11[6] + Q11[98]*w11[7] + Q11[99]*w11[8] + Q11[100]*w11[9] + Q11[101]*w11[10] + Q11[102]*w11[11] + Q11[103]*w11[12] + w12[7];
w13[8] = + Q11[104]*w11[0] + Q11[105]*w11[1] + Q11[106]*w11[2] + Q11[107]*w11[3] + Q11[108]*w11[4] + Q11[109]*w11[5] + Q11[110]*w11[6] + Q11[111]*w11[7] + Q11[112]*w11[8] + Q11[113]*w11[9] + Q11[114]*w11[10] + Q11[115]*w11[11] + Q11[116]*w11[12] + w12[8];
w13[9] = + Q11[117]*w11[0] + Q11[118]*w11[1] + Q11[119]*w11[2] + Q11[120]*w11[3] + Q11[121]*w11[4] + Q11[122]*w11[5] + Q11[123]*w11[6] + Q11[124]*w11[7] + Q11[125]*w11[8] + Q11[126]*w11[9] + Q11[127]*w11[10] + Q11[128]*w11[11] + Q11[129]*w11[12] + w12[9];
w13[10] = + Q11[130]*w11[0] + Q11[131]*w11[1] + Q11[132]*w11[2] + Q11[133]*w11[3] + Q11[134]*w11[4] + Q11[135]*w11[5] + Q11[136]*w11[6] + Q11[137]*w11[7] + Q11[138]*w11[8] + Q11[139]*w11[9] + Q11[140]*w11[10] + Q11[141]*w11[11] + Q11[142]*w11[12] + w12[10];
w13[11] = + Q11[143]*w11[0] + Q11[144]*w11[1] + Q11[145]*w11[2] + Q11[146]*w11[3] + Q11[147]*w11[4] + Q11[148]*w11[5] + Q11[149]*w11[6] + Q11[150]*w11[7] + Q11[151]*w11[8] + Q11[152]*w11[9] + Q11[153]*w11[10] + Q11[154]*w11[11] + Q11[155]*w11[12] + w12[11];
w13[12] = + Q11[156]*w11[0] + Q11[157]*w11[1] + Q11[158]*w11[2] + Q11[159]*w11[3] + Q11[160]*w11[4] + Q11[161]*w11[5] + Q11[162]*w11[6] + Q11[163]*w11[7] + Q11[164]*w11[8] + Q11[165]*w11[9] + Q11[166]*w11[10] + Q11[167]*w11[11] + Q11[168]*w11[12] + w12[12];
}

void acado_macASbar( real_t* const Gx1, real_t* const w11, real_t* const w12 )
{
w12[0] += + Gx1[0]*w11[0] + Gx1[1]*w11[1] + Gx1[2]*w11[2] + Gx1[3]*w11[3] + Gx1[4]*w11[4] + Gx1[5]*w11[5] + Gx1[6]*w11[6] + Gx1[7]*w11[7] + Gx1[8]*w11[8] + Gx1[9]*w11[9] + Gx1[10]*w11[10] + Gx1[11]*w11[11] + Gx1[12]*w11[12];
w12[1] += + Gx1[13]*w11[0] + Gx1[14]*w11[1] + Gx1[15]*w11[2] + Gx1[16]*w11[3] + Gx1[17]*w11[4] + Gx1[18]*w11[5] + Gx1[19]*w11[6] + Gx1[20]*w11[7] + Gx1[21]*w11[8] + Gx1[22]*w11[9] + Gx1[23]*w11[10] + Gx1[24]*w11[11] + Gx1[25]*w11[12];
w12[2] += + Gx1[26]*w11[0] + Gx1[27]*w11[1] + Gx1[28]*w11[2] + Gx1[29]*w11[3] + Gx1[30]*w11[4] + Gx1[31]*w11[5] + Gx1[32]*w11[6] + Gx1[33]*w11[7] + Gx1[34]*w11[8] + Gx1[35]*w11[9] + Gx1[36]*w11[10] + Gx1[37]*w11[11] + Gx1[38]*w11[12];
w12[3] += + Gx1[39]*w11[0] + Gx1[40]*w11[1] + Gx1[41]*w11[2] + Gx1[42]*w11[3] + Gx1[43]*w11[4] + Gx1[44]*w11[5] + Gx1[45]*w11[6] + Gx1[46]*w11[7] + Gx1[47]*w11[8] + Gx1[48]*w11[9] + Gx1[49]*w11[10] + Gx1[50]*w11[11] + Gx1[51]*w11[12];
w12[4] += + Gx1[52]*w11[0] + Gx1[53]*w11[1] + Gx1[54]*w11[2] + Gx1[55]*w11[3] + Gx1[56]*w11[4] + Gx1[57]*w11[5] + Gx1[58]*w11[6] + Gx1[59]*w11[7] + Gx1[60]*w11[8] + Gx1[61]*w11[9] + Gx1[62]*w11[10] + Gx1[63]*w11[11] + Gx1[64]*w11[12];
w12[5] += + Gx1[65]*w11[0] + Gx1[66]*w11[1] + Gx1[67]*w11[2] + Gx1[68]*w11[3] + Gx1[69]*w11[4] + Gx1[70]*w11[5] + Gx1[71]*w11[6] + Gx1[72]*w11[7] + Gx1[73]*w11[8] + Gx1[74]*w11[9] + Gx1[75]*w11[10] + Gx1[76]*w11[11] + Gx1[77]*w11[12];
w12[6] += + Gx1[78]*w11[0] + Gx1[79]*w11[1] + Gx1[80]*w11[2] + Gx1[81]*w11[3] + Gx1[82]*w11[4] + Gx1[83]*w11[5] + Gx1[84]*w11[6] + Gx1[85]*w11[7] + Gx1[86]*w11[8] + Gx1[87]*w11[9] + Gx1[88]*w11[10] + Gx1[89]*w11[11] + Gx1[90]*w11[12];
w12[7] += + Gx1[91]*w11[0] + Gx1[92]*w11[1] + Gx1[93]*w11[2] + Gx1[94]*w11[3] + Gx1[95]*w11[4] + Gx1[96]*w11[5] + Gx1[97]*w11[6] + Gx1[98]*w11[7] + Gx1[99]*w11[8] + Gx1[100]*w11[9] + Gx1[101]*w11[10] + Gx1[102]*w11[11] + Gx1[103]*w11[12];
w12[8] += + Gx1[104]*w11[0] + Gx1[105]*w11[1] + Gx1[106]*w11[2] + Gx1[107]*w11[3] + Gx1[108]*w11[4] + Gx1[109]*w11[5] + Gx1[110]*w11[6] + Gx1[111]*w11[7] + Gx1[112]*w11[8] + Gx1[113]*w11[9] + Gx1[114]*w11[10] + Gx1[115]*w11[11] + Gx1[116]*w11[12];
w12[9] += + Gx1[117]*w11[0] + Gx1[118]*w11[1] + Gx1[119]*w11[2] + Gx1[120]*w11[3] + Gx1[121]*w11[4] + Gx1[122]*w11[5] + Gx1[123]*w11[6] + Gx1[124]*w11[7] + Gx1[125]*w11[8] + Gx1[126]*w11[9] + Gx1[127]*w11[10] + Gx1[128]*w11[11] + Gx1[129]*w11[12];
w12[10] += + Gx1[130]*w11[0] + Gx1[131]*w11[1] + Gx1[132]*w11[2] + Gx1[133]*w11[3] + Gx1[134]*w11[4] + Gx1[135]*w11[5] + Gx1[136]*w11[6] + Gx1[137]*w11[7] + Gx1[138]*w11[8] + Gx1[139]*w11[9] + Gx1[140]*w11[10] + Gx1[141]*w11[11] + Gx1[142]*w11[12];
w12[11] += + Gx1[143]*w11[0] + Gx1[144]*w11[1] + Gx1[145]*w11[2] + Gx1[146]*w11[3] + Gx1[147]*w11[4] + Gx1[148]*w11[5] + Gx1[149]*w11[6] + Gx1[150]*w11[7] + Gx1[151]*w11[8] + Gx1[152]*w11[9] + Gx1[153]*w11[10] + Gx1[154]*w11[11] + Gx1[155]*w11[12];
w12[12] += + Gx1[156]*w11[0] + Gx1[157]*w11[1] + Gx1[158]*w11[2] + Gx1[159]*w11[3] + Gx1[160]*w11[4] + Gx1[161]*w11[5] + Gx1[162]*w11[6] + Gx1[163]*w11[7] + Gx1[164]*w11[8] + Gx1[165]*w11[9] + Gx1[166]*w11[10] + Gx1[167]*w11[11] + Gx1[168]*w11[12];
}

void acado_expansionStep( real_t* const Gx1, real_t* const Gu1, real_t* const U1, real_t* const w11, real_t* const w12 )
{
w12[0] += + Gx1[0]*w11[0] + Gx1[1]*w11[1] + Gx1[2]*w11[2] + Gx1[3]*w11[3] + Gx1[4]*w11[4] + Gx1[5]*w11[5] + Gx1[6]*w11[6] + Gx1[7]*w11[7] + Gx1[8]*w11[8] + Gx1[9]*w11[9] + Gx1[10]*w11[10] + Gx1[11]*w11[11] + Gx1[12]*w11[12];
w12[1] += + Gx1[13]*w11[0] + Gx1[14]*w11[1] + Gx1[15]*w11[2] + Gx1[16]*w11[3] + Gx1[17]*w11[4] + Gx1[18]*w11[5] + Gx1[19]*w11[6] + Gx1[20]*w11[7] + Gx1[21]*w11[8] + Gx1[22]*w11[9] + Gx1[23]*w11[10] + Gx1[24]*w11[11] + Gx1[25]*w11[12];
w12[2] += + Gx1[26]*w11[0] + Gx1[27]*w11[1] + Gx1[28]*w11[2] + Gx1[29]*w11[3] + Gx1[30]*w11[4] + Gx1[31]*w11[5] + Gx1[32]*w11[6] + Gx1[33]*w11[7] + Gx1[34]*w11[8] + Gx1[35]*w11[9] + Gx1[36]*w11[10] + Gx1[37]*w11[11] + Gx1[38]*w11[12];
w12[3] += + Gx1[39]*w11[0] + Gx1[40]*w11[1] + Gx1[41]*w11[2] + Gx1[42]*w11[3] + Gx1[43]*w11[4] + Gx1[44]*w11[5] + Gx1[45]*w11[6] + Gx1[46]*w11[7] + Gx1[47]*w11[8] + Gx1[48]*w11[9] + Gx1[49]*w11[10] + Gx1[50]*w11[11] + Gx1[51]*w11[12];
w12[4] += + Gx1[52]*w11[0] + Gx1[53]*w11[1] + Gx1[54]*w11[2] + Gx1[55]*w11[3] + Gx1[56]*w11[4] + Gx1[57]*w11[5] + Gx1[58]*w11[6] + Gx1[59]*w11[7] + Gx1[60]*w11[8] + Gx1[61]*w11[9] + Gx1[62]*w11[10] + Gx1[63]*w11[11] + Gx1[64]*w11[12];
w12[5] += + Gx1[65]*w11[0] + Gx1[66]*w11[1] + Gx1[67]*w11[2] + Gx1[68]*w11[3] + Gx1[69]*w11[4] + Gx1[70]*w11[5] + Gx1[71]*w11[6] + Gx1[72]*w11[7] + Gx1[73]*w11[8] + Gx1[74]*w11[9] + Gx1[75]*w11[10] + Gx1[76]*w11[11] + Gx1[77]*w11[12];
w12[6] += + Gx1[78]*w11[0] + Gx1[79]*w11[1] + Gx1[80]*w11[2] + Gx1[81]*w11[3] + Gx1[82]*w11[4] + Gx1[83]*w11[5] + Gx1[84]*w11[6] + Gx1[85]*w11[7] + Gx1[86]*w11[8] + Gx1[87]*w11[9] + Gx1[88]*w11[10] + Gx1[89]*w11[11] + Gx1[90]*w11[12];
w12[7] += + Gx1[91]*w11[0] + Gx1[92]*w11[1] + Gx1[93]*w11[2] + Gx1[94]*w11[3] + Gx1[95]*w11[4] + Gx1[96]*w11[5] + Gx1[97]*w11[6] + Gx1[98]*w11[7] + Gx1[99]*w11[8] + Gx1[100]*w11[9] + Gx1[101]*w11[10] + Gx1[102]*w11[11] + Gx1[103]*w11[12];
w12[8] += + Gx1[104]*w11[0] + Gx1[105]*w11[1] + Gx1[106]*w11[2] + Gx1[107]*w11[3] + Gx1[108]*w11[4] + Gx1[109]*w11[5] + Gx1[110]*w11[6] + Gx1[111]*w11[7] + Gx1[112]*w11[8] + Gx1[113]*w11[9] + Gx1[114]*w11[10] + Gx1[115]*w11[11] + Gx1[116]*w11[12];
w12[9] += + Gx1[117]*w11[0] + Gx1[118]*w11[1] + Gx1[119]*w11[2] + Gx1[120]*w11[3] + Gx1[121]*w11[4] + Gx1[122]*w11[5] + Gx1[123]*w11[6] + Gx1[124]*w11[7] + Gx1[125]*w11[8] + Gx1[126]*w11[9] + Gx1[127]*w11[10] + Gx1[128]*w11[11] + Gx1[129]*w11[12];
w12[10] += + Gx1[130]*w11[0] + Gx1[131]*w11[1] + Gx1[132]*w11[2] + Gx1[133]*w11[3] + Gx1[134]*w11[4] + Gx1[135]*w11[5] + Gx1[136]*w11[6] + Gx1[137]*w11[7] + Gx1[138]*w11[8] + Gx1[139]*w11[9] + Gx1[140]*w11[10] + Gx1[141]*w11[11] + Gx1[142]*w11[12];
w12[11] += + Gx1[143]*w11[0] + Gx1[144]*w11[1] + Gx1[145]*w11[2] + Gx1[146]*w11[3] + Gx1[147]*w11[4] + Gx1[148]*w11[5] + Gx1[149]*w11[6] + Gx1[150]*w11[7] + Gx1[151]*w11[8] + Gx1[152]*w11[9] + Gx1[153]*w11[10] + Gx1[154]*w11[11] + Gx1[155]*w11[12];
w12[12] += + Gx1[156]*w11[0] + Gx1[157]*w11[1] + Gx1[158]*w11[2] + Gx1[159]*w11[3] + Gx1[160]*w11[4] + Gx1[161]*w11[5] + Gx1[162]*w11[6] + Gx1[163]*w11[7] + Gx1[164]*w11[8] + Gx1[165]*w11[9] + Gx1[166]*w11[10] + Gx1[167]*w11[11] + Gx1[168]*w11[12];
w12[0] += + Gu1[0]*U1[0] + Gu1[1]*U1[1];
w12[1] += + Gu1[2]*U1[0] + Gu1[3]*U1[1];
w12[2] += + Gu1[4]*U1[0] + Gu1[5]*U1[1];
w12[3] += + Gu1[6]*U1[0] + Gu1[7]*U1[1];
w12[4] += + Gu1[8]*U1[0] + Gu1[9]*U1[1];
w12[5] += + Gu1[10]*U1[0] + Gu1[11]*U1[1];
w12[6] += + Gu1[12]*U1[0] + Gu1[13]*U1[1];
w12[7] += + Gu1[14]*U1[0] + Gu1[15]*U1[1];
w12[8] += + Gu1[16]*U1[0] + Gu1[17]*U1[1];
w12[9] += + Gu1[18]*U1[0] + Gu1[19]*U1[1];
w12[10] += + Gu1[20]*U1[0] + Gu1[21]*U1[1];
w12[11] += + Gu1[22]*U1[0] + Gu1[23]*U1[1];
w12[12] += + Gu1[24]*U1[0] + Gu1[25]*U1[1];
}

void acado_copyHTH( int iRow, int iCol )
{
acadoWorkspace.H[(iRow * 40) + (iCol * 2)] = acadoWorkspace.H[(iCol * 40) + (iRow * 2)];
acadoWorkspace.H[(iRow * 40) + (iCol * 2 + 1)] = acadoWorkspace.H[(iCol * 40 + 20) + (iRow * 2)];
acadoWorkspace.H[(iRow * 40 + 20) + (iCol * 2)] = acadoWorkspace.H[(iCol * 40) + (iRow * 2 + 1)];
acadoWorkspace.H[(iRow * 40 + 20) + (iCol * 2 + 1)] = acadoWorkspace.H[(iCol * 40 + 20) + (iRow * 2 + 1)];
}

void acado_multRDy( real_t* const R2, real_t* const Dy1, real_t* const RDy1 )
{
RDy1[0] = + R2[0]*Dy1[0] + R2[1]*Dy1[1] + R2[2]*Dy1[2] + R2[3]*Dy1[3];
RDy1[1] = + R2[4]*Dy1[0] + R2[5]*Dy1[1] + R2[6]*Dy1[2] + R2[7]*Dy1[3];
}

void acado_multQDy( real_t* const Q2, real_t* const Dy1, real_t* const QDy1 )
{
QDy1[0] = + Q2[0]*Dy1[0] + Q2[1]*Dy1[1] + Q2[2]*Dy1[2] + Q2[3]*Dy1[3];
QDy1[1] = + Q2[4]*Dy1[0] + Q2[5]*Dy1[1] + Q2[6]*Dy1[2] + Q2[7]*Dy1[3];
QDy1[2] = + Q2[8]*Dy1[0] + Q2[9]*Dy1[1] + Q2[10]*Dy1[2] + Q2[11]*Dy1[3];
QDy1[3] = + Q2[12]*Dy1[0] + Q2[13]*Dy1[1] + Q2[14]*Dy1[2] + Q2[15]*Dy1[3];
QDy1[4] = + Q2[16]*Dy1[0] + Q2[17]*Dy1[1] + Q2[18]*Dy1[2] + Q2[19]*Dy1[3];
QDy1[5] = + Q2[20]*Dy1[0] + Q2[21]*Dy1[1] + Q2[22]*Dy1[2] + Q2[23]*Dy1[3];
QDy1[6] = + Q2[24]*Dy1[0] + Q2[25]*Dy1[1] + Q2[26]*Dy1[2] + Q2[27]*Dy1[3];
QDy1[7] = + Q2[28]*Dy1[0] + Q2[29]*Dy1[1] + Q2[30]*Dy1[2] + Q2[31]*Dy1[3];
QDy1[8] = + Q2[32]*Dy1[0] + Q2[33]*Dy1[1] + Q2[34]*Dy1[2] + Q2[35]*Dy1[3];
QDy1[9] = + Q2[36]*Dy1[0] + Q2[37]*Dy1[1] + Q2[38]*Dy1[2] + Q2[39]*Dy1[3];
QDy1[10] = + Q2[40]*Dy1[0] + Q2[41]*Dy1[1] + Q2[42]*Dy1[2] + Q2[43]*Dy1[3];
QDy1[11] = + Q2[44]*Dy1[0] + Q2[45]*Dy1[1] + Q2[46]*Dy1[2] + Q2[47]*Dy1[3];
QDy1[12] = + Q2[48]*Dy1[0] + Q2[49]*Dy1[1] + Q2[50]*Dy1[2] + Q2[51]*Dy1[3];
}

void acado_multHxE( real_t* const Hx, real_t* const E, int row, int col )
{
acadoWorkspace.A[(row * 80) + (col * 2)] = + Hx[0]*E[0] + Hx[1]*E[2] + Hx[2]*E[4] + Hx[3]*E[6] + Hx[4]*E[8] + Hx[5]*E[10] + Hx[6]*E[12] + Hx[7]*E[14] + Hx[8]*E[16] + Hx[9]*E[18] + Hx[10]*E[20] + Hx[11]*E[22] + Hx[12]*E[24];
acadoWorkspace.A[(row * 80) + (col * 2 + 1)] = + Hx[0]*E[1] + Hx[1]*E[3] + Hx[2]*E[5] + Hx[3]*E[7] + Hx[4]*E[9] + Hx[5]*E[11] + Hx[6]*E[13] + Hx[7]*E[15] + Hx[8]*E[17] + Hx[9]*E[19] + Hx[10]*E[21] + Hx[11]*E[23] + Hx[12]*E[25];
acadoWorkspace.A[(row * 80 + 20) + (col * 2)] = + Hx[13]*E[0] + Hx[14]*E[2] + Hx[15]*E[4] + Hx[16]*E[6] + Hx[17]*E[8] + Hx[18]*E[10] + Hx[19]*E[12] + Hx[20]*E[14] + Hx[21]*E[16] + Hx[22]*E[18] + Hx[23]*E[20] + Hx[24]*E[22] + Hx[25]*E[24];
acadoWorkspace.A[(row * 80 + 20) + (col * 2 + 1)] = + Hx[13]*E[1] + Hx[14]*E[3] + Hx[15]*E[5] + Hx[16]*E[7] + Hx[17]*E[9] + Hx[18]*E[11] + Hx[19]*E[13] + Hx[20]*E[15] + Hx[21]*E[17] + Hx[22]*E[19] + Hx[23]*E[21] + Hx[24]*E[23] + Hx[25]*E[25];
acadoWorkspace.A[(row * 80 + 40) + (col * 2)] = + Hx[26]*E[0] + Hx[27]*E[2] + Hx[28]*E[4] + Hx[29]*E[6] + Hx[30]*E[8] + Hx[31]*E[10] + Hx[32]*E[12] + Hx[33]*E[14] + Hx[34]*E[16] + Hx[35]*E[18] + Hx[36]*E[20] + Hx[37]*E[22] + Hx[38]*E[24];
acadoWorkspace.A[(row * 80 + 40) + (col * 2 + 1)] = + Hx[26]*E[1] + Hx[27]*E[3] + Hx[28]*E[5] + Hx[29]*E[7] + Hx[30]*E[9] + Hx[31]*E[11] + Hx[32]*E[13] + Hx[33]*E[15] + Hx[34]*E[17] + Hx[35]*E[19] + Hx[36]*E[21] + Hx[37]*E[23] + Hx[38]*E[25];
acadoWorkspace.A[(row * 80 + 60) + (col * 2)] = + Hx[39]*E[0] + Hx[40]*E[2] + Hx[41]*E[4] + Hx[42]*E[6] + Hx[43]*E[8] + Hx[44]*E[10] + Hx[45]*E[12] + Hx[46]*E[14] + Hx[47]*E[16] + Hx[48]*E[18] + Hx[49]*E[20] + Hx[50]*E[22] + Hx[51]*E[24];
acadoWorkspace.A[(row * 80 + 60) + (col * 2 + 1)] = + Hx[39]*E[1] + Hx[40]*E[3] + Hx[41]*E[5] + Hx[42]*E[7] + Hx[43]*E[9] + Hx[44]*E[11] + Hx[45]*E[13] + Hx[46]*E[15] + Hx[47]*E[17] + Hx[48]*E[19] + Hx[49]*E[21] + Hx[50]*E[23] + Hx[51]*E[25];
}

void acado_macHxd( real_t* const Hx, real_t* const tmpd, real_t* const lbA, real_t* const ubA )
{
acadoWorkspace.evHxd[0] = + Hx[0]*tmpd[0] + Hx[1]*tmpd[1] + Hx[2]*tmpd[2] + Hx[3]*tmpd[3] + Hx[4]*tmpd[4] + Hx[5]*tmpd[5] + Hx[6]*tmpd[6] + Hx[7]*tmpd[7] + Hx[8]*tmpd[8] + Hx[9]*tmpd[9] + Hx[10]*tmpd[10] + Hx[11]*tmpd[11] + Hx[12]*tmpd[12];
acadoWorkspace.evHxd[1] = + Hx[13]*tmpd[0] + Hx[14]*tmpd[1] + Hx[15]*tmpd[2] + Hx[16]*tmpd[3] + Hx[17]*tmpd[4] + Hx[18]*tmpd[5] + Hx[19]*tmpd[6] + Hx[20]*tmpd[7] + Hx[21]*tmpd[8] + Hx[22]*tmpd[9] + Hx[23]*tmpd[10] + Hx[24]*tmpd[11] + Hx[25]*tmpd[12];
acadoWorkspace.evHxd[2] = + Hx[26]*tmpd[0] + Hx[27]*tmpd[1] + Hx[28]*tmpd[2] + Hx[29]*tmpd[3] + Hx[30]*tmpd[4] + Hx[31]*tmpd[5] + Hx[32]*tmpd[6] + Hx[33]*tmpd[7] + Hx[34]*tmpd[8] + Hx[35]*tmpd[9] + Hx[36]*tmpd[10] + Hx[37]*tmpd[11] + Hx[38]*tmpd[12];
acadoWorkspace.evHxd[3] = + Hx[39]*tmpd[0] + Hx[40]*tmpd[1] + Hx[41]*tmpd[2] + Hx[42]*tmpd[3] + Hx[43]*tmpd[4] + Hx[44]*tmpd[5] + Hx[45]*tmpd[6] + Hx[46]*tmpd[7] + Hx[47]*tmpd[8] + Hx[48]*tmpd[9] + Hx[49]*tmpd[10] + Hx[50]*tmpd[11] + Hx[51]*tmpd[12];
lbA[0] -= acadoWorkspace.evHxd[0];
lbA[1] -= acadoWorkspace.evHxd[1];
lbA[2] -= acadoWorkspace.evHxd[2];
lbA[3] -= acadoWorkspace.evHxd[3];
ubA[0] -= acadoWorkspace.evHxd[0];
ubA[1] -= acadoWorkspace.evHxd[1];
ubA[2] -= acadoWorkspace.evHxd[2];
ubA[3] -= acadoWorkspace.evHxd[3];
}

void acado_condensePrep(  )
{
int lRun1;
int lRun2;
acado_moveGxT( acadoWorkspace.evGx, acadoWorkspace.C );
acado_multGxGx( &(acadoWorkspace.evGx[ 169 ]), acadoWorkspace.C, &(acadoWorkspace.C[ 169 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 338 ]), &(acadoWorkspace.C[ 169 ]), &(acadoWorkspace.C[ 338 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 507 ]), &(acadoWorkspace.C[ 338 ]), &(acadoWorkspace.C[ 507 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.C[ 507 ]), &(acadoWorkspace.C[ 676 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.C[ 676 ]), &(acadoWorkspace.C[ 845 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.C[ 845 ]), &(acadoWorkspace.C[ 1014 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.C[ 1014 ]), &(acadoWorkspace.C[ 1183 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.C[ 1183 ]), &(acadoWorkspace.C[ 1352 ]) );
acado_multGxGx( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.C[ 1352 ]), &(acadoWorkspace.C[ 1521 ]) );
/* Column: 0 */
acado_moveGuE( acadoWorkspace.evGu, acadoWorkspace.E );
acado_multGxGu( &(acadoWorkspace.evGx[ 169 ]), acadoWorkspace.E, &(acadoWorkspace.E[ 26 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 338 ]), &(acadoWorkspace.E[ 26 ]), &(acadoWorkspace.E[ 52 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 507 ]), &(acadoWorkspace.E[ 52 ]), &(acadoWorkspace.E[ 78 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.E[ 78 ]), &(acadoWorkspace.E[ 104 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.E[ 104 ]), &(acadoWorkspace.E[ 130 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.E[ 130 ]), &(acadoWorkspace.E[ 156 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 156 ]), &(acadoWorkspace.E[ 182 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 182 ]), &(acadoWorkspace.E[ 208 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 208 ]), &(acadoWorkspace.E[ 234 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 234 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 208 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 182 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 156 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.E[ 130 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.W1, 5, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 845 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 845 ]), &(acadoWorkspace.E[ 104 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 104 ]), acadoWorkspace.W1, 4, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 676 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 676 ]), &(acadoWorkspace.E[ 78 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 78 ]), acadoWorkspace.W1, 3, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 507 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 507 ]), &(acadoWorkspace.E[ 52 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 52 ]), acadoWorkspace.W1, 2, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 338 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 338 ]), &(acadoWorkspace.E[ 26 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 26 ]), acadoWorkspace.W1, 1, 0 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 169 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 169 ]), acadoWorkspace.E, acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( acadoWorkspace.R1, acadoWorkspace.evGu, acadoWorkspace.W1, 0 );

/* Column: 1 */
acado_moveGuE( &(acadoWorkspace.evGu[ 26 ]), &(acadoWorkspace.E[ 260 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 338 ]), &(acadoWorkspace.E[ 260 ]), &(acadoWorkspace.E[ 286 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 507 ]), &(acadoWorkspace.E[ 286 ]), &(acadoWorkspace.E[ 312 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.E[ 312 ]), &(acadoWorkspace.E[ 338 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.E[ 338 ]), &(acadoWorkspace.E[ 364 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.E[ 364 ]), &(acadoWorkspace.E[ 390 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 390 ]), &(acadoWorkspace.E[ 416 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 416 ]), &(acadoWorkspace.E[ 442 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 442 ]), &(acadoWorkspace.E[ 468 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 468 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 442 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 416 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 390 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.E[ 364 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.W1, 5, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 845 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 845 ]), &(acadoWorkspace.E[ 338 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 104 ]), acadoWorkspace.W1, 4, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 676 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 676 ]), &(acadoWorkspace.E[ 312 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 78 ]), acadoWorkspace.W1, 3, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 507 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 507 ]), &(acadoWorkspace.E[ 286 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 52 ]), acadoWorkspace.W1, 2, 1 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 338 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 338 ]), &(acadoWorkspace.E[ 260 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 4 ]), &(acadoWorkspace.evGu[ 26 ]), acadoWorkspace.W1, 1 );

/* Column: 2 */
acado_moveGuE( &(acadoWorkspace.evGu[ 52 ]), &(acadoWorkspace.E[ 494 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 507 ]), &(acadoWorkspace.E[ 494 ]), &(acadoWorkspace.E[ 520 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.E[ 520 ]), &(acadoWorkspace.E[ 546 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.E[ 546 ]), &(acadoWorkspace.E[ 572 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.E[ 572 ]), &(acadoWorkspace.E[ 598 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 598 ]), &(acadoWorkspace.E[ 624 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 624 ]), &(acadoWorkspace.E[ 650 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 650 ]), &(acadoWorkspace.E[ 676 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 676 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 650 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 624 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 598 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.E[ 572 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.W1, 5, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 845 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 845 ]), &(acadoWorkspace.E[ 546 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 104 ]), acadoWorkspace.W1, 4, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 676 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 676 ]), &(acadoWorkspace.E[ 520 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 78 ]), acadoWorkspace.W1, 3, 2 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 507 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 507 ]), &(acadoWorkspace.E[ 494 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 8 ]), &(acadoWorkspace.evGu[ 52 ]), acadoWorkspace.W1, 2 );

/* Column: 3 */
acado_moveGuE( &(acadoWorkspace.evGu[ 78 ]), &(acadoWorkspace.E[ 702 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.E[ 702 ]), &(acadoWorkspace.E[ 728 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.E[ 728 ]), &(acadoWorkspace.E[ 754 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.E[ 754 ]), &(acadoWorkspace.E[ 780 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 780 ]), &(acadoWorkspace.E[ 806 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 806 ]), &(acadoWorkspace.E[ 832 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 832 ]), &(acadoWorkspace.E[ 858 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 858 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 3 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 832 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 3 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 806 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 3 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 780 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6, 3 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.E[ 754 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.W1, 5, 3 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 845 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 845 ]), &(acadoWorkspace.E[ 728 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 104 ]), acadoWorkspace.W1, 4, 3 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 676 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 676 ]), &(acadoWorkspace.E[ 702 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 12 ]), &(acadoWorkspace.evGu[ 78 ]), acadoWorkspace.W1, 3 );

/* Column: 4 */
acado_moveGuE( &(acadoWorkspace.evGu[ 104 ]), &(acadoWorkspace.E[ 884 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.E[ 884 ]), &(acadoWorkspace.E[ 910 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.E[ 910 ]), &(acadoWorkspace.E[ 936 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 936 ]), &(acadoWorkspace.E[ 962 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 962 ]), &(acadoWorkspace.E[ 988 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 988 ]), &(acadoWorkspace.E[ 1014 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 1014 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 4 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 988 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 4 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 962 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 4 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 936 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6, 4 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.E[ 910 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.W1, 5, 4 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 845 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 845 ]), &(acadoWorkspace.E[ 884 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 16 ]), &(acadoWorkspace.evGu[ 104 ]), acadoWorkspace.W1, 4 );

/* Column: 5 */
acado_moveGuE( &(acadoWorkspace.evGu[ 130 ]), &(acadoWorkspace.E[ 1040 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.E[ 1040 ]), &(acadoWorkspace.E[ 1066 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 1066 ]), &(acadoWorkspace.E[ 1092 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 1092 ]), &(acadoWorkspace.E[ 1118 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 1118 ]), &(acadoWorkspace.E[ 1144 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 1144 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 5 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 1118 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 5 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 1092 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 5 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 1066 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6, 5 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.E[ 1040 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 20 ]), &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.W1, 5 );

/* Column: 6 */
acado_moveGuE( &(acadoWorkspace.evGu[ 156 ]), &(acadoWorkspace.E[ 1170 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.E[ 1170 ]), &(acadoWorkspace.E[ 1196 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 1196 ]), &(acadoWorkspace.E[ 1222 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 1222 ]), &(acadoWorkspace.E[ 1248 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 1248 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 6 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 1222 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 6 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 1196 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7, 6 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.E[ 1170 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 24 ]), &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.W1, 6 );

/* Column: 7 */
acado_moveGuE( &(acadoWorkspace.evGu[ 182 ]), &(acadoWorkspace.E[ 1274 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.E[ 1274 ]), &(acadoWorkspace.E[ 1300 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 1300 ]), &(acadoWorkspace.E[ 1326 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 1326 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 7 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 1300 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8, 7 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.E[ 1274 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 28 ]), &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.W1, 7 );

/* Column: 8 */
acado_moveGuE( &(acadoWorkspace.evGu[ 208 ]), &(acadoWorkspace.E[ 1352 ]) );
acado_multGxGu( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.E[ 1352 ]), &(acadoWorkspace.E[ 1378 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 1378 ]), acadoWorkspace.W1 );
acado_multBTW1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9, 8 );
acado_multGxTGu( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.W1, acadoWorkspace.W2 );
acado_multQEW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.E[ 1352 ]), acadoWorkspace.W2, acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 32 ]), &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.W1, 8 );

/* Column: 9 */
acado_moveGuE( &(acadoWorkspace.evGu[ 234 ]), &(acadoWorkspace.E[ 1404 ]) );

acado_multGxGu( acadoWorkspace.QN1, &(acadoWorkspace.E[ 1404 ]), acadoWorkspace.W1 );
acado_multBTW1_R1( &(acadoWorkspace.R1[ 36 ]), &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.W1, 9 );

acado_copyHTH( 0, 1 );
acado_copyHTH( 0, 2 );
acado_copyHTH( 1, 2 );
acado_copyHTH( 0, 3 );
acado_copyHTH( 1, 3 );
acado_copyHTH( 2, 3 );
acado_copyHTH( 0, 4 );
acado_copyHTH( 1, 4 );
acado_copyHTH( 2, 4 );
acado_copyHTH( 3, 4 );
acado_copyHTH( 0, 5 );
acado_copyHTH( 1, 5 );
acado_copyHTH( 2, 5 );
acado_copyHTH( 3, 5 );
acado_copyHTH( 4, 5 );
acado_copyHTH( 0, 6 );
acado_copyHTH( 1, 6 );
acado_copyHTH( 2, 6 );
acado_copyHTH( 3, 6 );
acado_copyHTH( 4, 6 );
acado_copyHTH( 5, 6 );
acado_copyHTH( 0, 7 );
acado_copyHTH( 1, 7 );
acado_copyHTH( 2, 7 );
acado_copyHTH( 3, 7 );
acado_copyHTH( 4, 7 );
acado_copyHTH( 5, 7 );
acado_copyHTH( 6, 7 );
acado_copyHTH( 0, 8 );
acado_copyHTH( 1, 8 );
acado_copyHTH( 2, 8 );
acado_copyHTH( 3, 8 );
acado_copyHTH( 4, 8 );
acado_copyHTH( 5, 8 );
acado_copyHTH( 6, 8 );
acado_copyHTH( 7, 8 );
acado_copyHTH( 0, 9 );
acado_copyHTH( 1, 9 );
acado_copyHTH( 2, 9 );
acado_copyHTH( 3, 9 );
acado_copyHTH( 4, 9 );
acado_copyHTH( 5, 9 );
acado_copyHTH( 6, 9 );
acado_copyHTH( 7, 9 );
acado_copyHTH( 8, 9 );

for (lRun2 = 0; lRun2 < 130; ++lRun2)
acadoWorkspace.sbar[lRun2 + 13] = acadoWorkspace.d[lRun2];

acadoWorkspace.lb[0] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[0];
acadoWorkspace.lb[1] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[1];
acadoWorkspace.lb[2] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[2];
acadoWorkspace.lb[3] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[3];
acadoWorkspace.lb[4] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[4];
acadoWorkspace.lb[5] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[5];
acadoWorkspace.lb[6] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[6];
acadoWorkspace.lb[7] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[7];
acadoWorkspace.lb[8] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[8];
acadoWorkspace.lb[9] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[9];
acadoWorkspace.lb[10] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[10];
acadoWorkspace.lb[11] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[11];
acadoWorkspace.lb[12] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[12];
acadoWorkspace.lb[13] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[13];
acadoWorkspace.lb[14] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[14];
acadoWorkspace.lb[15] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[15];
acadoWorkspace.lb[16] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[16];
acadoWorkspace.lb[17] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[17];
acadoWorkspace.lb[18] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[18];
acadoWorkspace.lb[19] = (real_t)-1.0000000000000000e+12 - acadoVariables.u[19];
acadoWorkspace.ub[0] = (real_t)1.0000000000000000e+12 - acadoVariables.u[0];
acadoWorkspace.ub[1] = (real_t)1.0000000000000000e+12 - acadoVariables.u[1];
acadoWorkspace.ub[2] = (real_t)1.0000000000000000e+12 - acadoVariables.u[2];
acadoWorkspace.ub[3] = (real_t)1.0000000000000000e+12 - acadoVariables.u[3];
acadoWorkspace.ub[4] = (real_t)1.0000000000000000e+12 - acadoVariables.u[4];
acadoWorkspace.ub[5] = (real_t)1.0000000000000000e+12 - acadoVariables.u[5];
acadoWorkspace.ub[6] = (real_t)1.0000000000000000e+12 - acadoVariables.u[6];
acadoWorkspace.ub[7] = (real_t)1.0000000000000000e+12 - acadoVariables.u[7];
acadoWorkspace.ub[8] = (real_t)1.0000000000000000e+12 - acadoVariables.u[8];
acadoWorkspace.ub[9] = (real_t)1.0000000000000000e+12 - acadoVariables.u[9];
acadoWorkspace.ub[10] = (real_t)1.0000000000000000e+12 - acadoVariables.u[10];
acadoWorkspace.ub[11] = (real_t)1.0000000000000000e+12 - acadoVariables.u[11];
acadoWorkspace.ub[12] = (real_t)1.0000000000000000e+12 - acadoVariables.u[12];
acadoWorkspace.ub[13] = (real_t)1.0000000000000000e+12 - acadoVariables.u[13];
acadoWorkspace.ub[14] = (real_t)1.0000000000000000e+12 - acadoVariables.u[14];
acadoWorkspace.ub[15] = (real_t)1.0000000000000000e+12 - acadoVariables.u[15];
acadoWorkspace.ub[16] = (real_t)1.0000000000000000e+12 - acadoVariables.u[16];
acadoWorkspace.ub[17] = (real_t)1.0000000000000000e+12 - acadoVariables.u[17];
acadoWorkspace.ub[18] = (real_t)1.0000000000000000e+12 - acadoVariables.u[18];
acadoWorkspace.ub[19] = (real_t)1.0000000000000000e+12 - acadoVariables.u[19];

for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
acadoWorkspace.conValueIn[0] = acadoVariables.x[lRun1 * 13];
acadoWorkspace.conValueIn[1] = acadoVariables.x[lRun1 * 13 + 1];
acadoWorkspace.conValueIn[2] = acadoVariables.x[lRun1 * 13 + 2];
acadoWorkspace.conValueIn[3] = acadoVariables.x[lRun1 * 13 + 3];
acadoWorkspace.conValueIn[4] = acadoVariables.x[lRun1 * 13 + 4];
acadoWorkspace.conValueIn[5] = acadoVariables.x[lRun1 * 13 + 5];
acadoWorkspace.conValueIn[6] = acadoVariables.x[lRun1 * 13 + 6];
acadoWorkspace.conValueIn[7] = acadoVariables.x[lRun1 * 13 + 7];
acadoWorkspace.conValueIn[8] = acadoVariables.x[lRun1 * 13 + 8];
acadoWorkspace.conValueIn[9] = acadoVariables.x[lRun1 * 13 + 9];
acadoWorkspace.conValueIn[10] = acadoVariables.x[lRun1 * 13 + 10];
acadoWorkspace.conValueIn[11] = acadoVariables.x[lRun1 * 13 + 11];
acadoWorkspace.conValueIn[12] = acadoVariables.x[lRun1 * 13 + 12];
acadoWorkspace.conValueIn[13] = acadoVariables.u[lRun1 * 2];
acadoWorkspace.conValueIn[14] = acadoVariables.u[lRun1 * 2 + 1];
acadoWorkspace.conValueIn[15] = acadoVariables.od[lRun1 * 8];
acadoWorkspace.conValueIn[16] = acadoVariables.od[lRun1 * 8 + 1];
acadoWorkspace.conValueIn[17] = acadoVariables.od[lRun1 * 8 + 2];
acadoWorkspace.conValueIn[18] = acadoVariables.od[lRun1 * 8 + 3];
acadoWorkspace.conValueIn[19] = acadoVariables.od[lRun1 * 8 + 4];
acadoWorkspace.conValueIn[20] = acadoVariables.od[lRun1 * 8 + 5];
acadoWorkspace.conValueIn[21] = acadoVariables.od[lRun1 * 8 + 6];
acadoWorkspace.conValueIn[22] = acadoVariables.od[lRun1 * 8 + 7];
acado_evaluatePathConstraints( acadoWorkspace.conValueIn, acadoWorkspace.conValueOut );
acadoWorkspace.evH[lRun1 * 4] = acadoWorkspace.conValueOut[0];
acadoWorkspace.evH[lRun1 * 4 + 1] = acadoWorkspace.conValueOut[1];
acadoWorkspace.evH[lRun1 * 4 + 2] = acadoWorkspace.conValueOut[2];
acadoWorkspace.evH[lRun1 * 4 + 3] = acadoWorkspace.conValueOut[3];

acadoWorkspace.evHx[lRun1 * 52] = acadoWorkspace.conValueOut[4];
acadoWorkspace.evHx[lRun1 * 52 + 1] = acadoWorkspace.conValueOut[5];
acadoWorkspace.evHx[lRun1 * 52 + 2] = acadoWorkspace.conValueOut[6];
acadoWorkspace.evHx[lRun1 * 52 + 3] = acadoWorkspace.conValueOut[7];
acadoWorkspace.evHx[lRun1 * 52 + 4] = acadoWorkspace.conValueOut[8];
acadoWorkspace.evHx[lRun1 * 52 + 5] = acadoWorkspace.conValueOut[9];
acadoWorkspace.evHx[lRun1 * 52 + 6] = acadoWorkspace.conValueOut[10];
acadoWorkspace.evHx[lRun1 * 52 + 7] = acadoWorkspace.conValueOut[11];
acadoWorkspace.evHx[lRun1 * 52 + 8] = acadoWorkspace.conValueOut[12];
acadoWorkspace.evHx[lRun1 * 52 + 9] = acadoWorkspace.conValueOut[13];
acadoWorkspace.evHx[lRun1 * 52 + 10] = acadoWorkspace.conValueOut[14];
acadoWorkspace.evHx[lRun1 * 52 + 11] = acadoWorkspace.conValueOut[15];
acadoWorkspace.evHx[lRun1 * 52 + 12] = acadoWorkspace.conValueOut[16];
acadoWorkspace.evHx[lRun1 * 52 + 13] = acadoWorkspace.conValueOut[17];
acadoWorkspace.evHx[lRun1 * 52 + 14] = acadoWorkspace.conValueOut[18];
acadoWorkspace.evHx[lRun1 * 52 + 15] = acadoWorkspace.conValueOut[19];
acadoWorkspace.evHx[lRun1 * 52 + 16] = acadoWorkspace.conValueOut[20];
acadoWorkspace.evHx[lRun1 * 52 + 17] = acadoWorkspace.conValueOut[21];
acadoWorkspace.evHx[lRun1 * 52 + 18] = acadoWorkspace.conValueOut[22];
acadoWorkspace.evHx[lRun1 * 52 + 19] = acadoWorkspace.conValueOut[23];
acadoWorkspace.evHx[lRun1 * 52 + 20] = acadoWorkspace.conValueOut[24];
acadoWorkspace.evHx[lRun1 * 52 + 21] = acadoWorkspace.conValueOut[25];
acadoWorkspace.evHx[lRun1 * 52 + 22] = acadoWorkspace.conValueOut[26];
acadoWorkspace.evHx[lRun1 * 52 + 23] = acadoWorkspace.conValueOut[27];
acadoWorkspace.evHx[lRun1 * 52 + 24] = acadoWorkspace.conValueOut[28];
acadoWorkspace.evHx[lRun1 * 52 + 25] = acadoWorkspace.conValueOut[29];
acadoWorkspace.evHx[lRun1 * 52 + 26] = acadoWorkspace.conValueOut[30];
acadoWorkspace.evHx[lRun1 * 52 + 27] = acadoWorkspace.conValueOut[31];
acadoWorkspace.evHx[lRun1 * 52 + 28] = acadoWorkspace.conValueOut[32];
acadoWorkspace.evHx[lRun1 * 52 + 29] = acadoWorkspace.conValueOut[33];
acadoWorkspace.evHx[lRun1 * 52 + 30] = acadoWorkspace.conValueOut[34];
acadoWorkspace.evHx[lRun1 * 52 + 31] = acadoWorkspace.conValueOut[35];
acadoWorkspace.evHx[lRun1 * 52 + 32] = acadoWorkspace.conValueOut[36];
acadoWorkspace.evHx[lRun1 * 52 + 33] = acadoWorkspace.conValueOut[37];
acadoWorkspace.evHx[lRun1 * 52 + 34] = acadoWorkspace.conValueOut[38];
acadoWorkspace.evHx[lRun1 * 52 + 35] = acadoWorkspace.conValueOut[39];
acadoWorkspace.evHx[lRun1 * 52 + 36] = acadoWorkspace.conValueOut[40];
acadoWorkspace.evHx[lRun1 * 52 + 37] = acadoWorkspace.conValueOut[41];
acadoWorkspace.evHx[lRun1 * 52 + 38] = acadoWorkspace.conValueOut[42];
acadoWorkspace.evHx[lRun1 * 52 + 39] = acadoWorkspace.conValueOut[43];
acadoWorkspace.evHx[lRun1 * 52 + 40] = acadoWorkspace.conValueOut[44];
acadoWorkspace.evHx[lRun1 * 52 + 41] = acadoWorkspace.conValueOut[45];
acadoWorkspace.evHx[lRun1 * 52 + 42] = acadoWorkspace.conValueOut[46];
acadoWorkspace.evHx[lRun1 * 52 + 43] = acadoWorkspace.conValueOut[47];
acadoWorkspace.evHx[lRun1 * 52 + 44] = acadoWorkspace.conValueOut[48];
acadoWorkspace.evHx[lRun1 * 52 + 45] = acadoWorkspace.conValueOut[49];
acadoWorkspace.evHx[lRun1 * 52 + 46] = acadoWorkspace.conValueOut[50];
acadoWorkspace.evHx[lRun1 * 52 + 47] = acadoWorkspace.conValueOut[51];
acadoWorkspace.evHx[lRun1 * 52 + 48] = acadoWorkspace.conValueOut[52];
acadoWorkspace.evHx[lRun1 * 52 + 49] = acadoWorkspace.conValueOut[53];
acadoWorkspace.evHx[lRun1 * 52 + 50] = acadoWorkspace.conValueOut[54];
acadoWorkspace.evHx[lRun1 * 52 + 51] = acadoWorkspace.conValueOut[55];
acadoWorkspace.evHu[lRun1 * 8] = acadoWorkspace.conValueOut[56];
acadoWorkspace.evHu[lRun1 * 8 + 1] = acadoWorkspace.conValueOut[57];
acadoWorkspace.evHu[lRun1 * 8 + 2] = acadoWorkspace.conValueOut[58];
acadoWorkspace.evHu[lRun1 * 8 + 3] = acadoWorkspace.conValueOut[59];
acadoWorkspace.evHu[lRun1 * 8 + 4] = acadoWorkspace.conValueOut[60];
acadoWorkspace.evHu[lRun1 * 8 + 5] = acadoWorkspace.conValueOut[61];
acadoWorkspace.evHu[lRun1 * 8 + 6] = acadoWorkspace.conValueOut[62];
acadoWorkspace.evHu[lRun1 * 8 + 7] = acadoWorkspace.conValueOut[63];
}



acado_multHxE( &(acadoWorkspace.evHx[ 52 ]), acadoWorkspace.E, 1, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 104 ]), &(acadoWorkspace.E[ 26 ]), 2, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 104 ]), &(acadoWorkspace.E[ 260 ]), 2, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 156 ]), &(acadoWorkspace.E[ 52 ]), 3, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 156 ]), &(acadoWorkspace.E[ 286 ]), 3, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 156 ]), &(acadoWorkspace.E[ 494 ]), 3, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 208 ]), &(acadoWorkspace.E[ 78 ]), 4, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 208 ]), &(acadoWorkspace.E[ 312 ]), 4, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 208 ]), &(acadoWorkspace.E[ 520 ]), 4, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 208 ]), &(acadoWorkspace.E[ 702 ]), 4, 3 );
acado_multHxE( &(acadoWorkspace.evHx[ 260 ]), &(acadoWorkspace.E[ 104 ]), 5, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 260 ]), &(acadoWorkspace.E[ 338 ]), 5, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 260 ]), &(acadoWorkspace.E[ 546 ]), 5, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 260 ]), &(acadoWorkspace.E[ 728 ]), 5, 3 );
acado_multHxE( &(acadoWorkspace.evHx[ 260 ]), &(acadoWorkspace.E[ 884 ]), 5, 4 );
acado_multHxE( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.E[ 130 ]), 6, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.E[ 364 ]), 6, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.E[ 572 ]), 6, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.E[ 754 ]), 6, 3 );
acado_multHxE( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.E[ 910 ]), 6, 4 );
acado_multHxE( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.E[ 1040 ]), 6, 5 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 156 ]), 7, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 390 ]), 7, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 598 ]), 7, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 780 ]), 7, 3 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 936 ]), 7, 4 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 1066 ]), 7, 5 );
acado_multHxE( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.E[ 1170 ]), 7, 6 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 182 ]), 8, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 416 ]), 8, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 624 ]), 8, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 806 ]), 8, 3 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 962 ]), 8, 4 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 1092 ]), 8, 5 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 1196 ]), 8, 6 );
acado_multHxE( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.E[ 1274 ]), 8, 7 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 208 ]), 9, 0 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 442 ]), 9, 1 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 650 ]), 9, 2 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 832 ]), 9, 3 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 988 ]), 9, 4 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 1118 ]), 9, 5 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 1222 ]), 9, 6 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 1300 ]), 9, 7 );
acado_multHxE( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.E[ 1352 ]), 9, 8 );

acadoWorkspace.A[0] = acadoWorkspace.evHu[0];
acadoWorkspace.A[1] = acadoWorkspace.evHu[1];
acadoWorkspace.A[20] = acadoWorkspace.evHu[2];
acadoWorkspace.A[21] = acadoWorkspace.evHu[3];
acadoWorkspace.A[40] = acadoWorkspace.evHu[4];
acadoWorkspace.A[41] = acadoWorkspace.evHu[5];
acadoWorkspace.A[60] = acadoWorkspace.evHu[6];
acadoWorkspace.A[61] = acadoWorkspace.evHu[7];
acadoWorkspace.A[82] = acadoWorkspace.evHu[8];
acadoWorkspace.A[83] = acadoWorkspace.evHu[9];
acadoWorkspace.A[102] = acadoWorkspace.evHu[10];
acadoWorkspace.A[103] = acadoWorkspace.evHu[11];
acadoWorkspace.A[122] = acadoWorkspace.evHu[12];
acadoWorkspace.A[123] = acadoWorkspace.evHu[13];
acadoWorkspace.A[142] = acadoWorkspace.evHu[14];
acadoWorkspace.A[143] = acadoWorkspace.evHu[15];
acadoWorkspace.A[164] = acadoWorkspace.evHu[16];
acadoWorkspace.A[165] = acadoWorkspace.evHu[17];
acadoWorkspace.A[184] = acadoWorkspace.evHu[18];
acadoWorkspace.A[185] = acadoWorkspace.evHu[19];
acadoWorkspace.A[204] = acadoWorkspace.evHu[20];
acadoWorkspace.A[205] = acadoWorkspace.evHu[21];
acadoWorkspace.A[224] = acadoWorkspace.evHu[22];
acadoWorkspace.A[225] = acadoWorkspace.evHu[23];
acadoWorkspace.A[246] = acadoWorkspace.evHu[24];
acadoWorkspace.A[247] = acadoWorkspace.evHu[25];
acadoWorkspace.A[266] = acadoWorkspace.evHu[26];
acadoWorkspace.A[267] = acadoWorkspace.evHu[27];
acadoWorkspace.A[286] = acadoWorkspace.evHu[28];
acadoWorkspace.A[287] = acadoWorkspace.evHu[29];
acadoWorkspace.A[306] = acadoWorkspace.evHu[30];
acadoWorkspace.A[307] = acadoWorkspace.evHu[31];
acadoWorkspace.A[328] = acadoWorkspace.evHu[32];
acadoWorkspace.A[329] = acadoWorkspace.evHu[33];
acadoWorkspace.A[348] = acadoWorkspace.evHu[34];
acadoWorkspace.A[349] = acadoWorkspace.evHu[35];
acadoWorkspace.A[368] = acadoWorkspace.evHu[36];
acadoWorkspace.A[369] = acadoWorkspace.evHu[37];
acadoWorkspace.A[388] = acadoWorkspace.evHu[38];
acadoWorkspace.A[389] = acadoWorkspace.evHu[39];
acadoWorkspace.A[410] = acadoWorkspace.evHu[40];
acadoWorkspace.A[411] = acadoWorkspace.evHu[41];
acadoWorkspace.A[430] = acadoWorkspace.evHu[42];
acadoWorkspace.A[431] = acadoWorkspace.evHu[43];
acadoWorkspace.A[450] = acadoWorkspace.evHu[44];
acadoWorkspace.A[451] = acadoWorkspace.evHu[45];
acadoWorkspace.A[470] = acadoWorkspace.evHu[46];
acadoWorkspace.A[471] = acadoWorkspace.evHu[47];
acadoWorkspace.A[492] = acadoWorkspace.evHu[48];
acadoWorkspace.A[493] = acadoWorkspace.evHu[49];
acadoWorkspace.A[512] = acadoWorkspace.evHu[50];
acadoWorkspace.A[513] = acadoWorkspace.evHu[51];
acadoWorkspace.A[532] = acadoWorkspace.evHu[52];
acadoWorkspace.A[533] = acadoWorkspace.evHu[53];
acadoWorkspace.A[552] = acadoWorkspace.evHu[54];
acadoWorkspace.A[553] = acadoWorkspace.evHu[55];
acadoWorkspace.A[574] = acadoWorkspace.evHu[56];
acadoWorkspace.A[575] = acadoWorkspace.evHu[57];
acadoWorkspace.A[594] = acadoWorkspace.evHu[58];
acadoWorkspace.A[595] = acadoWorkspace.evHu[59];
acadoWorkspace.A[614] = acadoWorkspace.evHu[60];
acadoWorkspace.A[615] = acadoWorkspace.evHu[61];
acadoWorkspace.A[634] = acadoWorkspace.evHu[62];
acadoWorkspace.A[635] = acadoWorkspace.evHu[63];
acadoWorkspace.A[656] = acadoWorkspace.evHu[64];
acadoWorkspace.A[657] = acadoWorkspace.evHu[65];
acadoWorkspace.A[676] = acadoWorkspace.evHu[66];
acadoWorkspace.A[677] = acadoWorkspace.evHu[67];
acadoWorkspace.A[696] = acadoWorkspace.evHu[68];
acadoWorkspace.A[697] = acadoWorkspace.evHu[69];
acadoWorkspace.A[716] = acadoWorkspace.evHu[70];
acadoWorkspace.A[717] = acadoWorkspace.evHu[71];
acadoWorkspace.A[738] = acadoWorkspace.evHu[72];
acadoWorkspace.A[739] = acadoWorkspace.evHu[73];
acadoWorkspace.A[758] = acadoWorkspace.evHu[74];
acadoWorkspace.A[759] = acadoWorkspace.evHu[75];
acadoWorkspace.A[778] = acadoWorkspace.evHu[76];
acadoWorkspace.A[779] = acadoWorkspace.evHu[77];
acadoWorkspace.A[798] = acadoWorkspace.evHu[78];
acadoWorkspace.A[799] = acadoWorkspace.evHu[79];
acadoWorkspace.lbA[0] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[0];
acadoWorkspace.lbA[1] = - acadoWorkspace.evH[1];
acadoWorkspace.lbA[2] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[2];
acadoWorkspace.lbA[3] = - acadoWorkspace.evH[3];
acadoWorkspace.lbA[4] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[4];
acadoWorkspace.lbA[5] = - acadoWorkspace.evH[5];
acadoWorkspace.lbA[6] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[6];
acadoWorkspace.lbA[7] = - acadoWorkspace.evH[7];
acadoWorkspace.lbA[8] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[8];
acadoWorkspace.lbA[9] = - acadoWorkspace.evH[9];
acadoWorkspace.lbA[10] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[10];
acadoWorkspace.lbA[11] = - acadoWorkspace.evH[11];
acadoWorkspace.lbA[12] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[12];
acadoWorkspace.lbA[13] = - acadoWorkspace.evH[13];
acadoWorkspace.lbA[14] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[14];
acadoWorkspace.lbA[15] = - acadoWorkspace.evH[15];
acadoWorkspace.lbA[16] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[16];
acadoWorkspace.lbA[17] = - acadoWorkspace.evH[17];
acadoWorkspace.lbA[18] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[18];
acadoWorkspace.lbA[19] = - acadoWorkspace.evH[19];
acadoWorkspace.lbA[20] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[20];
acadoWorkspace.lbA[21] = - acadoWorkspace.evH[21];
acadoWorkspace.lbA[22] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[22];
acadoWorkspace.lbA[23] = - acadoWorkspace.evH[23];
acadoWorkspace.lbA[24] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[24];
acadoWorkspace.lbA[25] = - acadoWorkspace.evH[25];
acadoWorkspace.lbA[26] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[26];
acadoWorkspace.lbA[27] = - acadoWorkspace.evH[27];
acadoWorkspace.lbA[28] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[28];
acadoWorkspace.lbA[29] = - acadoWorkspace.evH[29];
acadoWorkspace.lbA[30] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[30];
acadoWorkspace.lbA[31] = - acadoWorkspace.evH[31];
acadoWorkspace.lbA[32] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[32];
acadoWorkspace.lbA[33] = - acadoWorkspace.evH[33];
acadoWorkspace.lbA[34] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[34];
acadoWorkspace.lbA[35] = - acadoWorkspace.evH[35];
acadoWorkspace.lbA[36] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[36];
acadoWorkspace.lbA[37] = - acadoWorkspace.evH[37];
acadoWorkspace.lbA[38] = (real_t)-1.0000000000000000e+12 - acadoWorkspace.evH[38];
acadoWorkspace.lbA[39] = - acadoWorkspace.evH[39];

acadoWorkspace.ubA[0] = - acadoWorkspace.evH[0];
acadoWorkspace.ubA[1] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[1];
acadoWorkspace.ubA[2] = - acadoWorkspace.evH[2];
acadoWorkspace.ubA[3] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[3];
acadoWorkspace.ubA[4] = - acadoWorkspace.evH[4];
acadoWorkspace.ubA[5] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[5];
acadoWorkspace.ubA[6] = - acadoWorkspace.evH[6];
acadoWorkspace.ubA[7] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[7];
acadoWorkspace.ubA[8] = - acadoWorkspace.evH[8];
acadoWorkspace.ubA[9] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[9];
acadoWorkspace.ubA[10] = - acadoWorkspace.evH[10];
acadoWorkspace.ubA[11] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[11];
acadoWorkspace.ubA[12] = - acadoWorkspace.evH[12];
acadoWorkspace.ubA[13] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[13];
acadoWorkspace.ubA[14] = - acadoWorkspace.evH[14];
acadoWorkspace.ubA[15] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[15];
acadoWorkspace.ubA[16] = - acadoWorkspace.evH[16];
acadoWorkspace.ubA[17] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[17];
acadoWorkspace.ubA[18] = - acadoWorkspace.evH[18];
acadoWorkspace.ubA[19] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[19];
acadoWorkspace.ubA[20] = - acadoWorkspace.evH[20];
acadoWorkspace.ubA[21] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[21];
acadoWorkspace.ubA[22] = - acadoWorkspace.evH[22];
acadoWorkspace.ubA[23] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[23];
acadoWorkspace.ubA[24] = - acadoWorkspace.evH[24];
acadoWorkspace.ubA[25] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[25];
acadoWorkspace.ubA[26] = - acadoWorkspace.evH[26];
acadoWorkspace.ubA[27] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[27];
acadoWorkspace.ubA[28] = - acadoWorkspace.evH[28];
acadoWorkspace.ubA[29] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[29];
acadoWorkspace.ubA[30] = - acadoWorkspace.evH[30];
acadoWorkspace.ubA[31] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[31];
acadoWorkspace.ubA[32] = - acadoWorkspace.evH[32];
acadoWorkspace.ubA[33] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[33];
acadoWorkspace.ubA[34] = - acadoWorkspace.evH[34];
acadoWorkspace.ubA[35] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[35];
acadoWorkspace.ubA[36] = - acadoWorkspace.evH[36];
acadoWorkspace.ubA[37] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[37];
acadoWorkspace.ubA[38] = - acadoWorkspace.evH[38];
acadoWorkspace.ubA[39] = (real_t)1.0000000000000000e+12 - acadoWorkspace.evH[39];

}

void acado_condenseFdb(  )
{
acadoWorkspace.Dx0[0] = acadoVariables.x0[0] - acadoVariables.x[0];
acadoWorkspace.Dx0[1] = acadoVariables.x0[1] - acadoVariables.x[1];
acadoWorkspace.Dx0[2] = acadoVariables.x0[2] - acadoVariables.x[2];
acadoWorkspace.Dx0[3] = acadoVariables.x0[3] - acadoVariables.x[3];
acadoWorkspace.Dx0[4] = acadoVariables.x0[4] - acadoVariables.x[4];
acadoWorkspace.Dx0[5] = acadoVariables.x0[5] - acadoVariables.x[5];
acadoWorkspace.Dx0[6] = acadoVariables.x0[6] - acadoVariables.x[6];
acadoWorkspace.Dx0[7] = acadoVariables.x0[7] - acadoVariables.x[7];
acadoWorkspace.Dx0[8] = acadoVariables.x0[8] - acadoVariables.x[8];
acadoWorkspace.Dx0[9] = acadoVariables.x0[9] - acadoVariables.x[9];
acadoWorkspace.Dx0[10] = acadoVariables.x0[10] - acadoVariables.x[10];
acadoWorkspace.Dx0[11] = acadoVariables.x0[11] - acadoVariables.x[11];
acadoWorkspace.Dx0[12] = acadoVariables.x0[12] - acadoVariables.x[12];
acadoWorkspace.Dy[0] -= acadoVariables.y[0];
acadoWorkspace.Dy[1] -= acadoVariables.y[1];
acadoWorkspace.Dy[2] -= acadoVariables.y[2];
acadoWorkspace.Dy[3] -= acadoVariables.y[3];
acadoWorkspace.Dy[4] -= acadoVariables.y[4];
acadoWorkspace.Dy[5] -= acadoVariables.y[5];
acadoWorkspace.Dy[6] -= acadoVariables.y[6];
acadoWorkspace.Dy[7] -= acadoVariables.y[7];
acadoWorkspace.Dy[8] -= acadoVariables.y[8];
acadoWorkspace.Dy[9] -= acadoVariables.y[9];
acadoWorkspace.Dy[10] -= acadoVariables.y[10];
acadoWorkspace.Dy[11] -= acadoVariables.y[11];
acadoWorkspace.Dy[12] -= acadoVariables.y[12];
acadoWorkspace.Dy[13] -= acadoVariables.y[13];
acadoWorkspace.Dy[14] -= acadoVariables.y[14];
acadoWorkspace.Dy[15] -= acadoVariables.y[15];
acadoWorkspace.Dy[16] -= acadoVariables.y[16];
acadoWorkspace.Dy[17] -= acadoVariables.y[17];
acadoWorkspace.Dy[18] -= acadoVariables.y[18];
acadoWorkspace.Dy[19] -= acadoVariables.y[19];
acadoWorkspace.Dy[20] -= acadoVariables.y[20];
acadoWorkspace.Dy[21] -= acadoVariables.y[21];
acadoWorkspace.Dy[22] -= acadoVariables.y[22];
acadoWorkspace.Dy[23] -= acadoVariables.y[23];
acadoWorkspace.Dy[24] -= acadoVariables.y[24];
acadoWorkspace.Dy[25] -= acadoVariables.y[25];
acadoWorkspace.Dy[26] -= acadoVariables.y[26];
acadoWorkspace.Dy[27] -= acadoVariables.y[27];
acadoWorkspace.Dy[28] -= acadoVariables.y[28];
acadoWorkspace.Dy[29] -= acadoVariables.y[29];
acadoWorkspace.Dy[30] -= acadoVariables.y[30];
acadoWorkspace.Dy[31] -= acadoVariables.y[31];
acadoWorkspace.Dy[32] -= acadoVariables.y[32];
acadoWorkspace.Dy[33] -= acadoVariables.y[33];
acadoWorkspace.Dy[34] -= acadoVariables.y[34];
acadoWorkspace.Dy[35] -= acadoVariables.y[35];
acadoWorkspace.Dy[36] -= acadoVariables.y[36];
acadoWorkspace.Dy[37] -= acadoVariables.y[37];
acadoWorkspace.Dy[38] -= acadoVariables.y[38];
acadoWorkspace.Dy[39] -= acadoVariables.y[39];
acadoWorkspace.DyN[0] -= acadoVariables.yN[0];
acadoWorkspace.DyN[1] -= acadoVariables.yN[1];

acado_multRDy( acadoWorkspace.R2, acadoWorkspace.Dy, acadoWorkspace.g );
acado_multRDy( &(acadoWorkspace.R2[ 8 ]), &(acadoWorkspace.Dy[ 4 ]), &(acadoWorkspace.g[ 2 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 16 ]), &(acadoWorkspace.Dy[ 8 ]), &(acadoWorkspace.g[ 4 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 24 ]), &(acadoWorkspace.Dy[ 12 ]), &(acadoWorkspace.g[ 6 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 32 ]), &(acadoWorkspace.Dy[ 16 ]), &(acadoWorkspace.g[ 8 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 40 ]), &(acadoWorkspace.Dy[ 20 ]), &(acadoWorkspace.g[ 10 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 48 ]), &(acadoWorkspace.Dy[ 24 ]), &(acadoWorkspace.g[ 12 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 56 ]), &(acadoWorkspace.Dy[ 28 ]), &(acadoWorkspace.g[ 14 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 64 ]), &(acadoWorkspace.Dy[ 32 ]), &(acadoWorkspace.g[ 16 ]) );
acado_multRDy( &(acadoWorkspace.R2[ 72 ]), &(acadoWorkspace.Dy[ 36 ]), &(acadoWorkspace.g[ 18 ]) );

acado_multQDy( acadoWorkspace.Q2, acadoWorkspace.Dy, acadoWorkspace.QDy );
acado_multQDy( &(acadoWorkspace.Q2[ 52 ]), &(acadoWorkspace.Dy[ 4 ]), &(acadoWorkspace.QDy[ 13 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 104 ]), &(acadoWorkspace.Dy[ 8 ]), &(acadoWorkspace.QDy[ 26 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 156 ]), &(acadoWorkspace.Dy[ 12 ]), &(acadoWorkspace.QDy[ 39 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 208 ]), &(acadoWorkspace.Dy[ 16 ]), &(acadoWorkspace.QDy[ 52 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 260 ]), &(acadoWorkspace.Dy[ 20 ]), &(acadoWorkspace.QDy[ 65 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 312 ]), &(acadoWorkspace.Dy[ 24 ]), &(acadoWorkspace.QDy[ 78 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 364 ]), &(acadoWorkspace.Dy[ 28 ]), &(acadoWorkspace.QDy[ 91 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 416 ]), &(acadoWorkspace.Dy[ 32 ]), &(acadoWorkspace.QDy[ 104 ]) );
acado_multQDy( &(acadoWorkspace.Q2[ 468 ]), &(acadoWorkspace.Dy[ 36 ]), &(acadoWorkspace.QDy[ 117 ]) );

acadoWorkspace.QDy[130] = + acadoWorkspace.QN2[0]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[1]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[131] = + acadoWorkspace.QN2[2]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[3]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[132] = + acadoWorkspace.QN2[4]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[5]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[133] = + acadoWorkspace.QN2[6]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[7]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[134] = + acadoWorkspace.QN2[8]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[9]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[135] = + acadoWorkspace.QN2[10]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[11]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[136] = + acadoWorkspace.QN2[12]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[13]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[137] = + acadoWorkspace.QN2[14]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[15]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[138] = + acadoWorkspace.QN2[16]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[17]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[139] = + acadoWorkspace.QN2[18]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[19]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[140] = + acadoWorkspace.QN2[20]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[21]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[141] = + acadoWorkspace.QN2[22]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[23]*acadoWorkspace.DyN[1];
acadoWorkspace.QDy[142] = + acadoWorkspace.QN2[24]*acadoWorkspace.DyN[0] + acadoWorkspace.QN2[25]*acadoWorkspace.DyN[1];

acadoWorkspace.sbar[0] = acadoWorkspace.Dx0[0];
acadoWorkspace.sbar[1] = acadoWorkspace.Dx0[1];
acadoWorkspace.sbar[2] = acadoWorkspace.Dx0[2];
acadoWorkspace.sbar[3] = acadoWorkspace.Dx0[3];
acadoWorkspace.sbar[4] = acadoWorkspace.Dx0[4];
acadoWorkspace.sbar[5] = acadoWorkspace.Dx0[5];
acadoWorkspace.sbar[6] = acadoWorkspace.Dx0[6];
acadoWorkspace.sbar[7] = acadoWorkspace.Dx0[7];
acadoWorkspace.sbar[8] = acadoWorkspace.Dx0[8];
acadoWorkspace.sbar[9] = acadoWorkspace.Dx0[9];
acadoWorkspace.sbar[10] = acadoWorkspace.Dx0[10];
acadoWorkspace.sbar[11] = acadoWorkspace.Dx0[11];
acadoWorkspace.sbar[12] = acadoWorkspace.Dx0[12];
acado_macASbar( acadoWorkspace.evGx, acadoWorkspace.sbar, &(acadoWorkspace.sbar[ 13 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 169 ]), &(acadoWorkspace.sbar[ 13 ]), &(acadoWorkspace.sbar[ 26 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 338 ]), &(acadoWorkspace.sbar[ 26 ]), &(acadoWorkspace.sbar[ 39 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 507 ]), &(acadoWorkspace.sbar[ 39 ]), &(acadoWorkspace.sbar[ 52 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.sbar[ 52 ]), &(acadoWorkspace.sbar[ 65 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.sbar[ 65 ]), &(acadoWorkspace.sbar[ 78 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.sbar[ 78 ]), &(acadoWorkspace.sbar[ 91 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.sbar[ 91 ]), &(acadoWorkspace.sbar[ 104 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.sbar[ 104 ]), &(acadoWorkspace.sbar[ 117 ]) );
acado_macASbar( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.sbar[ 117 ]), &(acadoWorkspace.sbar[ 130 ]) );

acadoWorkspace.w1[0] = + acadoWorkspace.QN1[0]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[1]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[2]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[3]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[4]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[5]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[6]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[7]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[8]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[9]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[10]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[11]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[12]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[130];
acadoWorkspace.w1[1] = + acadoWorkspace.QN1[13]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[14]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[15]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[16]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[17]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[18]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[19]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[20]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[21]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[22]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[23]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[24]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[25]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[131];
acadoWorkspace.w1[2] = + acadoWorkspace.QN1[26]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[27]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[28]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[29]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[30]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[31]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[32]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[33]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[34]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[35]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[36]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[37]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[38]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[132];
acadoWorkspace.w1[3] = + acadoWorkspace.QN1[39]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[40]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[41]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[42]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[43]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[44]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[45]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[46]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[47]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[48]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[49]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[50]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[51]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[133];
acadoWorkspace.w1[4] = + acadoWorkspace.QN1[52]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[53]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[54]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[55]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[56]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[57]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[58]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[59]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[60]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[61]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[62]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[63]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[64]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[134];
acadoWorkspace.w1[5] = + acadoWorkspace.QN1[65]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[66]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[67]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[68]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[69]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[70]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[71]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[72]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[73]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[74]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[75]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[76]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[77]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[135];
acadoWorkspace.w1[6] = + acadoWorkspace.QN1[78]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[79]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[80]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[81]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[82]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[83]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[84]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[85]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[86]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[87]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[88]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[89]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[90]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[136];
acadoWorkspace.w1[7] = + acadoWorkspace.QN1[91]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[92]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[93]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[94]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[95]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[96]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[97]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[98]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[99]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[100]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[101]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[102]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[103]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[137];
acadoWorkspace.w1[8] = + acadoWorkspace.QN1[104]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[105]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[106]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[107]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[108]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[109]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[110]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[111]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[112]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[113]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[114]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[115]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[116]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[138];
acadoWorkspace.w1[9] = + acadoWorkspace.QN1[117]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[118]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[119]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[120]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[121]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[122]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[123]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[124]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[125]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[126]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[127]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[128]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[129]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[139];
acadoWorkspace.w1[10] = + acadoWorkspace.QN1[130]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[131]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[132]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[133]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[134]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[135]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[136]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[137]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[138]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[139]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[140]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[141]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[142]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[140];
acadoWorkspace.w1[11] = + acadoWorkspace.QN1[143]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[144]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[145]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[146]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[147]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[148]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[149]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[150]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[151]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[152]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[153]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[154]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[155]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[141];
acadoWorkspace.w1[12] = + acadoWorkspace.QN1[156]*acadoWorkspace.sbar[130] + acadoWorkspace.QN1[157]*acadoWorkspace.sbar[131] + acadoWorkspace.QN1[158]*acadoWorkspace.sbar[132] + acadoWorkspace.QN1[159]*acadoWorkspace.sbar[133] + acadoWorkspace.QN1[160]*acadoWorkspace.sbar[134] + acadoWorkspace.QN1[161]*acadoWorkspace.sbar[135] + acadoWorkspace.QN1[162]*acadoWorkspace.sbar[136] + acadoWorkspace.QN1[163]*acadoWorkspace.sbar[137] + acadoWorkspace.QN1[164]*acadoWorkspace.sbar[138] + acadoWorkspace.QN1[165]*acadoWorkspace.sbar[139] + acadoWorkspace.QN1[166]*acadoWorkspace.sbar[140] + acadoWorkspace.QN1[167]*acadoWorkspace.sbar[141] + acadoWorkspace.QN1[168]*acadoWorkspace.sbar[142] + acadoWorkspace.QDy[142];
acado_macBTw1( &(acadoWorkspace.evGu[ 234 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 18 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 1521 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 117 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 1521 ]), &(acadoWorkspace.sbar[ 117 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 208 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 16 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 1352 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 104 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 1352 ]), &(acadoWorkspace.sbar[ 104 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 182 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 14 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 1183 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 91 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 1183 ]), &(acadoWorkspace.sbar[ 91 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 156 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 12 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 1014 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 78 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 1014 ]), &(acadoWorkspace.sbar[ 78 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 130 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 10 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 845 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 65 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 845 ]), &(acadoWorkspace.sbar[ 65 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 104 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 8 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 676 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 52 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 676 ]), &(acadoWorkspace.sbar[ 52 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 78 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 6 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 507 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 39 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 507 ]), &(acadoWorkspace.sbar[ 39 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 52 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 4 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 338 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 26 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 338 ]), &(acadoWorkspace.sbar[ 26 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( &(acadoWorkspace.evGu[ 26 ]), acadoWorkspace.w1, &(acadoWorkspace.g[ 2 ]) );
acado_macATw1QDy( &(acadoWorkspace.evGx[ 169 ]), acadoWorkspace.w1, &(acadoWorkspace.QDy[ 13 ]), acadoWorkspace.w2 );
acado_macQSbarW2( &(acadoWorkspace.Q1[ 169 ]), &(acadoWorkspace.sbar[ 13 ]), acadoWorkspace.w2, acadoWorkspace.w1 );
acado_macBTw1( acadoWorkspace.evGu, acadoWorkspace.w1, acadoWorkspace.g );



acado_macHxd( acadoWorkspace.evHx, acadoWorkspace.sbar, acadoWorkspace.lbA, acadoWorkspace.ubA );
acado_macHxd( &(acadoWorkspace.evHx[ 52 ]), &(acadoWorkspace.sbar[ 13 ]), &(acadoWorkspace.lbA[ 4 ]), &(acadoWorkspace.ubA[ 4 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 104 ]), &(acadoWorkspace.sbar[ 26 ]), &(acadoWorkspace.lbA[ 8 ]), &(acadoWorkspace.ubA[ 8 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 156 ]), &(acadoWorkspace.sbar[ 39 ]), &(acadoWorkspace.lbA[ 12 ]), &(acadoWorkspace.ubA[ 12 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 208 ]), &(acadoWorkspace.sbar[ 52 ]), &(acadoWorkspace.lbA[ 16 ]), &(acadoWorkspace.ubA[ 16 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 260 ]), &(acadoWorkspace.sbar[ 65 ]), &(acadoWorkspace.lbA[ 20 ]), &(acadoWorkspace.ubA[ 20 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 312 ]), &(acadoWorkspace.sbar[ 78 ]), &(acadoWorkspace.lbA[ 24 ]), &(acadoWorkspace.ubA[ 24 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 364 ]), &(acadoWorkspace.sbar[ 91 ]), &(acadoWorkspace.lbA[ 28 ]), &(acadoWorkspace.ubA[ 28 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 416 ]), &(acadoWorkspace.sbar[ 104 ]), &(acadoWorkspace.lbA[ 32 ]), &(acadoWorkspace.ubA[ 32 ]) );
acado_macHxd( &(acadoWorkspace.evHx[ 468 ]), &(acadoWorkspace.sbar[ 117 ]), &(acadoWorkspace.lbA[ 36 ]), &(acadoWorkspace.ubA[ 36 ]) );

}

void acado_expand(  )
{
int lRun1;
acadoVariables.u[0] += acadoWorkspace.x[0];
acadoVariables.u[1] += acadoWorkspace.x[1];
acadoVariables.u[2] += acadoWorkspace.x[2];
acadoVariables.u[3] += acadoWorkspace.x[3];
acadoVariables.u[4] += acadoWorkspace.x[4];
acadoVariables.u[5] += acadoWorkspace.x[5];
acadoVariables.u[6] += acadoWorkspace.x[6];
acadoVariables.u[7] += acadoWorkspace.x[7];
acadoVariables.u[8] += acadoWorkspace.x[8];
acadoVariables.u[9] += acadoWorkspace.x[9];
acadoVariables.u[10] += acadoWorkspace.x[10];
acadoVariables.u[11] += acadoWorkspace.x[11];
acadoVariables.u[12] += acadoWorkspace.x[12];
acadoVariables.u[13] += acadoWorkspace.x[13];
acadoVariables.u[14] += acadoWorkspace.x[14];
acadoVariables.u[15] += acadoWorkspace.x[15];
acadoVariables.u[16] += acadoWorkspace.x[16];
acadoVariables.u[17] += acadoWorkspace.x[17];
acadoVariables.u[18] += acadoWorkspace.x[18];
acadoVariables.u[19] += acadoWorkspace.x[19];
acadoWorkspace.sbar[0] = acadoWorkspace.Dx0[0];
acadoWorkspace.sbar[1] = acadoWorkspace.Dx0[1];
acadoWorkspace.sbar[2] = acadoWorkspace.Dx0[2];
acadoWorkspace.sbar[3] = acadoWorkspace.Dx0[3];
acadoWorkspace.sbar[4] = acadoWorkspace.Dx0[4];
acadoWorkspace.sbar[5] = acadoWorkspace.Dx0[5];
acadoWorkspace.sbar[6] = acadoWorkspace.Dx0[6];
acadoWorkspace.sbar[7] = acadoWorkspace.Dx0[7];
acadoWorkspace.sbar[8] = acadoWorkspace.Dx0[8];
acadoWorkspace.sbar[9] = acadoWorkspace.Dx0[9];
acadoWorkspace.sbar[10] = acadoWorkspace.Dx0[10];
acadoWorkspace.sbar[11] = acadoWorkspace.Dx0[11];
acadoWorkspace.sbar[12] = acadoWorkspace.Dx0[12];
for (lRun1 = 0; lRun1 < 130; ++lRun1)
acadoWorkspace.sbar[lRun1 + 13] = acadoWorkspace.d[lRun1];

acado_expansionStep( acadoWorkspace.evGx, acadoWorkspace.evGu, acadoWorkspace.x, acadoWorkspace.sbar, &(acadoWorkspace.sbar[ 13 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 169 ]), &(acadoWorkspace.evGu[ 26 ]), &(acadoWorkspace.x[ 2 ]), &(acadoWorkspace.sbar[ 13 ]), &(acadoWorkspace.sbar[ 26 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 338 ]), &(acadoWorkspace.evGu[ 52 ]), &(acadoWorkspace.x[ 4 ]), &(acadoWorkspace.sbar[ 26 ]), &(acadoWorkspace.sbar[ 39 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 507 ]), &(acadoWorkspace.evGu[ 78 ]), &(acadoWorkspace.x[ 6 ]), &(acadoWorkspace.sbar[ 39 ]), &(acadoWorkspace.sbar[ 52 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 676 ]), &(acadoWorkspace.evGu[ 104 ]), &(acadoWorkspace.x[ 8 ]), &(acadoWorkspace.sbar[ 52 ]), &(acadoWorkspace.sbar[ 65 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 845 ]), &(acadoWorkspace.evGu[ 130 ]), &(acadoWorkspace.x[ 10 ]), &(acadoWorkspace.sbar[ 65 ]), &(acadoWorkspace.sbar[ 78 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 1014 ]), &(acadoWorkspace.evGu[ 156 ]), &(acadoWorkspace.x[ 12 ]), &(acadoWorkspace.sbar[ 78 ]), &(acadoWorkspace.sbar[ 91 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 1183 ]), &(acadoWorkspace.evGu[ 182 ]), &(acadoWorkspace.x[ 14 ]), &(acadoWorkspace.sbar[ 91 ]), &(acadoWorkspace.sbar[ 104 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 1352 ]), &(acadoWorkspace.evGu[ 208 ]), &(acadoWorkspace.x[ 16 ]), &(acadoWorkspace.sbar[ 104 ]), &(acadoWorkspace.sbar[ 117 ]) );
acado_expansionStep( &(acadoWorkspace.evGx[ 1521 ]), &(acadoWorkspace.evGu[ 234 ]), &(acadoWorkspace.x[ 18 ]), &(acadoWorkspace.sbar[ 117 ]), &(acadoWorkspace.sbar[ 130 ]) );
for (lRun1 = 0; lRun1 < 143; ++lRun1)
acadoVariables.x[lRun1] += acadoWorkspace.sbar[lRun1];

}

int acado_preparationStep(  )
{
int ret;

ret = acado_modelSimulation();
acado_evaluateObjective(  );
acado_condensePrep(  );
return ret;
}

int acado_feedbackStep(  )
{
int tmp;

acado_condenseFdb(  );

tmp = acado_solve( );

acado_expand(  );
return tmp;
}

int acado_initializeSolver(  )
{
int ret;

/* This is a function which must be called once before any other function call! */


ret = 0;

memset(&acadoWorkspace, 0, sizeof( acadoWorkspace ));
return ret;
}

void acado_initializeNodesByForwardSimulation(  )
{
int index;
for (index = 0; index < 10; ++index)
{
acadoWorkspace.state[0] = acadoVariables.x[index * 13];
acadoWorkspace.state[1] = acadoVariables.x[index * 13 + 1];
acadoWorkspace.state[2] = acadoVariables.x[index * 13 + 2];
acadoWorkspace.state[3] = acadoVariables.x[index * 13 + 3];
acadoWorkspace.state[4] = acadoVariables.x[index * 13 + 4];
acadoWorkspace.state[5] = acadoVariables.x[index * 13 + 5];
acadoWorkspace.state[6] = acadoVariables.x[index * 13 + 6];
acadoWorkspace.state[7] = acadoVariables.x[index * 13 + 7];
acadoWorkspace.state[8] = acadoVariables.x[index * 13 + 8];
acadoWorkspace.state[9] = acadoVariables.x[index * 13 + 9];
acadoWorkspace.state[10] = acadoVariables.x[index * 13 + 10];
acadoWorkspace.state[11] = acadoVariables.x[index * 13 + 11];
acadoWorkspace.state[12] = acadoVariables.x[index * 13 + 12];
acadoWorkspace.state[208] = acadoVariables.u[index * 2];
acadoWorkspace.state[209] = acadoVariables.u[index * 2 + 1];
acadoWorkspace.state[210] = acadoVariables.od[index * 8];
acadoWorkspace.state[211] = acadoVariables.od[index * 8 + 1];
acadoWorkspace.state[212] = acadoVariables.od[index * 8 + 2];
acadoWorkspace.state[213] = acadoVariables.od[index * 8 + 3];
acadoWorkspace.state[214] = acadoVariables.od[index * 8 + 4];
acadoWorkspace.state[215] = acadoVariables.od[index * 8 + 5];
acadoWorkspace.state[216] = acadoVariables.od[index * 8 + 6];
acadoWorkspace.state[217] = acadoVariables.od[index * 8 + 7];

acado_integrate(acadoWorkspace.state, index == 0, index);

acadoVariables.x[index * 13 + 13] = acadoWorkspace.state[0];
acadoVariables.x[index * 13 + 14] = acadoWorkspace.state[1];
acadoVariables.x[index * 13 + 15] = acadoWorkspace.state[2];
acadoVariables.x[index * 13 + 16] = acadoWorkspace.state[3];
acadoVariables.x[index * 13 + 17] = acadoWorkspace.state[4];
acadoVariables.x[index * 13 + 18] = acadoWorkspace.state[5];
acadoVariables.x[index * 13 + 19] = acadoWorkspace.state[6];
acadoVariables.x[index * 13 + 20] = acadoWorkspace.state[7];
acadoVariables.x[index * 13 + 21] = acadoWorkspace.state[8];
acadoVariables.x[index * 13 + 22] = acadoWorkspace.state[9];
acadoVariables.x[index * 13 + 23] = acadoWorkspace.state[10];
acadoVariables.x[index * 13 + 24] = acadoWorkspace.state[11];
acadoVariables.x[index * 13 + 25] = acadoWorkspace.state[12];
}
}

void acado_shiftStates( int strategy, real_t* const xEnd, real_t* const uEnd )
{
int index;
for (index = 0; index < 10; ++index)
{
acadoVariables.x[index * 13] = acadoVariables.x[index * 13 + 13];
acadoVariables.x[index * 13 + 1] = acadoVariables.x[index * 13 + 14];
acadoVariables.x[index * 13 + 2] = acadoVariables.x[index * 13 + 15];
acadoVariables.x[index * 13 + 3] = acadoVariables.x[index * 13 + 16];
acadoVariables.x[index * 13 + 4] = acadoVariables.x[index * 13 + 17];
acadoVariables.x[index * 13 + 5] = acadoVariables.x[index * 13 + 18];
acadoVariables.x[index * 13 + 6] = acadoVariables.x[index * 13 + 19];
acadoVariables.x[index * 13 + 7] = acadoVariables.x[index * 13 + 20];
acadoVariables.x[index * 13 + 8] = acadoVariables.x[index * 13 + 21];
acadoVariables.x[index * 13 + 9] = acadoVariables.x[index * 13 + 22];
acadoVariables.x[index * 13 + 10] = acadoVariables.x[index * 13 + 23];
acadoVariables.x[index * 13 + 11] = acadoVariables.x[index * 13 + 24];
acadoVariables.x[index * 13 + 12] = acadoVariables.x[index * 13 + 25];
}

if (strategy == 1 && xEnd != 0)
{
acadoVariables.x[130] = xEnd[0];
acadoVariables.x[131] = xEnd[1];
acadoVariables.x[132] = xEnd[2];
acadoVariables.x[133] = xEnd[3];
acadoVariables.x[134] = xEnd[4];
acadoVariables.x[135] = xEnd[5];
acadoVariables.x[136] = xEnd[6];
acadoVariables.x[137] = xEnd[7];
acadoVariables.x[138] = xEnd[8];
acadoVariables.x[139] = xEnd[9];
acadoVariables.x[140] = xEnd[10];
acadoVariables.x[141] = xEnd[11];
acadoVariables.x[142] = xEnd[12];
}
else if (strategy == 2) 
{
acadoWorkspace.state[0] = acadoVariables.x[130];
acadoWorkspace.state[1] = acadoVariables.x[131];
acadoWorkspace.state[2] = acadoVariables.x[132];
acadoWorkspace.state[3] = acadoVariables.x[133];
acadoWorkspace.state[4] = acadoVariables.x[134];
acadoWorkspace.state[5] = acadoVariables.x[135];
acadoWorkspace.state[6] = acadoVariables.x[136];
acadoWorkspace.state[7] = acadoVariables.x[137];
acadoWorkspace.state[8] = acadoVariables.x[138];
acadoWorkspace.state[9] = acadoVariables.x[139];
acadoWorkspace.state[10] = acadoVariables.x[140];
acadoWorkspace.state[11] = acadoVariables.x[141];
acadoWorkspace.state[12] = acadoVariables.x[142];
if (uEnd != 0)
{
acadoWorkspace.state[208] = uEnd[0];
acadoWorkspace.state[209] = uEnd[1];
}
else
{
acadoWorkspace.state[208] = acadoVariables.u[18];
acadoWorkspace.state[209] = acadoVariables.u[19];
}
acadoWorkspace.state[210] = acadoVariables.od[80];
acadoWorkspace.state[211] = acadoVariables.od[81];
acadoWorkspace.state[212] = acadoVariables.od[82];
acadoWorkspace.state[213] = acadoVariables.od[83];
acadoWorkspace.state[214] = acadoVariables.od[84];
acadoWorkspace.state[215] = acadoVariables.od[85];
acadoWorkspace.state[216] = acadoVariables.od[86];
acadoWorkspace.state[217] = acadoVariables.od[87];

acado_integrate(acadoWorkspace.state, 1, 9);

acadoVariables.x[130] = acadoWorkspace.state[0];
acadoVariables.x[131] = acadoWorkspace.state[1];
acadoVariables.x[132] = acadoWorkspace.state[2];
acadoVariables.x[133] = acadoWorkspace.state[3];
acadoVariables.x[134] = acadoWorkspace.state[4];
acadoVariables.x[135] = acadoWorkspace.state[5];
acadoVariables.x[136] = acadoWorkspace.state[6];
acadoVariables.x[137] = acadoWorkspace.state[7];
acadoVariables.x[138] = acadoWorkspace.state[8];
acadoVariables.x[139] = acadoWorkspace.state[9];
acadoVariables.x[140] = acadoWorkspace.state[10];
acadoVariables.x[141] = acadoWorkspace.state[11];
acadoVariables.x[142] = acadoWorkspace.state[12];
}
}

void acado_shiftControls( real_t* const uEnd )
{
int index;
for (index = 0; index < 9; ++index)
{
acadoVariables.u[index * 2] = acadoVariables.u[index * 2 + 2];
acadoVariables.u[index * 2 + 1] = acadoVariables.u[index * 2 + 3];
}

if (uEnd != 0)
{
acadoVariables.u[18] = uEnd[0];
acadoVariables.u[19] = uEnd[1];
}
}

real_t acado_getKKT(  )
{
real_t kkt;

int index;
real_t prd;

kkt = + acadoWorkspace.g[0]*acadoWorkspace.x[0] + acadoWorkspace.g[1]*acadoWorkspace.x[1] + acadoWorkspace.g[2]*acadoWorkspace.x[2] + acadoWorkspace.g[3]*acadoWorkspace.x[3] + acadoWorkspace.g[4]*acadoWorkspace.x[4] + acadoWorkspace.g[5]*acadoWorkspace.x[5] + acadoWorkspace.g[6]*acadoWorkspace.x[6] + acadoWorkspace.g[7]*acadoWorkspace.x[7] + acadoWorkspace.g[8]*acadoWorkspace.x[8] + acadoWorkspace.g[9]*acadoWorkspace.x[9] + acadoWorkspace.g[10]*acadoWorkspace.x[10] + acadoWorkspace.g[11]*acadoWorkspace.x[11] + acadoWorkspace.g[12]*acadoWorkspace.x[12] + acadoWorkspace.g[13]*acadoWorkspace.x[13] + acadoWorkspace.g[14]*acadoWorkspace.x[14] + acadoWorkspace.g[15]*acadoWorkspace.x[15] + acadoWorkspace.g[16]*acadoWorkspace.x[16] + acadoWorkspace.g[17]*acadoWorkspace.x[17] + acadoWorkspace.g[18]*acadoWorkspace.x[18] + acadoWorkspace.g[19]*acadoWorkspace.x[19];
kkt = fabs( kkt );
for (index = 0; index < 20; ++index)
{
prd = acadoWorkspace.y[index];
if (prd > 1e-12)
kkt += fabs(acadoWorkspace.lb[index] * prd);
else if (prd < -1e-12)
kkt += fabs(acadoWorkspace.ub[index] * prd);
}
for (index = 0; index < 40; ++index)
{
prd = acadoWorkspace.y[index + 20];
if (prd > 1e-12)
kkt += fabs(acadoWorkspace.lbA[index] * prd);
else if (prd < -1e-12)
kkt += fabs(acadoWorkspace.ubA[index] * prd);
}
return kkt;
}

real_t acado_getObjective(  )
{
real_t objVal;

int lRun1;
/** Row vector of size: 4 */
real_t tmpDy[ 4 ];

/** Row vector of size: 2 */
real_t tmpDyN[ 2 ];

for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
acadoWorkspace.objValueIn[0] = acadoVariables.x[lRun1 * 13];
acadoWorkspace.objValueIn[1] = acadoVariables.x[lRun1 * 13 + 1];
acadoWorkspace.objValueIn[2] = acadoVariables.x[lRun1 * 13 + 2];
acadoWorkspace.objValueIn[3] = acadoVariables.x[lRun1 * 13 + 3];
acadoWorkspace.objValueIn[4] = acadoVariables.x[lRun1 * 13 + 4];
acadoWorkspace.objValueIn[5] = acadoVariables.x[lRun1 * 13 + 5];
acadoWorkspace.objValueIn[6] = acadoVariables.x[lRun1 * 13 + 6];
acadoWorkspace.objValueIn[7] = acadoVariables.x[lRun1 * 13 + 7];
acadoWorkspace.objValueIn[8] = acadoVariables.x[lRun1 * 13 + 8];
acadoWorkspace.objValueIn[9] = acadoVariables.x[lRun1 * 13 + 9];
acadoWorkspace.objValueIn[10] = acadoVariables.x[lRun1 * 13 + 10];
acadoWorkspace.objValueIn[11] = acadoVariables.x[lRun1 * 13 + 11];
acadoWorkspace.objValueIn[12] = acadoVariables.x[lRun1 * 13 + 12];
acadoWorkspace.objValueIn[13] = acadoVariables.u[lRun1 * 2];
acadoWorkspace.objValueIn[14] = acadoVariables.u[lRun1 * 2 + 1];
acadoWorkspace.objValueIn[15] = acadoVariables.od[lRun1 * 8];
acadoWorkspace.objValueIn[16] = acadoVariables.od[lRun1 * 8 + 1];
acadoWorkspace.objValueIn[17] = acadoVariables.od[lRun1 * 8 + 2];
acadoWorkspace.objValueIn[18] = acadoVariables.od[lRun1 * 8 + 3];
acadoWorkspace.objValueIn[19] = acadoVariables.od[lRun1 * 8 + 4];
acadoWorkspace.objValueIn[20] = acadoVariables.od[lRun1 * 8 + 5];
acadoWorkspace.objValueIn[21] = acadoVariables.od[lRun1 * 8 + 6];
acadoWorkspace.objValueIn[22] = acadoVariables.od[lRun1 * 8 + 7];

acado_evaluateLSQ( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );
acadoWorkspace.Dy[lRun1 * 4] = acadoWorkspace.objValueOut[0] - acadoVariables.y[lRun1 * 4];
acadoWorkspace.Dy[lRun1 * 4 + 1] = acadoWorkspace.objValueOut[1] - acadoVariables.y[lRun1 * 4 + 1];
acadoWorkspace.Dy[lRun1 * 4 + 2] = acadoWorkspace.objValueOut[2] - acadoVariables.y[lRun1 * 4 + 2];
acadoWorkspace.Dy[lRun1 * 4 + 3] = acadoWorkspace.objValueOut[3] - acadoVariables.y[lRun1 * 4 + 3];
}
acadoWorkspace.objValueIn[0] = acadoVariables.x[130];
acadoWorkspace.objValueIn[1] = acadoVariables.x[131];
acadoWorkspace.objValueIn[2] = acadoVariables.x[132];
acadoWorkspace.objValueIn[3] = acadoVariables.x[133];
acadoWorkspace.objValueIn[4] = acadoVariables.x[134];
acadoWorkspace.objValueIn[5] = acadoVariables.x[135];
acadoWorkspace.objValueIn[6] = acadoVariables.x[136];
acadoWorkspace.objValueIn[7] = acadoVariables.x[137];
acadoWorkspace.objValueIn[8] = acadoVariables.x[138];
acadoWorkspace.objValueIn[9] = acadoVariables.x[139];
acadoWorkspace.objValueIn[10] = acadoVariables.x[140];
acadoWorkspace.objValueIn[11] = acadoVariables.x[141];
acadoWorkspace.objValueIn[12] = acadoVariables.x[142];
acadoWorkspace.objValueIn[13] = acadoVariables.od[80];
acadoWorkspace.objValueIn[14] = acadoVariables.od[81];
acadoWorkspace.objValueIn[15] = acadoVariables.od[82];
acadoWorkspace.objValueIn[16] = acadoVariables.od[83];
acadoWorkspace.objValueIn[17] = acadoVariables.od[84];
acadoWorkspace.objValueIn[18] = acadoVariables.od[85];
acadoWorkspace.objValueIn[19] = acadoVariables.od[86];
acadoWorkspace.objValueIn[20] = acadoVariables.od[87];
acado_evaluateLSQEndTerm( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );
acadoWorkspace.DyN[0] = acadoWorkspace.objValueOut[0] - acadoVariables.yN[0];
acadoWorkspace.DyN[1] = acadoWorkspace.objValueOut[1] - acadoVariables.yN[1];
objVal = 0.0000000000000000e+00;
for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
tmpDy[0] = + acadoWorkspace.Dy[lRun1 * 4]*acadoVariables.W[0];
tmpDy[1] = + acadoWorkspace.Dy[lRun1 * 4 + 1]*acadoVariables.W[5];
tmpDy[2] = + acadoWorkspace.Dy[lRun1 * 4 + 2]*acadoVariables.W[10];
tmpDy[3] = + acadoWorkspace.Dy[lRun1 * 4 + 3]*acadoVariables.W[15];
objVal += + acadoWorkspace.Dy[lRun1 * 4]*tmpDy[0] + acadoWorkspace.Dy[lRun1 * 4 + 1]*tmpDy[1] + acadoWorkspace.Dy[lRun1 * 4 + 2]*tmpDy[2] + acadoWorkspace.Dy[lRun1 * 4 + 3]*tmpDy[3];
}

tmpDyN[0] = + acadoWorkspace.DyN[0]*acadoVariables.WN[0];
tmpDyN[1] = + acadoWorkspace.DyN[1]*acadoVariables.WN[3];
objVal += + acadoWorkspace.DyN[0]*tmpDyN[0] + acadoWorkspace.DyN[1]*tmpDyN[1];

objVal *= 0.5;
return objVal;
}

